#!/bin/sh

cd daemontools-0.76 &&
patch -Np1 -i ../daemontools-0.76.errno.patch &&
package/compile &&
cd package &&
sed 's|command|usr/sbin|' boot.inittab > boot.inittab~ &&
mv boot.inittab~ boot.inittab &&
cd ../command &&
sed -e 's|/command:/usr/local/bin:/usr/local/sbin:||' \
    -e 's|command|usr/sbin|' \
    -e 's|/service|/etc/service|g' svscanboot > svscanboot~ &&
mv svscanboot~ svscanboot &&
chmod 555 svscanboot &&
cp * /usr/sbin &&
cd ../package &&
cat /etc/inittab boot.inittab > /etc/inittab~ &&
mv -f /etc/inittab~ /etc/inittab &&
mkdir /etc/service &&
telinit Q
