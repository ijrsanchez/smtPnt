/**
* @file	Arg_Window.cpp
* @brief		<b>Tipo Abstracto de Dato (Widget) para contener a
*				traves de una Ventana los demas Widgets.<br>
*				Este Widget contiene tres temporizadores los
*				cuales disparan los eventos para actualizar los
*				demas objetos que se agreguen a la Ventana.<br>
*				Los Widgets son desarrollados para ser implementados
*				en interfARGOS (RAD basado en fluid) usando la
*				biblioteca grafica FLTK http://www.fltk.org </b><br>
* @author	    Alejandro Pina <ajpina@gmail.com><br>
* @link			http://www.cintal.com.ve/tecnologia/argos<br>
* @package      argos
* @access       public
* @version      1.0  -  01/06/09
*/

/*
Copyright (C) 2006 Alejandro Pina <ajpina@gmail.com>

Este programa es software libre. Puede redistribuirlo y/o modificarlo bajo
los terminos de la Licencia Publica General de GNU segun es publicada por
la Free Software Foundation, bien de la version 3 de dicha Licencia o bien
(segun su eleccion) de cualquier version posterior.

Este programa se distribuye con la esperanza de que sea util, pero
SIN NINGUNA GARANTIA, incluso sin la garantia MERCANTIL implicita o sin
garantizar la CONVENIENCIA PARA UN PROPOSITO PARTICULAR. Vease la Licencia
Publica General de GNU para mas detalles.

Deberia haber recibido una copia de la Licencia Publica General junto con
este programa. Si no ha sido asi, escriba a la Free Software Foundation, Inc.,
en 675 Mass Ave, Cambridge, MA 02139, EEUU.

Alejandro Pina mediante este documento renuncia a cualquier interes de derechos de
copyright con respecto al programa 'argos'.

01 de Noviembre de 2008

Por favor reporte cualquier fallo a la siguiente direccion:

	http://www.cintal.com.ve/tecnologia/argos

*/

#include "Arg_Window.h"

using namespace infarg;

/**
* @brief	Constructor del Objeto
* @param	x				Ancho del Widget
* @param	y				Alto del Widget
* @param	nombre_shm_t	Memoria Compartida de Tags
* @param	nombre_shm_a	Memoria Compartida de Alarmas
* @return	Referencia al Objeto
*/
Arg_Window::Arg_Window(int x, int y, std::string nombre_shm_t,
		std::string nombre_shm_a ) : Fl_Double_Window(x,y){
	Fl::add_timeout(0.577, refrescar_rapido, this);
	Fl::add_timeout(1.117, refrescar_normal, this);
	Fl::add_timeout(4.931, refrescar_lento, this);
	data = new Arg_Data( nombre_shm_t, nombre_shm_a );
}

/**
* @brief	Constructor del Objeto
* @param	x		Ancho del Widget
* @param	y		Alto del Widget
* @return	Referencia al Objeto
*/
Arg_Window::Arg_Window(int x, int y ) : Fl_Double_Window(x,y){
}

/**
* @brief	Destructor por Defecto
*/
Arg_Window::~Arg_Window(){
	delete data;
}

/**
* @brief	Registra tres temporizadores y las memorias compartidas
*			para el acceso a Tags y Alarmas
* @param	nombre_shm_t	Memoria Compartida de Tags
* @param	nombre_shm_a	Memoria Compartida de Alarmas
*/
void Arg_Window::agregar_timeout( std::string nombre_shm_t,
		std::string nombre_shm_a ){
	Fl::add_timeout(0.577, refrescar_rapido, this);
	Fl::add_timeout(1.117, refrescar_normal, this);
	Fl::add_timeout(4.931, refrescar_lento, this);
	data = new Arg_Data( nombre_shm_t, nombre_shm_a );
}

/**
* @brief	Asigna el Temporizado rapido a un Widget que es
*			contenido dentro de la Ventana, para que el
*			Temporizado dispare eventos que permitan refrescar
*			el Widget
* @param	widget		Widget contenido en la Ventana
*/
void Arg_Window::registrar_timer_rapido(Arg_Widget *widget){
	l_rapido.push_back( widget );
	widget->asignar_data( data );
}

/**
* @brief	Asigna el Temporizado normal a un Widget que es
*			contenido dentro de la Ventana, para que el
*			Temporizado dispare eventos que permitan refrescar
*			el Widget
* @param	widget		Widget contenido en la Ventana
*/
void Arg_Window::registrar_timer_normal(Arg_Widget *widget){
	l_normal.push_back( widget );
	widget->asignar_data( data );
}

/**
* @brief	Asigna el Temporizado lento a un Widget que es
*			contenido dentro de la Ventana, para que el
*			Temporizado dispare eventos que permitan refrescar
*			el Widget
* @param	widget		Widget contenido en la Ventana
*/
void Arg_Window::registrar_timer_lento(Arg_Widget *widget){
	l_lento.push_back( widget );
	widget->asignar_data( data );
}

/**
* @brief	Al consumirse el tiempo del Temporizado rapido se
*			dispara un evento para que los Widgets sean
*			refrescados con valores recientes de Tags y Alarmas
*/
void Arg_Window::disparar_rapido(){
	list <Arg_Widget *>::iterator it;
	for(it=l_rapido.begin(); it != l_rapido.end(); ++it){
		if(*it){
			(*it)->refrescar();
		}
	}
	Fl::repeat_timeout(0.577, refrescar_rapido, this);
}

/**
* @brief	Al consumirse el tiempo del Temporizado normal se
*			dispara un evento para que los Widgets sean
*			refrescados con valores recientes de Tags y Alarmas
*/
void Arg_Window::disparar_normal(){
	list <Arg_Widget *>::iterator it;
	for(it=l_normal.begin(); it != l_normal.end(); ++it){
		if(*it){
			(*it)->refrescar();
		}
	}
	Fl::repeat_timeout(1.117, refrescar_normal, this);
}

/**
* @brief	Al consumirse el tiempo del Temporizado lento se
*			dispara un evento para que los Widgets sean
*			refrescados con valores recientes de Tags y Alarmas
*/
void Arg_Window::disparar_lento(){
	list <Arg_Widget *>::iterator it;
	for(it=l_lento.begin(); it != l_lento.end(); ++it){
		if(*it){
			(*it)->refrescar();
		}
	}
	Fl::repeat_timeout(4.931, refrescar_lento, this);
}

/**
* @brief	Funciones disparadas por el Temporizador rapido
*			al consumirse el tiempo
* @param	user	Referencia a la Ventana principal
*/
static void infarg::refrescar_rapido(void* user){
		((Arg_Window*)user)->disparar_rapido();
}

/**
* @brief	Funciones disparadas por el Temporizador normal
*			al consumirse el tiempo
* @param	user	Referencia a la Ventana principal
*/
static void infarg::refrescar_normal(void* user){
		((Arg_Window*)user)->disparar_normal();
}

/**
* @brief	Funciones disparadas por el Temporizador lento
*			al consumirse el tiempo
* @param	user	Referencia a la Ventana principal
*/
static void infarg::refrescar_lento(void* user){
	((Arg_Window*)user)->disparar_lento();
}

