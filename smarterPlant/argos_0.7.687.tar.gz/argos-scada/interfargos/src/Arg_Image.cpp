/**
* @file	Arg_Image.cpp
* @brief		<b>Tipo Abstracto de Dato (Widget) para el despliegue de
*				Imagenes de acuerdo a los valores de Tags y Alarmas.<br>
*				De acuerdo al resultado de evaluar la expresion, este
*				Widget puede desplegar tres imagenes distintas.<br>
*				Los Widgets son desarrollados para ser implementados
*				en interfARGOS (RAD basado en fluid) usando la
*				biblioteca grafica FLTK http://www.fltk.org </b><br>
* @author	    Alejandro Pina <ajpina@gmail.com><br>
* @link			http://www.cintal.com.ve/tecnologia/argos<br>
* @package      argos
* @access       public
* @version      1.0  -  01/06/09
*/

/*
Copyright (C) 2006 Alejandro Pina <ajpina@gmail.com>

Este programa es software libre. Puede redistribuirlo y/o modificarlo bajo
los terminos de la Licencia Publica General de GNU segun es publicada por
la Free Software Foundation, bien de la version 3 de dicha Licencia o bien
(segun su eleccion) de cualquier version posterior.

Este programa se distribuye con la esperanza de que sea util, pero
SIN NINGUNA GARANTIA, incluso sin la garantia MERCANTIL implicita o sin
garantizar la CONVENIENCIA PARA UN PROPOSITO PARTICULAR. Vease la Licencia
Publica General de GNU para mas detalles.

Deberia haber recibido una copia de la Licencia Publica General junto con
este programa. Si no ha sido asi, escriba a la Free Software Foundation, Inc.,
en 675 Mass Ave, Cambridge, MA 02139, EEUU.

Alejandro Pina mediante este documento renuncia a cualquier interes de derechos de
copyright con respecto al programa 'argos'.

01 de Noviembre de 2008

Por favor reporte cualquier fallo a la siguiente direccion:

	http://www.cintal.com.ve/tecnologia/argos

*/

#include "Arg_Image.h"

#include <iostream>

using namespace std;
namespace infarg{

/**
* @brief	Constructor del Objeto
* @param	x1		Posicion X del Widget
* @param	y1		Posicion Y del Widget
* @param	x2		Ancho del Widget
* @param	y2		Alto del Widget
* @param	l		Titulo del Widget
* @return	Referencia al Objeto
*/
Arg_Image::Arg_Image(int x1, int y1, int x2, int y2, const char *l = 0) : Fl_Box( x1, y1, x2, y2 ){
	fl_register_images();
	box(FL_THIN_DOWN_BOX);
	align(FL_ALIGN_INSIDE|FL_ALIGN_CENTER);
	img_actual = -1;
}

/**
* @brief	Constructor del Objeto
* @param	x1		Posicion X del Widget
* @param	y1		Posicion Y del Widget
* @param	x2		Ancho del Widget
* @param	y2		Alto del Widget
* @return	Referencia al Objeto
*/
Arg_Image::Arg_Image(int x1, int y1, int x2, int y2) : Fl_Box( x1, y1, x2, y2 ){
	fl_register_images();
	box(FL_THIN_DOWN_BOX);
	align(FL_ALIGN_INSIDE|FL_ALIGN_CENTER);
	img_actual = -1;
}

/**
* @brief	Asigna las rutas de las tres imagenes que seran
*			cargadas por el Widget
* @param	s1		Ruta de la imagen 1
* @param	s2		Ruta de la imagen 2
* @param	s3		Ruta de la imagen 3
*/
void Arg_Image::asignar_imagenes( string s1, string s2, string s3 ){
	path_img[0] = s1;
	path_img[1] = s2;
	path_img[2] = s3;
}

/**
* @brief	Despliega la Imagen correspondiente en el Widget
* @param	n		Numero de Imagen
*/
void Arg_Image::mostrar_imagen(short n ){
	if( n != 0 && n != 1 )
		n = 2;
	if( n == img_actual )
		return;
	img_actual = n;
	img = Fl_Shared_Image::get(path_img[n].c_str(), w(), h() );
	if( !img ){
		label("No Encontrada");
		labelsize(24);
		labelcolor(FL_LIGHT2);
		image(0);
	}
	else{
		image( img );
	}
	redraw();
}

/**
* @brief	Destructor por Defecto
*/
Arg_Image::~Arg_Image(){};

/**
* @brief	Actualiza la Imagen del Widget de acuerdo al
*			resultado de evaluar la expresion con los valores
*			recientes de los Tags y Alarmas
*/
void Arg_Image::refrescar(){
	double 		resultado;
	string		str_evaluar = expresion;
	try{
		parser.SetExpr( data->obtener_valores(str_evaluar) );
		resultado = parser.Eval();
		if( resultado == 0.0 )
			mostrar_imagen(0);
		else if( resultado == 1.0 )
			mostrar_imagen(1);
		else
			mostrar_imagen(-1);

	}catch (mu::Parser::exception_type &e){
		mostrar_imagen(-1);
	}
}

/**
* @brief	Asigna la expresion que debe evaluar el Widget
*			para desplegar la imagen correspondiente
* @param	str		Expresion
*/
void Arg_Image::asignar_expresion(std::string str){
	expresion = str;
}

}
