/**
* @file	Arg_Data.cpp
* @brief		<b>Tipo Abstracto de Dato para el acceso a los
*				Tags y las Alarmas desde los Widgets.<br>
*				Los Widgets son desarrollados para ser implementados
*				en interfARGOS (RAD basado en fluid) usando la
*				biblioteca grafica FLTK http://www.fltk.org </b><br>
* @author	    Alejandro Pina <ajpina@gmail.com><br>
* @link			http://www.cintal.com.ve/tecnologia/argos<br>
* @package      argos
* @access       public
* @version      1.0  -  01/06/09
*/

/*
Copyright (C) 2006 Alejandro Pina <ajpina@gmail.com>

Este programa es software libre. Puede redistribuirlo y/o modificarlo bajo
los terminos de la Licencia Publica General de GNU segun es publicada por
la Free Software Foundation, bien de la version 3 de dicha Licencia o bien
(segun su eleccion) de cualquier version posterior.

Este programa se distribuye con la esperanza de que sea util, pero
SIN NINGUNA GARANTIA, incluso sin la garantia MERCANTIL implicita o sin
garantizar la CONVENIENCIA PARA UN PROPOSITO PARTICULAR. Vease la Licencia
Publica General de GNU para mas detalles.

Deberia haber recibido una copia de la Licencia Publica General junto con
este programa. Si no ha sido asi, escriba a la Free Software Foundation, Inc.,
en 675 Mass Ave, Cambridge, MA 02139, EEUU.

Alejandro Pina mediante este documento renuncia a cualquier interes de derechos de
copyright con respecto al programa 'argos'.

01 de Noviembre de 2008

Por favor reporte cualquier fallo a la siguiente direccion:

	http://www.cintal.com.ve/tecnologia/argos

*/

#include "Arg_Data.h"
#include "as-tags.h"
#include "as-util.h"

namespace infarg{

/**
* @brief	Constructor por Defecto
* @return	Referencia al Objeto
*/
Arg_Data::Arg_Data(){
}

/**
* @brief	Constructor del Objeto
* @param	shm_tags		Nombre de Memoria Compartida de Tags
* @param	shm_alarmas		Nombre de Memoria Compartida de Alarmas
* @return	Referencia al Objeto
*/
Arg_Data::Arg_Data(std::string shm_tags, std::string shm_alarmas){
	if( !shm_tags.empty() ){
		shm_th_t.inicializar_shm_thtag(shm_tags);
		shm_th_t.obtener_shm_tablahash();
	}
	if( !shm_alarmas.empty() ){
		shm_th_a.inicializar_shm_thalarma(shm_alarmas);
		shm_th_a.obtener_shm_tablahash();
	}
}

/**
* @brief	Destructor por Defecto, cierra las Memorias Compartidas
*/
Arg_Data::~Arg_Data(){
		shm_th_t.cerrar_shm_tablahash();
		shm_th_a.cerrar_shm_tablahash();
}

/**
* @brief	Permite usar muparser para analizar operaciones aritmeticas
*			con los valores de los Tags o Alarmas
* @param	expresion		Expresion para Analizar
* @return	expresion		Resultado de la Expresion
*/
std::string Arg_Data::obtener_valores( std::string expresion ){
	size_t 			amp,
					blank,
					longitud;
	std::string		nombre,
					to_replace,
					str_valor;
	argos::tags		*t;

	for( amp = expresion.find("$", 0); amp != std::string::npos ; amp = expresion.find("$", amp) ){
		blank = expresion.find_first_of( ") }]+*-%/;=!&><", amp + 1 );
		if( blank != std::string::npos ){
			nombre = expresion.substr(amp + 1, blank - amp - 1);
			t = shm_th_t.buscar_tag( nombre );
			if(!t)
				return "";
			longitud = blank - amp;
		}
		else{
			nombre = expresion.substr(amp + 1, expresion.length() - amp - 1);
			t = shm_th_t.buscar_tag( nombre );
			if(!t)
				return "";
			longitud = expresion.length() - amp;
		}
		if( t != NULL ){
			switch(t->tipo){
				case CARAC_:
					to_replace = numero2string<char>( t->valor_campo.C, std::dec );
				break;
				case CORTO_:
					to_replace = numero2string<short>( t->valor_campo.S, std::dec );
				break;
				case ENTERO_:
					to_replace = numero2string<int>( t->valor_campo.I, std::dec );
				break;
				case LARGO_:
					to_replace = numero2string<__int64_t>( t->valor_campo.L, std::dec );
				break;
				case DREAL_:
					to_replace = numero2string<double>( t->valor_campo.D, std::dec );
				break;
				case BIT_:
					to_replace = numero2string<bool>( t->valor_campo.B, std::dec );
				break;
				case REAL_:
					to_replace = numero2string<float>( t->valor_campo.F, std::dec );
				break;
				case TERROR_:
				default:
					to_replace = numero2string<__int64_t>( _ERR_DATO_, std::hex );
			}
			expresion.replace( amp, longitud, to_replace );
		}
		amp++;
	}
	return expresion;
}


}
