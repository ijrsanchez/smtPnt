/**
* @file	Arg_SVG_Box.cpp
* @brief		<b>Tipo Abstracto de Dato (Widget) para el despliegue de
*				Imagenes con formato SVG.<br>
*				Los Widgets son desarrollados para ser implementados
*				en interfARGOS (RAD basado en fluid) usando la
*				biblioteca grafica FLTK http://www.fltk.org </b><br>
* @author	    Alejandro Pina <ajpina@gmail.com><br>
* @link			http://www.cintal.com.ve/tecnologia/argos<br>
* @package      argos
* @access       public
* @version      1.0  -  01/06/09
*/

/*
Copyright (C) 2006 Alejandro Pina <ajpina@gmail.com>

Este programa es software libre. Puede redistribuirlo y/o modificarlo bajo
los terminos de la Licencia Publica General de GNU segun es publicada por
la Free Software Foundation, bien de la version 3 de dicha Licencia o bien
(segun su eleccion) de cualquier version posterior.

Este programa se distribuye con la esperanza de que sea util, pero
SIN NINGUNA GARANTIA, incluso sin la garantia MERCANTIL implicita o sin
garantizar la CONVENIENCIA PARA UN PROPOSITO PARTICULAR. Vease la Licencia
Publica General de GNU para mas detalles.

Deberia haber recibido una copia de la Licencia Publica General junto con
este programa. Si no ha sido asi, escriba a la Free Software Foundation, Inc.,
en 675 Mass Ave, Cambridge, MA 02139, EEUU.

Alejandro Pina mediante este documento renuncia a cualquier interes de derechos de
copyright con respecto al programa 'argos'.

01 de Noviembre de 2008

Por favor reporte cualquier fallo a la siguiente direccion:

	http://www.cintal.com.ve/tecnologia/argos

*/


#include "Arg_SVG_Box.h"
#include <FL/fl_draw.H>

namespace infarg{

int Arg_SVG_Box::counter_ = 0;

/**
 * @brief	Construye un Box a partir de una imagen con formato SVG o SVGZ
 * @param image	Widget con la Imagen en SVG o SVGZ.
 * @param a			?
 * @param b			?
 * @param c			?
 * @param d			?
 */
Arg_SVG_Box::Arg_SVG_Box(Arg_SVG_Image* image, uchar a, uchar b, uchar c, uchar d)
      : image_(image)
{
   // mutex lock?
   counter_++;
   id_ = counter_;
	//Fl::set_boxtype((Fl_Boxtype)(FL_FREE_BOXTYPE + 8 + id_), draw_svg_box, a, b, c, d, this);
}

/**
 * @brief	Destructor por defecto
 */
Arg_SVG_Box::~Arg_SVG_Box()
{
   if (image_)
      delete image_;
}

/**
 * @brief	Dibuja la imagen dentro de un Box
 * @param x			Posicion X
 * @param y			Posicion Y
 * @param w			Ancho inicial
 * @param h			Alto inicial
 * @param bgcolor	Color de Fondo
 * @param o			?
 */
void Arg_SVG_Box::draw_svg_box(int x, int y, int w, int h, Fl_Color bgcolor, void* o)
{
   Arg_SVG_Image* img = (Arg_SVG_Image*)o;
   img->size(w, h);
   img->draw(x, y, w, h, 0, 0);
}

}

