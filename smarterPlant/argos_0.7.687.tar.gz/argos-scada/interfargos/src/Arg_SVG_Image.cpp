/**
* @file	Arg_SVG_Image.cpp
* @brief		<b>Tipo Abstracto de Dato (Widget) para el despliegue de
*				Imagenes con formato SVG.<br>
*				Los Widgets son desarrollados para ser implementados
*				en interfARGOS (RAD basado en fluid) usando la
*				biblioteca grafica FLTK http://www.fltk.org </b><br>
* @author	    Alejandro Pina <ajpina@gmail.com><br>
* @link			http://www.cintal.com.ve/tecnologia/argos<br>
* @package      argos
* @access       public
* @version      1.0  -  01/06/09
*/

/*
Copyright (C) 2006 Alejandro Pina <ajpina@gmail.com>

Este programa es software libre. Puede redistribuirlo y/o modificarlo bajo
los terminos de la Licencia Publica General de GNU segun es publicada por
la Free Software Foundation, bien de la version 3 de dicha Licencia o bien
(segun su eleccion) de cualquier version posterior.

Este programa se distribuye con la esperanza de que sea util, pero
SIN NINGUNA GARANTIA, incluso sin la garantia MERCANTIL implicita o sin
garantizar la CONVENIENCIA PARA UN PROPOSITO PARTICULAR. Vease la Licencia
Publica General de GNU para mas detalles.

Deberia haber recibido una copia de la Licencia Publica General junto con
este programa. Si no ha sido asi, escriba a la Free Software Foundation, Inc.,
en 675 Mass Ave, Cambridge, MA 02139, EEUU.

Alejandro Pina mediante este documento renuncia a cualquier interes de derechos de
copyright con respecto al programa 'argos'.

01 de Noviembre de 2008

Por favor reporte cualquier fallo a la siguiente direccion:

	http://www.cintal.com.ve/tecnologia/argos

*/

//----------------------------------------------------------
// *) 30 Noviembre 2009
// 			Utiliza codigo de FLTK Imago - Chris Osgood 2002-2005
// 			http://imago.functionalfuture.com/
//
//----------------------------------------------------------

#include "Arg_SVG_Image.h"

#include <FL/Fl.H>
#include <FL/fl_draw.H>
#include <fcntl.h>
#include <sys/stat.h>
#include <zlib.h>
#include <string.h>
#include <cairo-svg.h>
#include <rsvg.h>
#include <rsvg-cairo.h>
#ifdef _WIN32
#include <io.h>
#else
#include <unistd.h>
#endif

namespace infarg{

/**
 * @brief	Constructor.  La principal diferencia entre esto y una imagen
 * normal es que los graficos SVG no tienen un tamano especifico y el
 * tamano puede ser especificado aqui.
 * @param bits	Datos del archivo SVG. Puede ser en texto XML en SVG o SVGZ.
 * @param len		Longitud de los datos
 * @param W			Ancho inicial
 * @param H			Alto inicial
 * @param c			Color de fondo (used to blend with translucent areas of image)
 */
Arg_SVG_Image::Arg_SVG_Image(const char* bits, size_t len, int W, int H, Fl_Color c)
    : Fl_RGB_Image(0,W,H,4,0), svgcontext_(0), draw_width_(0), draw_height_(0), bgcolor_(c), draw_bg_(c) {
    if (svgdata(bits, len) != 0) {
        destroy();
        return;
    }
}

/**
 * @brief	Constructor para leer desde el archivo.
 * @param filename	Archivo SVG, soporta formato SVGZ gzip o SVG.
 * @param W					Ancho inicial
 * @param H					Alto inicial
 * @param c					Color de fondo (used to blend with translucent areas of image)
 */
Arg_SVG_Image::Arg_SVG_Image(const char* filename, int W, int H, Fl_Color c)
    : Fl_RGB_Image(0,W,H,4,0), svgcontext_(0), draw_width_(0), draw_height_(0), bgcolor_(c), draw_bg_(c) {
    int fd = open(filename, O_RDONLY);
    if (fd == -1)
        return;

    char* bits = 0;

    try {
        struct stat stat;
        if (fstat(fd, &stat) != 0)
            throw(0);

        bits = new char[stat.st_size];
        if (!bits)
            throw(0);

        if (read(fd, bits, stat.st_size) != stat.st_size)
            throw(0);

        if (svgdata(bits, stat.st_size) != 0)
            throw(0);
    } catch(int) {
        destroy();
    }

    if (bits)
        delete [] bits;

    close(fd);
}

/**
 * @brief	Destructor por defecto
 */
Arg_SVG_Image::~Arg_SVG_Image() {
    destroy();
}

/**
 * @brief	Limpia el estado actual, liberando memoria, etc.
 */
void Arg_SVG_Image::destroy() {
    if (svgcontext_) {
        rsvg_handle_free((RsvgHandle *)svgcontext_);
        rsvg_term();
        svgcontext_ = 0;
    }

    if (array && alloc_array) {
        delete [] array;
        array = 0;
        alloc_array = 0;
    }

    draw_width_ = 0;
    draw_height_ = 0;
}

/**
 * @brief	Analiza los datos SVG para generar la imagen
 * @param data	Datos SVG(gzip o texto XML)
 * @param len		Longitud de los datos
 * @return 0 		Exitoso
 */
int Arg_SVG_Image::svgdata(const char* data, size_t len) {
    int 									rv = 0;
    bool 									free_mem = false;
    const char						*decompressed = 0;

    try {
        destroy();

        RsvgHandle				*svgHandle = NULL;
        GError 						*pError = NULL;
        RsvgDimensionData	svgDimension;
        rsvg_init();

        decompressed = decompGZ(data, len);
        if (!decompressed)
            decompressed = data;
        else {
            free_mem = true;
            len = strlen(decompressed);
        }

        svgHandle = rsvg_handle_new_from_data((const guint8 *)decompressed, len, &pError);
        svgcontext_ = svgHandle;
        if(pError != NULL) {
            rv = -1;
            throw(0);
        }
        rsvg_handle_get_dimensions(svgHandle, &svgDimension);
        pt_width_ = svgDimension.width;
        pt_height_ = svgDimension.height;

        if (!w())
            w(pt_width_);

        if (!h())
            h(pt_height_);
    } catch(int) {
    }

    if (decompressed && free_mem)
        delete [] decompressed;

		len_ = len;

    return rv;
}

/**
 * @brief metodo FLTK draw().  Reconstruye la imagen si cambian las dimensiones
 * SVG permite un renderizado a cualquier tamano.
 * This caches the generated image so that the SVG data does not need to be
 * reparsed and rescaled every time the image is drawn.
 * @param XP posicion X
 * @param YP posicion Y
 * @param WP Ancho del Dibujo
 * @param HP Alto del Dibujo
 * @param cx ?? fltk option.. maybe clip x?
 * @param cy ?? fltk option.. maybe clip y?
 */
void Arg_SVG_Image::draw(int XP, int YP, int WP, int HP, int cx, int cy) {
    if (WP <=0 || HP <= 0)
        return;

    if (!svgcontext_) {
        draw_empty(XP, YP);
        return;
    }

    // Si la version en cache contiene las mismas dimensiones se salta
    // este paso
    if (draw_width_ != WP || draw_height_ != HP || draw_bg_ != bgcolor_) {
        uncache();

        w(WP);
        h(HP);

        if (array && alloc_array)
            delete [] array;

        size_t array_size = WP * HP * d();
        array = new uchar[array_size];

        data((const char **)&array, 1);

        if (!array) {
            alloc_array = 0;
            draw_empty(XP, YP);
            return;
        }

        memset(const_cast<uchar*>(array), 0x00, array_size);
        alloc_array = 1;

        unsigned int 			base_width,
        									base_height;
        RsvgDimensionData	svgDimension;

        rsvg_handle_get_dimensions( (RsvgHandle *)svgcontext_, &svgDimension);

        base_width = svgDimension.width;
        base_height = svgDimension.height;

        cairo_surface_t *surface = cairo_image_surface_create_for_data ((unsigned char*)array, CAIRO_FORMAT_ARGB32, WP * 4, HP, WP * 4);

        if(surface) {
            cairo_t* render_context = cairo_create( surface );
            cairo_scale(render_context, (double)WP/(double)base_width, (double)HP/(double)base_height);
            cairo_surface_destroy(surface);
            rsvg_handle_render_cairo((RsvgHandle *)svgcontext_, render_context);
            cairo_surface_flush(surface);
            if (cairo_status(render_context) != CAIRO_STATUS_SUCCESS) {
                cairo_destroy(render_context);
                draw_empty(XP, YP);
            }
            else{
            	cairo_destroy(render_context);
            }
        }

        draw_width_ = WP;
        draw_height_ = HP;
        draw_bg_ = bgcolor_;

        {
            int i, j;
            uchar* pos = const_cast<uchar*>(array), temp;
            for (i = 0; i < HP; i++) {
                for (j = 0; j < WP; j++) {
#ifdef __APPLE__
                    // Convert ARGB to RGBA
                    temp = pos[0];
                    (*((unsigned int*)pos)) <<= 8;
                    pos[3] = temp;
#else
                    // Convert BGRA to RGBA
                    temp = pos[0];
                    pos[0] = pos[2];
                    pos[2] = temp;
#endif
                    pos += 4;
                }
            }
        }

#ifndef HARDWARE_ALPHA

        {
            int i, j;
            uchar r, g, b;

            Fl::get_color(bgcolor_, r, g, b);

            uchar* pos = const_cast<uchar*>(array);
#define ALPHA_INDEX 3
#define char_max(x) ((uchar)(((x)>0xFF)?0xFF:(x)))

            for (i = 0; i < HP; i++)
                for (j = 0; j < WP; j++) {
                    if (pos[ALPHA_INDEX] != 0xFF && pos[ALPHA_INDEX] != 0x00) {
                        float alpha1 = (float)pos[ALPHA_INDEX] / 255.0f;
                        float alpha2 = 1.0f - alpha1;
                        *pos = char_max((int)((float)*pos * alpha1 + (float)r * alpha2)); // red
                        pos++;
                        *pos = char_max((int)((float)*pos * alpha1 + (float)g * alpha2)); // green
                        pos++;
                        *pos = char_max((int)((float)*pos * alpha1 + (float)b * alpha2)); // blue
                        pos++;
                        *pos = 0xFF; // Alpha value
                        pos++;
                        continue;
                    }

                    pos += 4;
                }
        }
#endif // HARDWARE_ALPHA
    }
    Fl_RGB_Image::draw(XP, YP, WP, HP, cx, cy);
}


/**
 * @brief	Callback interna para operar con zlib
 * @param in		Input data (compressed with gzip)
 * @param size	Length of input data
 * @return Returns SVG text file (be sure to delete [] it) or null if error
 */
static void* zalloc_func(void*, unsigned int items, unsigned int size) {
    return new char[items * size];
}

/**
 * @brief	Callback interna para operar con zlib
 * @param in		Input data (compressed with gzip)
 * @param size	Length of input data
 * @return Returns SVG text file (be sure to delete [] it) or null if error
 */
static void zfree_func(void*, void* address) {
    delete [] (char*)address;
}

/**
 * @brief	Descomprime usando GZip para archivos SVGZ
 * @param in		Datos (comprimidos con gzip)
 * @param size 	Longitud de los datos
 * @return Returns Archivo SVG (be sure to delete [] it) or null if error
 */
char* Arg_SVG_Image::decompGZ(const char* in, size_t size) {
    uchar t_buf[32768]; // Fairly large chunk size.. SVG files can be really big
    uchar* out_buf = 0;
    size_t alloc_size = 0;
    z_stream s;
    int rv;

    s.zalloc = zalloc_func;
    s.zfree = zfree_func;
    s.opaque = 0;
    s.next_in = (Bytef*)in;
    s.avail_in = size;

    rv = inflateInit2(&s, 0x2F);
    if (rv != Z_OK)
        return 0;

    while(1) {
        s.next_out = t_buf;
        s.avail_out = sizeof(t_buf);

        rv = inflate(&s, Z_FULL_FLUSH);

        size_t num = sizeof(t_buf) - s.avail_out;
        uchar* new_buf = new uchar[alloc_size + num + 1];
        if (!new_buf)
            break;

        if (alloc_size)
            memcpy(new_buf, out_buf, alloc_size);

        memcpy(&new_buf[alloc_size], t_buf, num);

        if (out_buf)
            delete [] out_buf;

        out_buf = new_buf;
        alloc_size += num;

        if (rv == Z_STREAM_END) {
            inflateEnd(&s);
            out_buf[alloc_size] = 0x00;
            return reinterpret_cast<char*>(out_buf);
        } else if (rv != Z_OK)
            break;
    }

    if (out_buf)
        delete [] out_buf;

    inflateEnd(&s);

    return 0;
}

/**
 * @brief	Tests to see if a particular x/y coordinate "hit" the image in a non-
 * transparent part.  It might be worthwhile to make this inline by
 * moving it to the header.
 * @param at_x X coordinate
 * @param at_y Y coordinate
 * @param thresh Alpha threshold (0-255; 255 is fully opaque; 1 is default)
 */
bool Arg_SVG_Image::hit(int at_x, int at_y, int thresh) {
    if (d() < 4)
        return true;
    else if (at_x < 0 || at_x >= w() || at_y < 0 || at_y >= h())
        return false;
    else if (array && array[(at_y * (w()*d()) + (at_x*d()) + (d()-1))] > thresh)
        return true;
    else
        return false;
}

}
