/**
* @file	Arg_SVG_Button.cpp
* @brief		<b>Tipo Abstracto de Dato (Widget) para el despliegue de
*				Botones con Imagenes con formato SVG.<br>
*				Los Widgets son desarrollados para ser implementados
*				en interfARGOS (RAD basado en fluid) usando la
*				biblioteca grafica FLTK http://www.fltk.org </b><br>
* @author	    Alejandro Pina <ajpina@gmail.com><br>
* @link			http://www.cintal.com.ve/tecnologia/argos<br>
* @package      argos
* @access       public
* @version      1.0  -  01/06/09
*/

/*
Copyright (C) 2006 Alejandro Pina <ajpina@gmail.com>

Este programa es software libre. Puede redistribuirlo y/o modificarlo bajo
los terminos de la Licencia Publica General de GNU segun es publicada por
la Free Software Foundation, bien de la version 3 de dicha Licencia o bien
(segun su eleccion) de cualquier version posterior.

Este programa se distribuye con la esperanza de que sea util, pero
SIN NINGUNA GARANTIA, incluso sin la garantia MERCANTIL implicita o sin
garantizar la CONVENIENCIA PARA UN PROPOSITO PARTICULAR. Vease la Licencia
Publica General de GNU para mas detalles.

Deberia haber recibido una copia de la Licencia Publica General junto con
este programa. Si no ha sido asi, escriba a la Free Software Foundation, Inc.,
en 675 Mass Ave, Cambridge, MA 02139, EEUU.

Alejandro Pina mediante este documento renuncia a cualquier interes de derechos de
copyright con respecto al programa 'argos'.

01 de Noviembre de 2008

Por favor reporte cualquier fallo a la siguiente direccion:

	http://www.cintal.com.ve/tecnologia/argos

*/

//----------------------------------------------------------
// *) 30 Noviembre 2009
// 			Utiliza codigo de FLTK Imago - Chris Osgood 2002-2005
// 			http://imago.functionalfuture.com/
//
//----------------------------------------------------------

#ifdef _WIN32
// The following include is a nasty little hack for Windows; otherwise you will
// get unresolved symbols from the Fl:: class.  This basically applies
// __declspec(dllimport) to "class Fl".  However, you can't just define FL_DLL
// for the whole project  otherwise you will get multiple symbols.  This is
// partly the fault of the MS compiler but it could be fixed in FLTK.
#define FL_DLL
#include <FL/Fl.H>
#undef FL_DLL
#undef FL_EXPORT
#undef Fl_Export_H
#include <FL/Fl_Export.H>
#else
#include <FL/Fl.H>
#endif

#include <FL/fl_draw.H>
#include "Arg_SVG_Button.h"

namespace infarg{

/**
 * @brief	Constructor de botones con imagenes SVG o SVGZ
 * @param X Posicion X
 * @param Y Posicion Y
 * @param W Ancho
 * @param H Alto
 * @param label Etiqueta
 */
Arg_SVG_Button::Arg_SVG_Button(int X, int Y, int W, int H, const char* label)
   : Fl_Button(X, Y, W, H, label), down_image_(0), focus_image_(0),
     highlight_image_(0), focus_highlight_(false)
{
}

/**
 * Destructor por defecto
 */
Arg_SVG_Button::~Arg_SVG_Button()
{
   if (up_image_)
      delete up_image_;

   if (down_image_)
      delete down_image_;

   if (focus_image_)
      delete focus_image_;

   if (highlight_image_)
      delete highlight_image_;
}

/**
 * @brief Asigna la imagen para el boton en estado normal
 * @param img Imagen
 */
void Arg_SVG_Button::up_image(Arg_SVG_Image* img)
{
   img->size(w(), h());
   img->bgcolor(color());
   up_image_ = img;
}

/**
 * @brief Asigna la imagen para el boton en estado presionado
 * @param img Imagen
 */
void Arg_SVG_Button::down_image(Arg_SVG_Image* img)
{
   img->size(w(), h());
   img->bgcolor(color());
   down_image_ = img;
}

/**
 * @brief Asigna la imagen para el boton cuando obtiene foco
 * @param img Imagen
 */
void Arg_SVG_Button::focus_image(Arg_SVG_Image* img)
{
   img->size(w(), h());
   img->bgcolor(color());
   focus_image_ = img;
}

/**
 * @brief Asigna la imagen para el boton cuando el puntero del raton
 *				pasa sobre el widget
 * @param img Imagen
 */
void Arg_SVG_Button::highlight_image(Arg_SVG_Image* img)
{
   img->size(w(), h());
   img->bgcolor(color());
   highlight_image_ = img;
}

/**
 * @brief metodo FLTK draw().
 */
void Arg_SVG_Button::draw()
{
   if (type() == FL_HIDDEN_BUTTON) return;
   Fl_Color col = value() ? selection_color() : color();

   draw_box(FL_FLAT_BOX, col);

   fl_push_clip(x(), y(), w(), h());

   if (value() && down_image_)
      down_image_->draw(x(), y(), w()-3, h()-3, 0, 0);
   else if (focus_highlight_ && focus_image_)
      focus_image_->draw(x(), y(), w()-3, h()-3, 0, 0);
   else if (up_image_)
      up_image_->draw(x(), y(), w()-3, h()-3, 0, 0);

   draw_label();

   //if (Fl::focus() == this && focus_image_)
   //   focus_image_->draw(x(), y(), w()-3, h()-3, 0, 0);

   fl_pop_clip();
}

/**
 * @brief	Manejador de eventos
 * @param event Evento
 * @return Standard event handler return value
 */
int Arg_SVG_Button::handle(int event)
{
   switch (event)
   {
   case FL_PUSH:
   case FL_DRAG:
   case FL_RELEASE:
      {
         Arg_SVG_Image* img = value() ? down_image_ : up_image_;

         if (!img->hit(Fl::event_x() - x(), Fl::event_y() - y(), 120))
         {
            value(0);
            return 0;
         }
         break;
      }
   case FL_MOVE:
      if (focus_image_)
      {
         if (up_image_->hit(Fl::event_x() - x(), Fl::event_y() - y(), 120))
         {
            if (!focus_highlight_)
            {
               focus_highlight_ = true;
               redraw();
            }
         }
         else if (focus_highlight_)
         {
            focus_highlight_ = false;
            redraw();
         }
      }
      break;
   case FL_LEAVE:
      if (focus_highlight_)
      {
         focus_highlight_ = false;
         redraw();
      }
      break;
   default:
      break;
   }

   return Fl_Button::handle(event);
}

}

