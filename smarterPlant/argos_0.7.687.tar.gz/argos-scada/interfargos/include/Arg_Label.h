/**
* @file	Arg_Label.h
* @class Arg_Label
* @brief		<b>Tipo Abstracto de Dato (Widget) para el despliegue
*				textual de los valores de Tags y Alarmas.<br>
*				Este Widget despliega el valor resultado de evaluar
*				la expresion.<br>
*				Los Widgets son desarrollados para ser implementados
*				en interfARGOS (RAD basado en fluid) usando la
*				biblioteca grafica FLTK http://www.fltk.org </b><br>
* @author	    Alejandro Pina <ajpina@gmail.com><br>
* @link			http://www.cintal.com.ve/tecnologia/argos<br>
* @package      argos
* @access       public
* @version      1.0  -  01/06/09
*/

/*
Copyright (C) 2006 Alejandro Pina <ajpina@gmail.com>

Este programa es software libre. Puede redistribuirlo y/o modificarlo bajo
los terminos de la Licencia Publica General de GNU segun es publicada por
la Free Software Foundation, bien de la version 3 de dicha Licencia o bien
(segun su eleccion) de cualquier version posterior.

Este programa se distribuye con la esperanza de que sea util, pero
SIN NINGUNA GARANTIA, incluso sin la garantia MERCANTIL implicita o sin
garantizar la CONVENIENCIA PARA UN PROPOSITO PARTICULAR. Vease la Licencia
Publica General de GNU para mas detalles.

Deberia haber recibido una copia de la Licencia Publica General junto con
este programa. Si no ha sido asi, escriba a la Free Software Foundation, Inc.,
en 675 Mass Ave, Cambridge, MA 02139, EEUU.

Alejandro Pina mediante este documento renuncia a cualquier interes de derechos de
copyright con respecto al programa 'argos'.

01 de Noviembre de 2008

Por favor reporte cualquier fallo a la siguiente direccion:

	http://www.cintal.com.ve/tecnologia/argos

*/

#ifndef ARG_LABEL_H_
#define ARG_LABEL_H_

#include <FL/Fl.H>
#include <FL/Fl_Output.H>

#include "Arg_Widget.h"

namespace infarg{

class Arg_Label : public Fl_Output, public Arg_Widget {
  public:
	Arg_Label(int , int , int , int , const char *);
	Arg_Label(int , int , int , int);
	~Arg_Label();

/*--------------------------------------------------------
	Actualiza el Texto del Widget de acuerdo al
	resultado de evaluar la expresion con los valores
	recientes de los Tags y Alarmas
----------------------------------------------------------*/
	void refrescar();

/*--------------------------------------------------------
	Asigna la expresion que debe evaluar el Widget
	para desplegar el valor correspondiente
----------------------------------------------------------*/
	void asignar_expresion(std::string);
};



}

#endif
