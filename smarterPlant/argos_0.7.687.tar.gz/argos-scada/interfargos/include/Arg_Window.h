/**
* @file	Arg_Window.cpp
* @class Arg_Window
* @brief		<b>Tipo Abstracto de Dato (Widget) para contener a
*				traves de una Ventana los demas Widgets.<br>
*				Este Widget contiene tres temporizadores los
*				cuales disparan los eventos para actualizar los
*				demas objetos que se agreguen a la Ventana.<br>
*				Los Widgets son desarrollados para ser implementados
*				en interfARGOS (RAD basado en fluid) usando la
*				biblioteca grafica FLTK http://www.fltk.org </b><br>
* @author	    Alejandro Pina <ajpina@gmail.com><br>
* @link			http://www.cintal.com.ve/tecnologia/argos<br>
* @package      argos
* @access       public
* @version      1.0  -  01/06/09
*/

/*
Copyright (C) 2006 Alejandro Pina <ajpina@gmail.com>

Este programa es software libre. Puede redistribuirlo y/o modificarlo bajo
los terminos de la Licencia Publica General de GNU segun es publicada por
la Free Software Foundation, bien de la version 3 de dicha Licencia o bien
(segun su eleccion) de cualquier version posterior.

Este programa se distribuye con la esperanza de que sea util, pero
SIN NINGUNA GARANTIA, incluso sin la garantia MERCANTIL implicita o sin
garantizar la CONVENIENCIA PARA UN PROPOSITO PARTICULAR. Vease la Licencia
Publica General de GNU para mas detalles.

Deberia haber recibido una copia de la Licencia Publica General junto con
este programa. Si no ha sido asi, escriba a la Free Software Foundation, Inc.,
en 675 Mass Ave, Cambridge, MA 02139, EEUU.

Alejandro Pina mediante este documento renuncia a cualquier interes de derechos de
copyright con respecto al programa 'argos'.

01 de Noviembre de 2008

Por favor reporte cualquier fallo a la siguiente direccion:

	http://www.cintal.com.ve/tecnologia/argos

*/

#ifndef ARG_WINDOW_H_
#define ARG_WINDOW_H_

#include <FL/Fl.H>
#include <FL/Fl_Double_Window.H>
#include <FL/Fl_Widget.H>

#include <cstdio>
#include <list>
#include <string>

#include "Arg_Widget.h"
#include "Arg_Data.h"

using namespace std;

namespace infarg{

class Arg_Window : public Fl_Double_Window{
private:
	list <Arg_Widget *>		l_rapido;		//!< Listado de Widgets con Temporizado rapido
	list <Arg_Widget *>		l_normal;		//!< Listado de Widgets con Temporizado normal
	list <Arg_Widget *>		l_lento;		//!< Listado de Widgets con Temporizado lento
	Arg_Data *				data;			//!< Referencia a la Memoria de Compartida de Tags y Alarmas

public:
	Arg_Window(int , int , std::string , std::string );
	Arg_Window(int , int);
	~Arg_Window();

/*--------------------------------------------------------
	Registra tres temporizadores y las memorias compartidas
	para el acceso a Tags y Alarmas
----------------------------------------------------------*/
	void agregar_timeout( std::string , std::string );

/*--------------------------------------------------------
	Asigna el Temporizado a un Widget que es
	contenido dentro de la Ventana, para que el
	Temporizado dispare eventos que permitan refrescar
	el Widget
----------------------------------------------------------*/
	void registrar_timer_rapido(Arg_Widget *);
	void registrar_timer_normal(Arg_Widget *);
	void registrar_timer_lento(Arg_Widget *);

/*--------------------------------------------------------
	Al consumirse el tiempo del Temporizado rapido se
	dispara un evento para que los Widgets sean
	refrescados con valores recientes de Tags y Alarmas
----------------------------------------------------------*/
	void disparar_rapido();
	void disparar_normal();
	void disparar_lento();
};

/*--------------------------------------------------------
	Funciones disparadas por el Temporizador
	al consumirse el tiempo
----------------------------------------------------------*/
static void refrescar_rapido(void *);
static void refrescar_normal(void *);
static void refrescar_lento(void *);

}

#endif
