/**
* @file	Arg_SVG_Box.h
*	@class	Arg_SVG_Box
* @brief		<b>Tipo Abstracto de Dato (Widget) para el despliegue de
*				Imagenes con formato SVG.<br>
*				Los Widgets son desarrollados para ser implementados
*				en interfARGOS (RAD basado en fluid) usando la
*				biblioteca grafica FLTK http://www.fltk.org </b><br>
* @author	    Alejandro Pina <ajpina@gmail.com><br>
* @link			http://www.cintal.com.ve/tecnologia/argos<br>
* @package      argos
* @access       public
* @version      1.0  -  01/06/09
*/

/*
Copyright (C) 2006 Alejandro Pina <ajpina@gmail.com>

Este programa es software libre. Puede redistribuirlo y/o modificarlo bajo
los terminos de la Licencia Publica General de GNU segun es publicada por
la Free Software Foundation, bien de la version 3 de dicha Licencia o bien
(segun su eleccion) de cualquier version posterior.

Este programa se distribuye con la esperanza de que sea util, pero
SIN NINGUNA GARANTIA, incluso sin la garantia MERCANTIL implicita o sin
garantizar la CONVENIENCIA PARA UN PROPOSITO PARTICULAR. Vease la Licencia
Publica General de GNU para mas detalles.

Deberia haber recibido una copia de la Licencia Publica General junto con
este programa. Si no ha sido asi, escriba a la Free Software Foundation, Inc.,
en 675 Mass Ave, Cambridge, MA 02139, EEUU.

Alejandro Pina mediante este documento renuncia a cualquier interes de derechos de
copyright con respecto al programa 'argos'.

01 de Noviembre de 2008

Por favor reporte cualquier fallo a la siguiente direccion:

	http://www.cintal.com.ve/tecnologia/argos

*/

//----------------------------------------------------------
// *) 30 Noviembre 2009
// 			Utiliza codigo de FLTK Imago - Chris Osgood 2002-2005
// 			http://imago.functionalfuture.com/
//
//----------------------------------------------------------


#ifndef ARG_SVG_BOX_H
#define ARG_SVG_BOX_H


#include <FL/Fl.H>
#include "Arg_SVG_Image.h"

namespace infarg{

class Arg_SVG_Box {
private:
    static int counter_;				//!< ???
    Arg_SVG_Image* image_;			//!< Imagen para archivos SVG o SVGZ
    int id_;										//!< Identificador

public:
    Arg_SVG_Box(Arg_SVG_Image* image, uchar a, uchar b, uchar c, uchar d);
    ~Arg_SVG_Box();

/*--------------------------------------------------------
	Tipo de Widget FLTK
----------------------------------------------------------*/
    Fl_Boxtype type() {
        return (Fl_Boxtype)(FL_FREE_BOXTYPE + 8 + id_);
    }

protected:

/*--------------------------------------------------------
	Dibujo del Box
----------------------------------------------------------*/
    static void draw_svg_box(int x, int y, int w, int h, Fl_Color bgcolor, void* o);
};

}

#endif // ARG_SVG_BOX_H

