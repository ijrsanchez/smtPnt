/**
* @file	Arg_SVG_Image.h
* @class Arg_Image
* @brief		<b>Tipo Abstracto de Dato (Widget) para el despliegue de
*				Imagenes con formato SVG.<br>
*				Los Widgets son desarrollados para ser implementados
*				en interfARGOS (RAD basado en fluid) usando la
*				biblioteca grafica FLTK http://www.fltk.org </b><br>
* @author	    Alejandro Pina <ajpina@gmail.com><br>
* @link			http://www.cintal.com.ve/tecnologia/argos<br>
* @package      argos
* @access       public
* @version      1.0  -  01/06/09
*/

/*
Copyright (C) 2006 Alejandro Pina <ajpina@gmail.com>

Este programa es software libre. Puede redistribuirlo y/o modificarlo bajo
los terminos de la Licencia Publica General de GNU segun es publicada por
la Free Software Foundation, bien de la version 3 de dicha Licencia o bien
(segun su eleccion) de cualquier version posterior.

Este programa se distribuye con la esperanza de que sea util, pero
SIN NINGUNA GARANTIA, incluso sin la garantia MERCANTIL implicita o sin
garantizar la CONVENIENCIA PARA UN PROPOSITO PARTICULAR. Vease la Licencia
Publica General de GNU para mas detalles.

Deberia haber recibido una copia de la Licencia Publica General junto con
este programa. Si no ha sido asi, escriba a la Free Software Foundation, Inc.,
en 675 Mass Ave, Cambridge, MA 02139, EEUU.

Alejandro Pina mediante este documento renuncia a cualquier interes de derechos de
copyright con respecto al programa 'argos'.

01 de Noviembre de 2008

Por favor reporte cualquier fallo a la siguiente direccion:

	http://www.cintal.com.ve/tecnologia/argos

*/

#ifndef ARG_SVG_IMAGE_H
#define ARG_SVG_IMAGE_H

#include <FL/Fl_Image.H>
#include <stdlib.h>

namespace infarg{

class Arg_SVG_Image : public Fl_RGB_Image {
private:
    void* 				svgcontext_; 		//!< Contexto Cairo
    unsigned int 	pt_width_;			//!< Ancho de la Imagen "points" (tamano en el archivo SVG)
    unsigned int 	pt_height_;    	//!< Alto de la Imagen "points" (tamano en el archivo SVG)
    int 					draw_width_;   	//!< Ancho de la Imagen donde se dibuja
    int 					draw_height_;  	//!< Alto de la Imagen donde se dibuja
    Fl_Color 			bgcolor_; 			//!< Background color (for blending translucent areas of image)
    Fl_Color 			draw_bg_; 			//!< Background color that was last drawn
    size_t				len_;

public:
    Arg_SVG_Image(const char* bits, size_t len, int W=0, int H=0, Fl_Color c = FL_BACKGROUND_COLOR);
    Arg_SVG_Image(const char* filename, int W=0, int H=0, Fl_Color c = FL_BACKGROUND_COLOR);
    virtual ~Arg_SVG_Image();

/*--------------------------------------------------------
	Devuelve las dimensiones de la imagen
----------------------------------------------------------*/
    int pt_width() const {
        return pt_width_;
    }
    int pt_height() const {
        return pt_height_;
    }

/*--------------------------------------------------------
	Devuelve la longitud en bytes de la imagen
----------------------------------------------------------*/
    size_t len() const {
    	return len_;
    }

/*--------------------------------------------------------
	Asigna las dimensiones al contenedor donde se pinta
	la imagen
----------------------------------------------------------*/
    void size(int W, int H) {
        w(W);
        h(H);
    }

/*--------------------------------------------------------
	Asigna el color de fondo a la imagen
----------------------------------------------------------*/
    void bgcolor(Fl_Color c) {
        bgcolor_ = c;
    }

/*--------------------------------------------------------
	Se invoca desde el destructor para liberar los recursos
----------------------------------------------------------*/
    void destroy();

/*--------------------------------------------------------
	Obtiene los datos de la imagen desde un flujo de datos
	con formato SVG
----------------------------------------------------------*/
    int svgdata(const char* data, size_t len);

/*--------------------------------------------------------
	Dibuja el widget
----------------------------------------------------------*/
    virtual void draw(int XP, int YP, int WP, int HP, int cx, int cy);

/*--------------------------------------------------------

----------------------------------------------------------*/
    bool hit(int at_x, int at_y, int thresh = 1);

protected:

/*--------------------------------------------------------
	Descomprime los datos si se encuentran en formato SVGZ
----------------------------------------------------------*/
    static char* decompGZ(const char* in, size_t size);
};

}

#endif // ARG_SVG_IMAGE_H


