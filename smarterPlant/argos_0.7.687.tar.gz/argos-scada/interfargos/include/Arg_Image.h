/**
* @file	Arg_Image.h
* @class Arg_Image
* @brief		<b>Tipo Abstracto de Dato (Widget) para el despliegue de
*				Imagenes de acuerdo a los valores de Tags y Alarmas.<br>
*				De acuerdo al resultado de evaluar la expresion, este
*				Widget puede desplegar tres imagenes distintas.<br>
*				Los Widgets son desarrollados para ser implementados
*				en interfARGOS (RAD basado en fluid) usando la
*				biblioteca grafica FLTK http://www.fltk.org </b><br>
* @author	    Alejandro Pina <ajpina@gmail.com><br>
* @link			http://www.cintal.com.ve/tecnologia/argos<br>
* @package      argos
* @access       public
* @version      1.0  -  01/06/09
*/

/*
Copyright (C) 2006 Alejandro Pina <ajpina@gmail.com>

Este programa es software libre. Puede redistribuirlo y/o modificarlo bajo
los terminos de la Licencia Publica General de GNU segun es publicada por
la Free Software Foundation, bien de la version 3 de dicha Licencia o bien
(segun su eleccion) de cualquier version posterior.

Este programa se distribuye con la esperanza de que sea util, pero
SIN NINGUNA GARANTIA, incluso sin la garantia MERCANTIL implicita o sin
garantizar la CONVENIENCIA PARA UN PROPOSITO PARTICULAR. Vease la Licencia
Publica General de GNU para mas detalles.

Deberia haber recibido una copia de la Licencia Publica General junto con
este programa. Si no ha sido asi, escriba a la Free Software Foundation, Inc.,
en 675 Mass Ave, Cambridge, MA 02139, EEUU.

Alejandro Pina mediante este documento renuncia a cualquier interes de derechos de
copyright con respecto al programa 'argos'.

01 de Noviembre de 2008

Por favor reporte cualquier fallo a la siguiente direccion:

	http://www.cintal.com.ve/tecnologia/argos

*/


#ifndef ARG_IMAGE_H_
#define ARG_IMAGE_H_

#include <FL/Fl.H>
#include <FL/Fl_Box.H>
#include <FL/Fl_Shared_Image.H>

#include "Arg_Widget.h"

namespace infarg{

class Arg_Image : public Fl_Box, public Arg_Widget {
private:
	Fl_Shared_Image		*img;				//!< Referencia a las Imagenes
	std::string			path_img[3];		//!< Rutas de las Imagenes
	short				img_actual;			//!< Indice de la Imagen desplegada

public:
	Arg_Image(int , int , int , int , const char *);
	Arg_Image(int , int , int , int );
	~Arg_Image();

/*--------------------------------------------------------
	Asigna las rutas de las tres imagenes que seran
	cargadas por el Widget
----------------------------------------------------------*/
	void asignar_imagenes(std::string, std::string, std::string );

/*--------------------------------------------------------
	Despliega la Imagen correspondiente en el Widget
----------------------------------------------------------*/
	void mostrar_imagen( short );

/*--------------------------------------------------------
	Actualiza la Imagen del Widget de acuerdo al
	resultado de evaluar la expresion con los valores
	recientes de los Tags y Alarmas
----------------------------------------------------------*/
	void refrescar();

/*--------------------------------------------------------
	Asigna la expresion que debe evaluar el Widget
	para desplegar la imagen correspondiente
----------------------------------------------------------*/
	void asignar_expresion(std::string);
};


}

#endif
