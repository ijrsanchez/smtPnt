/**
* @file	Arg_Widget.h
* @class Arg_Widget
* @brief		<b>Clase Abstracta creada para que todos los Widgets de
*				interfARGOS hereden de esta, forzando asi a que
*				todos tengan acceso a la Memoria Compartida de Tags
*				y Alarmas, ademas de poder analizar y evaluar
*				expresiones a traves de MuParser.<br>
*				Los Widgets son desarrollados para ser implementados
*				en interfARGOS (RAD basado en fluid) usando la
*				biblioteca grafica FLTK http://www.fltk.org </b><br>
* @author	    Alejandro Pina <ajpina@gmail.com><br>
* @link			http://www.cintal.com.ve/tecnologia/argos<br>
* @package      argos
* @access       public
* @version      1.0  -  01/06/09
*/

/*
Copyright (C) 2006 Alejandro Pina <ajpina@gmail.com>

Este programa es software libre. Puede redistribuirlo y/o modificarlo bajo
los terminos de la Licencia Publica General de GNU segun es publicada por
la Free Software Foundation, bien de la version 3 de dicha Licencia o bien
(segun su eleccion) de cualquier version posterior.

Este programa se distribuye con la esperanza de que sea util, pero
SIN NINGUNA GARANTIA, incluso sin la garantia MERCANTIL implicita o sin
garantizar la CONVENIENCIA PARA UN PROPOSITO PARTICULAR. Vease la Licencia
Publica General de GNU para mas detalles.

Deberia haber recibido una copia de la Licencia Publica General junto con
este programa. Si no ha sido asi, escriba a la Free Software Foundation, Inc.,
en 675 Mass Ave, Cambridge, MA 02139, EEUU.

Alejandro Pina mediante este documento renuncia a cualquier interes de derechos de
copyright con respecto al programa 'argos'.

01 de Noviembre de 2008

Por favor reporte cualquier fallo a la siguiente direccion:

	http://www.cintal.com.ve/tecnologia/argos

*/

#ifndef ARG_WIDGET_H_
#define ARG_WIDGET_H_

#include <string>

#include "Arg_Data.h"
#include "muParser.h"
#include "as-util.h"

namespace infarg{

class Arg_Widget{
protected:
	mu::Parser		parser;			//!< Analizador Matematico
	std::string		expresion;		//!< Expresion a Evaluar
	Arg_Data *		data;			//!< Referencia a los Tags y Alarmas

public:
	Arg_Widget();
	~Arg_Widget();

/*--------------------------------------------------------
	Asignar al Widget la capacidad de acceder a la
	Memoria Compartida de Tags y Alarmas a traves del
	Objeto Arg_Data.
----------------------------------------------------------*/
	void asignar_data( Arg_Data *);

/*--------------------------------------------------------
	Obliga a los Widgets a sobreescribir el metodo para
	refrescarse, de acuerdo al resultado de evaluar
	la expresion con los valores recientes de los Tags y Alarmas
----------------------------------------------------------*/
	virtual void refrescar() = 0;

/*--------------------------------------------------------
	Obliga a los Widgets a sobreescribir el metodo para
	asignar la expresion que debe ser evaluada con los valores
	recientes de los Tags y Alarmas
----------------------------------------------------------*/
	virtual void asignar_expresion(std::string) = 0;
};

}

#endif
