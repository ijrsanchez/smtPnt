// generado por InterfArgos (Argos) version 1.0109

#ifndef pr1_h
#define pr1_h
#include <FL/Fl.H>
#include "Arg_Window.h"
#include <FL/Fl_Double_Window.H>
#include "Arg_Label.h"

using namespace infarg;

#endif
