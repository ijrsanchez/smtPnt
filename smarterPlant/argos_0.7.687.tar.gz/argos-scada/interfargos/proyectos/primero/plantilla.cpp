#include <Fl/Fl_Shared_Image.H>

#include "Arg_Window.h"
#include "Arg_Label.h"
#include "Arg_Image.h"




Fl_Output * label1=(Fl_Output *)0;
Fl_Output * label2=(Fl_Output *)0;
Fl_Output * label3=(Fl_Output *)0;
Fl_Output * label4=(Fl_Output *)0;
Fl_Output * label5=(Fl_Output *)0;
Fl_Output * label6=(Fl_Output *)0;
Fl_Output * label7=(Fl_Output *)0;
Fl_Output * label8=(Fl_Output *)0;
Fl_Output * label9=(Fl_Output *)0;
Fl_Output * label10=(Fl_Output *)0;
Fl_Output * label11=(Fl_Output *)0;
Fl_Output * label12=(Fl_Output *)0;
Fl_Output * label13=(Fl_Output *)0;
Fl_Output * label14=(Fl_Output *)0;
Fl_Output * label15=(Fl_Output *)0;
Fl_Box * box1=(Fl_Box *)0;
Fl_Box * box0=(Fl_Box *)0;
Fl_Box * fondo=(Fl_Box *)0;


int foo(){
	return 1;
}

using namespace infarg;

int main (int argc, char *argv[]) {
	fl_register_images();

	Fl_Double_Window *w = new Arg_Window(800,600,"escaner/tags","escaner/alarmas");;
	{
		{
		fondo = new Fl_Box(0,10,800,600, "");

		Fl_Shared_Image * img = Fl_Shared_Image::get( "compresor.JPG", fondo->w(), fondo->h() );
		if( img )
			fondo->image(img);
		fondo->redraw();
		}
		{
		label1 = new Arg_Label(1,300,100,30, "Temperatura �C");
		((Arg_Label *)label1)->asignar_expresion( "$ganch_aux_Vel+ 5 + $ganch_aux_Freno_Mecanico_Elev/ 56745" );
		label1->box(FL_BORDER_BOX);
		label1->labeltype(FL_ENGRAVED_LABEL);
		label1->labelsize(14);
		label1->color(FL_FOREGROUND_COLOR);
		label1->textfont(1);
		label1->textsize(16);
		label1->textcolor(7);
		label1->align(FL_ALIGN_TOP_LEFT);
	((Arg_Window *)label1->window())->registrar_timer_rapido( (Arg_Label *)(label1) );
		}
		{
		label2 = new Arg_Label(500,300,100,30, "agr");
		((Arg_Label *)label2)->asignar_expresion( "0xFFFFFF" );
		}
		{
		label3 = new Arg_Label(590,360,100,30, "");
		((Arg_Label *)label3)->asignar_expresion( "ln($ganch_aux_Vel) * 10 * 10" );
		}
		{
		label4 = new Arg_Label(590,395,100,30, "");
		((Arg_Label *)label4)->asignar_expresion( "sqrt($ganch_dist_freno)" );
		}
		{
		label5 = new Arg_Label(590,430,100,30, "");
		((Arg_Label *)label5)->asignar_expresion( "sin(4.5*$ganch_aux_Freno_Mecanico_Elev/9.98)" );
		}
		{
		label6 = new Arg_Label(40,80,100,30, "Presion Entrada");
		((Arg_Label *)label6)->asignar_expresion( "$ganch_dist_freno+exp(100)" );
		label6->box(FL_BORDER_BOX);
		label6->labeltype(FL_ENGRAVED_LABEL);
		label6->labelsize(14);
		label6->color(FL_FOREGROUND_COLOR);
		label6->textfont(1);
		label6->textsize(16);
		label6->textcolor(7);
		label6->align(FL_ALIGN_TOP_LEFT);
		}
		{
		label7 = new Arg_Label(560,90,100,30, "");
		((Arg_Label *)label7)->asignar_expresion( "rint($ganch_dist_freno)" );
		}
		{
		label8 = new Arg_Label(210,490,100,30, "");
		((Arg_Label *)label8)->asignar_expresion( "12 / log($ganch_dist_freno)" );
		}
		{
		label9 = new Arg_Label(350,490,100,30, "");
		((Arg_Label *)label9)->asignar_expresion( "$ganch_dist_freno== 423779" );
		}
		{
		label10 = new Arg_Label(560,20,100,30, "Presion Entrada");
		((Arg_Label *)label10)->asignar_expresion( "tanh($ganch_dist_freno)" );
		label10->box(FL_BORDER_BOX);
		label10->labeltype(FL_ENGRAVED_LABEL);
		label10->labelsize(14);
		label10->color(FL_FOREGROUND_COLOR);
		label10->textfont(1);
		label10->textsize(16);
		label10->textcolor(7);
		label10->align(FL_ALIGN_TOP_LEFT);
((Arg_Window *)w)->registrar_timer_rapido( (Arg_Label *)(label10) );
		}
		{
		label11 = new Arg_Label(560,130,100,30, "");
		((Arg_Label *)label11)->asignar_expresion( "(678/435546)*(cos($ganch_aux_Vel))" );
		label11->box(FL_BORDER_BOX);
		label11->labeltype(FL_ENGRAVED_LABEL);
		label11->labelsize(14);
		label11->color(FL_FOREGROUND_COLOR);
		label11->textfont(1);
		label11->textsize(16);
		label11->textcolor(7);
		label11->align(FL_ALIGN_TOP_LEFT);
	((Arg_Window *)w)->registrar_timer_normal( (Arg_Label *)(label11) );
		}
		{
		label12 = new Arg_Label(20,450,100,30, "Presion Entrada");
		((Arg_Label *)label12)->asignar_expresion( "$ganch_aux_Vel and 683643" );
		label12->box(FL_BORDER_BOX);
		label12->labeltype(FL_ENGRAVED_LABEL);
		label12->labelsize(14);
		label12->color(FL_FOREGROUND_COLOR);
		label12->textfont(1);
		label12->textsize(16);
		label12->textcolor(7);
		label12->align(FL_ALIGN_TOP_LEFT);
	((Arg_Window *)w)->registrar_timer_lento( (Arg_Label *)(label12) );
		}
		{
		label13 = new Arg_Label(110,550,100,30, "");
		((Arg_Label *)label13)->asignar_expresion( "947393 or $ganch_aux_Vel" );
	((Arg_Window *)w)->registrar_timer_rapido( (Arg_Label *)(label13) );
		}
		{
		label14 = new Arg_Label(220,550,100,30, "");
		((Arg_Label *)label14)->asignar_expresion( "sqrt($ganch_dist_freno) and 4739" );
	((Arg_Window *)w)->registrar_timer_normal( (Arg_Label *)(label14) );
		}
		{
		label15 = new Arg_Label(330,550,100,30, "");
		((Arg_Label *)label15)->asignar_expresion( "atan($ganch_dist_freno)" );
((Arg_Window *)w)->registrar_timer_lento( (Arg_Label *)(label15) );
		}

	((Arg_Window *)w)->registrar_timer_normal( (Arg_Label *)(label2) );
	((Arg_Window *)w)->registrar_timer_lento( (Arg_Label *)(label3) );
	((Arg_Window *)w)->registrar_timer_rapido( (Arg_Label *)(label4) );
	((Arg_Window *)w)->registrar_timer_normal( (Arg_Label *)(label5) );
	((Arg_Window *)w)->registrar_timer_lento( (Arg_Label *)(label6) );
	((Arg_Window *)w)->registrar_timer_rapido( (Arg_Label *)(label7) );
	((Arg_Window *)w)->registrar_timer_normal( (Arg_Label *)(label8) );
	((Arg_Window *)w)->registrar_timer_lento( (Arg_Label *)(label9) );
	




	

{
		box0 = new Arg_Image(90,10,50,50, "");
		box0->box(FL_THIN_DOWN_BOX);
		((Arg_Image *)box0)->asignar_expresion( "sin($ganch_dist_freno) > 0" );
		((Arg_Image*)box0)->asignar_imagenes("bomba_roja.jpeg",
			"bomba_verde.jpeg", "");
		}

		((Arg_Window *)w)->registrar_timer_rapido( (Arg_Image *)(box0) );



{
		box1 = new Arg_Image(5,150,50,50, "");
		box1->box(FL_THIN_DOWN_BOX);
		((Arg_Image *)box1)->asignar_expresion( "$ganch_aux_Vel == 1" );
		((Arg_Image*)box1)->asignar_imagenes("bomba_roja.jpeg",
			"bomba_verde.jpeg", "");
		}

		((Arg_Window *)w)->registrar_timer_rapido( (Arg_Image *)(box1) );



	w->end();
	}







	w->resizable(w);
	w->show(argc, argv);
	return Fl::run();
}
