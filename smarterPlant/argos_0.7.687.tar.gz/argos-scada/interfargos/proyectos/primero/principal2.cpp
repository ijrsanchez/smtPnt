#include <Fl/Fl_Shared_Image.H>

#include "Arg_Window.h"
#include "Arg_Label.h"
#include "Arg_Image.h"




Fl_Output * label1=(Fl_Output *)0;
Fl_Output * label2=(Fl_Output *)0;
Fl_Output * label3=(Fl_Output *)0;
Fl_Output * label4=(Fl_Output *)0;
Fl_Output * label5=(Fl_Output *)0;
Fl_Output * label6=(Fl_Output *)0;
Fl_Output * label7=(Fl_Output *)0;
Fl_Output * label8=(Fl_Output *)0;
Fl_Output * label9=(Fl_Output *)0;
Fl_Output * label10=(Fl_Output *)0;
Fl_Output * label11=(Fl_Output *)0;
Fl_Output * label12=(Fl_Output *)0;
Fl_Output * label13=(Fl_Output *)0;
Fl_Output * label14=(Fl_Output *)0;
Fl_Output * label15=(Fl_Output *)0;
Fl_Box * box1=(Fl_Box *)0;
Fl_Box * box0=(Fl_Box *)0;
Fl_Box * fondo=(Fl_Box *)0;


int foo(){
	return 1;
}

using namespace infarg;

int main (int argc, char *argv[]) {
	fl_register_images();

	Fl_Double_Window *w = new Arg_Window(800,800,"escaner/tags","escaner/alarmas");;
	{
		{
		fondo = new Fl_Box(10,10,800,600, "");
		Fl_Shared_Image * img = Fl_Shared_Image::get( "compresor.JPG", fondo->w(), fondo->h() );
		if( img )
			fondo->image(img);
		fondo->redraw();
		}
		{
		label1 = new Arg_Label(20,295,100,30, "");
		((Arg_Label *)label1)->asignar_expresion( "$trasl_puente_Vel_motor_lado_uno+ 5 + $trasl_puente_Tiempo_Uso_motor_lado_dos/ 56745" );
		}
		{
		label2 = new Arg_Label(500,300,100,30, "");
		((Arg_Label *)label2)->asignar_expresion( "sin($trasl_puente_Tiempo_Uso_motor_lado_dos)" );
		}
		{
		label3 = new Arg_Label(590,360,100,30, "");
		((Arg_Label *)label3)->asignar_expresion( "ln($trasl_puente_Tiempo_Uso_motor_lado_dos) * 10 * 10" );
		}
		{
		label4 = new Arg_Label(590,395,100,30, "");
		((Arg_Label *)label4)->asignar_expresion( "sqrt($trasl_puente_Tiempo_Uso_motor_lado_dos)" );
		}
		{
		label5 = new Arg_Label(590,430,100,30, "");
		((Arg_Label *)label5)->asignar_expresion( "sin(4.5*$trasl_puente_Tiempo_Uso_motor_lado_dos/9.98)" );
		}
		{
		label6 = new Arg_Label(50,70,100,30, "");
		((Arg_Label *)label6)->asignar_expresion( "$trasl_puente_Tiempo_Uso_motor_lado_dos+exp(100)" );
		}
		{
		label7 = new Arg_Label(560,90,100,30, "");
		((Arg_Label *)label7)->asignar_expresion( "rint($trasl_puente_Tiempo_Uso_motor_lado_dos)" );
		}
		{
		label8 = new Arg_Label(210,490,100,30, "");
		((Arg_Label *)label8)->asignar_expresion( "12 / log($trasl_puente_Tiempo_Uso_motor_lado_dos)" );
		}
		{
		label9 = new Arg_Label(350,490,100,30, "");
		((Arg_Label *)label9)->asignar_expresion( "$trasl_puente_Tiempo_Uso_motor_lado_dos== 423779" );
		}
		{
		label10 = new Arg_Label(560,20,100,30, "");
		((Arg_Label *)label10)->asignar_expresion( "tanh($trasl_puente_Tiempo_Uso_motor_lado_dos)" );
		}
		{
		label11 = new Arg_Label(560,130,100,30, "");
		((Arg_Label *)label11)->asignar_expresion( "(678/435546)*(cos($trasl_puente_Tiempo_Uso_motor_lado_dos))" );
		}
		{
		label12 = new Arg_Label(20,450,100,30, "");
		((Arg_Label *)label12)->asignar_expresion( "$trasl_puente_Tiempo_Uso_motor_lado_dos and 683643" );
		}
		{
		label13 = new Arg_Label(110,550,100,30, "");
		((Arg_Label *)label13)->asignar_expresion( "947393 or $trasl_puente_Tiempo_Uso_motor_lado_dos" );
		}
		{
		label14 = new Arg_Label(220,550,100,30, "");
		((Arg_Label *)label14)->asignar_expresion( "sqrt($trasl_puente_Tiempo_Uso_motor_lado_dos) and 4739" );
		}
		{
		label15 = new Arg_Label(330,550,100,30, "");
		((Arg_Label *)label15)->asignar_expresion( "atan($trasl_puente_Tiempo_Uso_motor_lado_dos)" );
		}
	((Arg_Window *)w)->registrar_timer_rapido( (Arg_Label *)(label1) );
	((Arg_Window *)w)->registrar_timer_normal( (Arg_Label *)(label2) );
	((Arg_Window *)w)->registrar_timer_lento( (Arg_Label *)(label3) );
	((Arg_Window *)w)->registrar_timer_rapido( (Arg_Label *)(label4) );
	((Arg_Window *)w)->registrar_timer_normal( (Arg_Label *)(label5) );
	((Arg_Window *)w)->registrar_timer_lento( (Arg_Label *)(label6) );
	((Arg_Window *)w)->registrar_timer_rapido( (Arg_Label *)(label7) );
	((Arg_Window *)w)->registrar_timer_normal( (Arg_Label *)(label8) );
	((Arg_Window *)w)->registrar_timer_lento( (Arg_Label *)(label9) );
	((Arg_Window *)w)->registrar_timer_rapido( (Arg_Label *)(label10) );
	((Arg_Window *)w)->registrar_timer_normal( (Arg_Label *)(label11) );
	((Arg_Window *)w)->registrar_timer_lento( (Arg_Label *)(label12) );
	((Arg_Window *)w)->registrar_timer_rapido( (Arg_Label *)(label13) );
	((Arg_Window *)w)->registrar_timer_normal( (Arg_Label *)(label14) );
	((Arg_Window *)w)->registrar_timer_lento( (Arg_Label *)(label15) );

{
		box0 = new Arg_Image(90,10,50,50, "");
		box0->box(FL_THIN_DOWN_BOX);
		((Arg_Image *)box0)->asignar_expresion( "sin($trasl_puente_Tiempo_Uso_motor_lado_dos) > 0" );
		((Arg_Image*)box0)->asignar_imagenes("bomba_roja.jpeg",
			"bomba_verde.jpeg", "");
		}

		((Arg_Window *)w)->registrar_timer_rapido( (Arg_Image *)(box0) );



{
		box1 = new Arg_Image(5,150,50,50, "");
		box1->box(FL_THIN_DOWN_BOX);
		((Arg_Image *)box1)->asignar_expresion( "$compres_Presion_Entrada_Alta == 1" );
		((Arg_Image*)box1)->asignar_imagenes("bomba_roja.jpeg",
			"bomba_verde.jpeg", "");
		}

		((Arg_Window *)w)->registrar_timer_rapido( (Arg_Image *)(box1) );



	w->end();
	}







	w->resizable(w);
	w->show(argc, argv);
	return Fl::run();
}
