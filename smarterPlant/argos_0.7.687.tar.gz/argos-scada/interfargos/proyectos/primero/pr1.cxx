// generado por InterfArgos (Argos) version 1.0109

#include "pr1.h"

int main(int argc, char **argv) {
  Fl_Double_Window* w;
  { Fl_Double_Window* o = new Arg_Window(310, 285, "escaner/tags","escaner/alarmas");
    w = o;
    { Arg_Label* o = new Arg_Label(70, 105, 205, 60);
      ((Arg_Label *)o)->asignar_expresion("$ganch_aux_Vel");
      ((Arg_Window *)o->window())->registrar_timer_lento( (Arg_Label *)(o) );
    } // Arg_Label* o
    o->end();
  } // Fl_Double_Window* o
  w->show(argc, argv);
  return Fl::run();
}
