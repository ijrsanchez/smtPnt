/************************************************************
*                      test.cxx
*
* This is a crude test prog for Fl_Scope
*
*
* Author: Michael Pearce   (mike@slavelighting.com)
*
* Started: 1 August 2003
*
* Copyright: GPL
*
*************************************************************
*                  Version Information
*************************************************************
* Version 0.1.0 - 11 Feb 2005
* Update to show added features
*************************************************************
* Version 0.0.0 - 1 August 2003
*  Start
*************************************************************/
#define DEBUG 0

#include <FL/Fl.H>
#include <FL/Fl_Double_Window.H>

#include "Fl_Scope.h"

#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <stdlib.h>
#include <stdio.h>
#include <linux/soundcard.h>

#include <stdlib.h>



#define RATE 441000   /* the sampling rate */
#define SIZE 16      /* sample size: 8 or 16 bits */
#define CHANNELS 2  /* 1 = mono 2 = stereo */


Fl_Window* w;
Fl_Scope*  t;


unsigned char DataUpDown;
char Direction;

FILE *WavFile;

int fd,arg,status;

int Audio_OK;

/*********************************************************************************
*
*********************************************************************************/
static void DataAddTimer(void*)
{

 short int Dat[2];
 int tmp,count;
 unsigned char tmpl,tmph;
 

#if 0
 if(Direction==0 && DataUpDown >0)
 {
  DataUpDown--;
 }
 else
 {
  Direction=1;
  if(DataUpDown < 254)
  {
   DataUpDown ++;
  }
  else
  {
   Direction=0;
  }
 }
 t->Add(DataUpDown);
#endif
 
 if(DEBUG>1)printf("1\n");

 if(feof(WavFile))
 {
  rewind(WavFile);
  /* Get past Header somehow */
  if(DEBUG>1)printf("2\n");
 }
 
 

 for(count=0;count<sizeof(Dat)/2;count++)
 {
  fread(&tmpl,1,1,WavFile);
  fread(&tmph,1,1,WavFile);
  
  tmp=((int)tmph<<8) | tmpl;
  
  Dat[count]=tmp;
  
  t->Add((unsigned int)Dat[count/2]); 
 
 }
 
 
 if(DEBUG>1)printf("3\n"); 
 
 
 if(DEBUG>1)printf("short int = %d    Dat = %d\n",sizeof(short int),sizeof(Dat));
 
 //Dat=fgetc(WavFile)<<8;
 //Dat=Dat|fgetc(WavFile);
 //t->Add(Dat[0]);
 
 
#if 1 
 if(fd > 0)
 {
  status = write(fd, &Dat, sizeof(Dat)); /* play it back */
  if (status != sizeof(Dat)) perror("wrote wrong number of bytes");
 }
#endif 

// t->redraw(); 

 if(DEBUG>1)printf("4\n"); 

 //Fl::repeat_timeout((1/((RATE/sizeof(Dat))*CHANNELS)),DataAddTimer);
 Fl::repeat_timeout(0.00002,DataAddTimer);
}


/*********************************************************************************
*
*********************************************************************************/
void AudioOpen(void)
{
  
 /* open sound device */
 fd = open("/dev/dsp", O_RDWR);
 if (fd < 0)
 {
   perror("open of /dev/dsp failed");
   return;
 }

 /* set sampling parameters */
 arg = SIZE;      /* sample size */
 status = ioctl(fd, SOUND_PCM_WRITE_BITS, &arg);
 if (status == -1) perror("SOUND_PCM_WRITE_BITS ioctl failed");
 if (arg != SIZE)perror("unable to set sample size");

    
 arg = CHANNELS;  /* mono or stereo */
 status = ioctl(fd, SOUND_PCM_WRITE_CHANNELS, &arg);
 if (status == -1) perror("SOUND_PCM_WRITE_CHANNELS ioctl failed");
 if (arg != CHANNELS) perror("unable to set number of channels");

 arg = RATE;      /* sampling rate */
 status = ioctl(fd, SOUND_PCM_WRITE_RATE, &arg);
 if (status == -1) perror("SOUND_PCM_WRITE_WRITE ioctl failed");

 Audio_OK=1;
 
}


/*********************************************************************************
*
*********************************************************************************/
int main()
{
 int count;

 Audio_OK=0;
 
 w = new Fl_Double_Window(600,300,"Test For Fl_Scope");
 //w->size_range(400,200, 800, 600, 0, 0,0);

 t = new Fl_Scope(10,10,580,280,"");
 t ->TraceColour(FL_WHITE);
 
 
 w->end();
 w->show();
 
  t->tracetype(FL_SCOPE_TRACE_LOOP);
  //t->tracetype(FL_SCOPE_TRACE_LOOP_CLEAR);
  //t->tracetype(FL_SCOPE_TRACE_SCROLL);
  
  //t->redrawmode(FL_SCOPE_REDRAW_OFF);
  t->redrawmode(FL_SCOPE_REDRAW_FULL);
  //t->redrawmode(FL_SCOPE_REDRAW_ALWAYS);

  
  t->linetype(FL_SCOPE_LINE);
  //t->linetype(FL_SCOPE_DOT);
 
  t->datatype(FL_SCOPE_SIGNED); 
  
  /* Attempt to open audio */
  AudioOpen();
  
  
   
   
 
 if((WavFile=fopen("flscope.wav","r"))==NULL)
 {
  printf("Could not open flscope.wav - make sure its in the same directory as you run from\n");
  return(1);
 }
  
 
  
   
 Fl::add_timeout(0.5,DataAddTimer);
 
 Fl::run();
 
 fcloseall();
 
 
 
}









