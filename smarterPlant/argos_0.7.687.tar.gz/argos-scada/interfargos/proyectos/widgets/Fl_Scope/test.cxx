/************************************************************
*                      test.cxx
*
* This is a crude test prog for Fl_Scope
*
*
* Author: Michael Pearce   (mike@slavelighting.com)
*
* Started: 1 August 2003
*
* Copyright: GPL
*
*************************************************************
*                  Version Information
*************************************************************
* Version 0.1.0 - 11 Feb 2005
* Update to show added features
*************************************************************
* Version 0.0.0 - 1 August 2003
*  Start
*************************************************************/


#include <FL/Fl.H>
#include <FL/Fl_Double_Window.H>

#include "Fl_Scope.h"

#include <stdlib.h>
#include <stdio.h>

Fl_Window* w;
Fl_Scope*  t;


int DataUpDown;
int Direction;


static void DataAddTimer(void*)
{

 if(Direction==0 && DataUpDown > 1)
 {
  DataUpDown-=110;
 }
 else
 {
  Direction=1;
  if(DataUpDown < 50000)
  {
   DataUpDown +=100;
  }
  else
  {
   Direction=0;
  }
 }
 t->Add(DataUpDown);

 

 Fl::repeat_timeout(0.001,DataAddTimer);
}




int main()
{
 int count;

 w = new Fl_Double_Window(600,300,"Test For Fl_Scope");
 //w->size_range(400,200, 800, 600, 0, 0,0);

 t = new Fl_Scope(10,10,580,280,"");
 t ->TraceColour(FL_WHITE);
 
 
 w->end();
 w->show();
 
 //t->tracetype(FL_SCOPE_TRACE_LOOP);
 //t->tracetype(FL_SCOPE_TRACE_LOOP_CLEAR);
 t->tracetype(FL_SCOPE_TRACE_SCROLL);
  
 //t->redrawmode(FL_SCOPE_REDRAW_OFF);
 //t->redrawmode(FL_SCOPE_REDRAW_FULL);
 t->redrawmode(FL_SCOPE_REDRAW_ALWAYS);

  
 //t->linetype(FL_SCOPE_LINE);
 t->linetype(FL_SCOPE_DOT);
 
 
 
 
   
 Fl::add_timeout(0.5,DataAddTimer);
 
 Fl::run();
 
 fcloseall();
 
 
 
}
