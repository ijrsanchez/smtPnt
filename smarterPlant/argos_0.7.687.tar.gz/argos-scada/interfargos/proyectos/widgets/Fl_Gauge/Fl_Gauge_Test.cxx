/**************************************************
*    Fl_Gauge_Test.cxx
*
*
***************************************************
*    Version Information
***************************************************
* V0.0.1 - 6 August
* Updated to handle changes in V0.0.6 of FL_Gauge
***************************************************
* V0.0.0 - 2 August 2004
* Start of project
**************************************************/

#include <Fl/Fl.H>
#include <Fl/Fl_Double_Window.H>
#include <Fl/Fl_Button.H>
#include <Fl/Fl_Box.H>

#include "Fl_Gauge.H"

#include <stdio.h>

Fl_Double_Window *win;
Fl_Gauge *gauge1,*gauge2,*gauge3,*gauge4;

Fl_Box *gzone;
Fl_Box *yzone;

static void timeout(void*);

static void cb_alert(void*);

static void cb_green(void*);
static void cb_greenout(void*);

int main(void)
{

 win=new Fl_Double_Window(540,440,"Fl_Gauge Test");

 gauge1=new Fl_Gauge(20,20,100,100,"Gauge 1");
 gauge1->stepdiv(5);
 gauge1->framecolor(FL_GREEN);
 gauge1->v2color(FL_DARK_MAGENTA);
 gauge1->fontsize(8);

 gauge2=new Fl_Gauge(140,20,150,150,"Gauge 2");
 gauge2->redlinestart(90.0);
 gauge2->value(100);
 gauge2->redlinemode(FL_GAUGE_RL_BEEP);
 gauge2->redlinecolor(FL_YELLOW);
 gauge2->pointercolor(FL_BLUE);
 gauge2->odocolor(FL_DARK_MAGENTA);

 gauge2->greenzoneend(85);
 gauge2->greenzonestart(50);

 gauge2->greenzonemode(FL_GAUGE_GZ_ON);

 gauge3=new Fl_Gauge(20,160,200,200,"Gauge 3");
 gauge3->redlinestart(80.0);
 gauge3->redlinemode(FL_GAUGE_RL_CBIN);
 gauge3->redlinecb(cb_alert);
 gauge3->odoincsize(0.1);
 gauge3->odomode(1);
 gauge3->min(-10);
 gauge3->max(90);
 yzone=new Fl_Box(20,370,200,20,"Yellow Zone Info");



 gauge4=new Fl_Gauge(250,160,250,250,"Gauge 4");
 gauge4->redlinestart(55);
 gauge4->value(0);
 gauge4->odoincsize(1.0);
 gauge4->textcolor(FL_DARK_MAGENTA);
 gauge4->v2mode(FL_GAUGE_V2_V1);
 gauge4->min(-60);
 gauge4->max(+60);
 gauge4->greenzonestart(-30);
 gauge4->greenzoneend(30);
 gauge4->greenzonemode(FL_GAUGE_GZ_CBIN);
 gauge4->greenzonecb(cb_green);


 gzone=new Fl_Box(250,420,250,20,"Green Zone Info");



 win->end();
 win->show();

 Fl::add_timeout(1,timeout);

 return(Fl::run());
}



double a1=1.0,a2=-1.0,a3=1.7,a4=-0.2;

static void timeout(void*)
{
 gauge1->value(gauge1->value()+a1);
 if(gauge1->value() > gauge1->max()) a1=-1.9;
 if(gauge1->value() < gauge1->min()) a1=1.2;
 gauge1->odoinc();

 gauge2->value(gauge2->value()+a2);
 if(gauge2->value() > gauge2->max()) a2=-1.5;
 if(gauge2->value() < gauge2->min()) a2=1.5;
 gauge2->ododec();

 gauge3->value(gauge3->value()+a3);
 if(gauge3->value() > gauge3->max()) a3=-1.1;
 if(gauge3->value() < gauge3->min()) a3=0.3;
 gauge3->odoinc();

 gauge4->value(gauge4->value()+a4);
 if(gauge4->value() > gauge4->max()) a4=-0.1;
 if(gauge4->value() < gauge4->min()) a4=1.2;





 gauge1->redraw();
 gauge2->redraw();
 gauge3->redraw();
 gauge4->redraw();


 Fl::repeat_timeout(0.1,timeout);
}






static void cb_alert(void*)
{
 switch(gauge3->redlinemode())
 {
  case FL_GAUGE_RL_CBIN:
   yzone->label("Inside the Red Line Area");
   gauge3->redlinemode(FL_GAUGE_RL_CBOUT);
   break;

  case FL_GAUGE_RL_CBOUT:
   yzone->label("Outside of the Red Line Area");
   gauge3->redlinemode(FL_GAUGE_RL_CBIN);
   break;
 }
}




static void cb_green(void*)
{
 gzone->label("Inside the Green Zone");

 gauge4->greenzonemode(FL_GAUGE_GZ_CBOUT);
 gauge4->greenzonecb(cb_greenout);
}


static void cb_greenout(void*)
{
 gzone->label("Outside of the Green Zone");

 gauge4->greenzonemode(FL_GAUGE_GZ_CBIN);
 gauge4->greenzonecb(cb_green);
}








