
/************************************************************************
*                         Fl_PlotXY_Test.cxx
*
*
* Author: Michael Pearce
* Started: 6 July 2004
*************************************************************************
*                        Version Information
*************************************************************************
* V1.0.4 - 27 July 2004
* Fixed buttons so when files loaded the are ON.
*************************************************************************
* V1.0.4 - 26 July 2004
* Update to use most features of Fl_PlotXY V1.0.10
* Especially added the loadxyyy functions.
*************************************************************************
* V1.0.3 - 19 July 2004
* Updated to use most of the features in FL_PlotXY V1.0.8
*************************************************************************
* V1.0.2 - 7 July 2004
* Changed to test new features
* Added line indicators and removeal buttons
* Added repeat demo button.
*************************************************************************
* V1.0.1 - 7 July 2004
* Changed to test new features
*************************************************************************
* V1.0.0 - 6 July 2004
* Modified to work with V1.0.0 of the Fl_PlotXY Widget
************************************************************************/

#include <FL/Fl.H>
#include <FL/Fl_Box.H>
#include <FL/Fl_Button.H>
#include <FL/Fl_Toggle_Button.H>
#include <FL/Fl_Double_Window.H>
#include <FL/fl_draw.H>
#include <FL/Fl_File_Chooser.H>
#include "Fl_PlotXY.H"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#ifdef WIN32
 #include <windows.h>
#endif


Fl_Double_Window* win;
Fl_PlotXY* plot;
Fl_Box* status;
Fl_Button* loadfile;
Fl_Button* loadxyyy;
Fl_Button* savefile;
Fl_Button* savexyyy;

Fl_Button* ReRunDemo;
Fl_Button* StopDemo;


Fl_Toggle_Button* LineSel[10];
char LineLabel[10][10];


Fl_Button* LineClose[10];
char LineCloseLabel[10][10];


static void AutoAddData(void*);
static void LineCheck(void*);

static void cb_loadfile(Fl_Widget *, void*);
static void cb_loadxyyyfile(Fl_Widget *, void*);
static void cb_savefile(Fl_Widget *, void*);
static void cb_savexyyy(Fl_Widget *, void*);
static void cb_linesel(Fl_Button *, void*);
static void cb_lineclose(Fl_Button *o, void*);
static void cb_restart(Fl_Widget *, void*);
static void cb_stopdemo(Fl_Widget *, void*);

int Line1,Line2,Line3;


Fl_Color MyColour[10] = {FL_BLACK, FL_BLUE, FL_CYAN, FL_DARK_BLUE, FL_DARK_CYAN, FL_DARK_GREEN, FL_DARK_MAGENTA, FL_DARK_RED, FL_DARK_YELLOW, FL_GREEN};

/*************************************
*              main
**************************************/
int main(void)
{
 int cnt,x,y;
 double count;

 win=new Fl_Double_Window(540,440,"Fl_PlotXY Test");

 plot=new Fl_PlotXY(10,20,380,380,"Test Fl_PlotXY Graph");
 plot->box(FL_UP_BOX);
 plot->align(FL_ALIGN_TOP);
 Fl_Group::current()->resizable(plot);

 status=new Fl_Box(10,405,300,30,"Status");
 status->box(FL_ENGRAVED_BOX);

 loadfile=new Fl_Button(320,405,70,15,"Load");
 loadfile->callback((Fl_Callback*)cb_loadfile);

 loadxyyy=new Fl_Button(395,405,70,15,"Load xyyy");
 loadxyyy->callback((Fl_Callback*)cb_loadxyyyfile);


 savefile=new Fl_Button(320,420,70,15,"Save");
 savefile->callback((Fl_Callback*)cb_savefile);

 savexyyy=new Fl_Button(395,420,70,15,"Save xyyy");
 savexyyy->callback((Fl_Callback*)cb_savexyyy);



 ReRunDemo=new Fl_Button(470,405,70,30,"Restart");
 ReRunDemo->callback((Fl_Callback*)cb_restart);
 ReRunDemo->hide();

 StopDemo=new Fl_Button(470,405,70,30,"Stop");
 StopDemo->callback((Fl_Callback*)cb_stopdemo);

 /* Make Line Selector Buttons */
 x=395;y=20;
 for(cnt=0;cnt<10;cnt++)
 {
  sprintf(LineLabel[cnt],"Line %d",cnt);
  LineSel[cnt]=new Fl_Toggle_Button(x,y,50,20,LineLabel[cnt]);
  LineSel[cnt]->type(FL_TOGGLE_BUTTON);
  LineSel[cnt]->callback((Fl_Callback*)cb_linesel);
  LineSel[cnt]->down_box(FL_DOWN_BOX);
  LineSel[cnt]->box(FL_PLASTIC_UP_BOX);

  sprintf(LineCloseLabel[cnt],"Close %d",cnt);
  LineClose[cnt]=new Fl_Button(x+50,y,50,20,LineCloseLabel[cnt]);
  LineClose[cnt]->callback((Fl_Callback*)cb_lineclose);

  y+=21;
 }


 win->end();
 win->show();



 Line1=plot->newline();
 Line2=plot->newline(0,0,0,0,FL_PLOTXY_AUTO,FL_GREEN,"");


 Line3=plot->newline(-2,-2,2,2,FL_PLOTXY_FIXED,FL_BLUE,"");



 /* Draw A Circle */
 for(count=0;count<7;count+=0.01)
 {
  plot->add(Line1,cos(count)*10,sin(count)*10);
 }

 Fl::add_timeout(1,AutoAddData);
 Fl::add_timeout(0.1,LineCheck);

 Fl::run();


 return(0);
}


double AutoCount=0;
double TimeReload=0.1;
int DemoStage=0;
double Zoom=0;
Fl_Color Colour=FL_BLACK;
unsigned char r=0,g=0,b=0;
unsigned long int datacount;
double myX,myY,myX2,myY2;

static void AutoAddData(void*)
{

 switch(DemoStage)
 {
  case 0:
   status->label("Drawing Random Data On Line2");
   TimeReload=0.01;
   /* Draw Random Stuff */
   AutoCount+=0.1;

   plot->add(Line2,AutoCount,100*(rand()/(RAND_MAX+1.0)));
   if(AutoCount > 20){DemoStage++;AutoCount=0;}
   break;



  case 1:
   status->label("Drawing Random Data on Line 3");
   TimeReload=0.01;

   /* Draw Random Stuff */
   AutoCount+=0.1;

   plot->add(Line3,2*(rand()/(RAND_MAX+1.0)),2*(rand()/(RAND_MAX+1.0)));
   if(AutoCount > 40){DemoStage++;AutoCount=0;}
   break;


  case 2:
   TimeReload=0.02;
   status->label("Zooming out on Line 3");

   AutoCount+=0.1;

   plot->scalemode(Line3, FL_PLOTXY_FIXED);
   plot->setrange(Line3,0,0,AutoCount,AutoCount);

   if(AutoCount > 5){DemoStage++;}
   break;


  case 3:
   status->label("Zooming in on Line 3");

   AutoCount-=0.05;

   plot->scalemode(Line3, FL_PLOTXY_FIXED);
   plot->setrange(Line3,0,0,AutoCount,AutoCount);

   if(AutoCount <= 1){DemoStage++;AutoCount=0;}
   break;

  case 4:
   status->label("Removing Line 3");
   TimeReload=1.0;
   plot->remove(Line3);
   DemoStage++;
   break;


  case 5:
   status->label("Moving around Line 2");
   TimeReload=0.03;
   AutoCount+=0.2;

   plot->scalemode(Line2, FL_PLOTXY_FIXED);
   plot->setrange(Line2,AutoCount-10,AutoCount-10,AutoCount+10,AutoCount+10);

   if(AutoCount >20){DemoStage++;AutoCount=0;}
   break;



  case 6:
   TimeReload=1.0;
   status->label("Auto Scaling Line 2");
   plot->scalemode(Line2, FL_PLOTXY_AUTO);
   DemoStage++;
   break;


  case 7:
   status->label("Creating Line 3 - Fixed Size");
   Line3=plot->newline(-20,-20,20,20,FL_PLOTXY_FIXED,FL_RED,"");
   DemoStage++;
   break;


  case 8:
   TimeReload=0.005;
   status->label("Drawing Circle On Line 3");
   AutoCount+=0.01;
   /* Draw A Circle */
   plot->add(Line3,cos(AutoCount)*10,sin(AutoCount)*10);

   if(AutoCount>7){DemoStage++;AutoCount=0;}

   break;

  case 9:
   TimeReload=1;
   status->label("Reading Data Size for Line 3");
   datacount=plot->datasize(Line3);
   DemoStage++;
   break;

  case 10:
   status->label("Changing Some Data On Line 3");
   TimeReload=0.01;
   AutoCount+=0.03;
   datacount-=3;

   /* Draw A Circle */
   plot->change(Line3,datacount,cos(AutoCount)*15,sin(AutoCount)*5);

   if(AutoCount>7)DemoStage++;
   break;


  case 11:
   TimeReload=1;
   status->label("Getting limits on Line1 & setting as Fixed");

   plot->getrange(Line1,&myX,&myY,&myX2,&myY2); /* Gets range from current mode*/
   plot->setrange(Line1,myX,myY,myX2,myY2); /* Set lines range */
   plot->scalemode(Line1, FL_PLOTXY_FIXED);     /* Set Fixed Scale mode */

   datacount=plot->datasize(Line1);
   DemoStage++;
   break;

  case 12:
   TimeReload=0.001;
   status->label("Applying Limits to Y axis of Line1");
   datacount--;
   if(plot->read(Line1,datacount,&myX,&myY)==1)
   {
    if(myY > 5.0)myY=5.0;
    if(myY < -3.0)myY=-3.0;
    plot->change(Line1,datacount,myX,myY);
   }
   if(plot->used(Line1)==0 || datacount <=0)DemoStage++;
   break;

  case 13:
   TimeReload=1;
   status->label("Changing Line mode of Line3 to DOT");
   plot->drawmode(Line3,FL_PLOTXY_DOT);
   DemoStage++;
   r=g=b=0;
   break;

  case 14:
   r+=2;g+=11;b+=23;
   Colour=fl_rgb_color(r,g,b);
   TimeReload=0.01;
   status->label("Changing colour of Line2");
   plot->linecolor(Line2,Colour);
   if(r>200)DemoStage++;
   break;


  case 15:
   TimeReload=1;
   status->label("Hiding line 1");
   plot->linehide(Line1);
   DemoStage++;
   break;

  case 16:
   TimeReload=1;
   status->label("Hiding line 2");
   plot->linehide(Line2);
   DemoStage++;
   break;


  case 17:
   TimeReload=1;
   status->label("Hiding line 3");
   plot->linehide(Line3);
   DemoStage++;
   break;

  case 18:
   TimeReload=2;
   status->label("Showing Line1");
   plot->lineshow(Line1);
   DemoStage++;
   break;


  case 19:
   TimeReload=4;
   status->label("Showing Line1 Axis Marks");
   plot->xmarkon(Line1,FL_PLOTXY_MARK_ON);    /* Turn Value display ON */
   plot->ymarkon(Line1,FL_PLOTXY_MARK_ON);
   plot->xmarkstep(Line1,4.0);                /* Set X and Y value divisions */
   plot->ymarkstep(Line1,2.0);
   plot->xvalformat(Line1,2,1);               /* Set X val to %02.01lf */
   plot->yvalformat(Line1,1,3);               /* Set X val to %01.03lf */
   DemoStage++;
   break;






  case 20:
   TimeReload=4;
   status->label("Showing Line1 Axis Values");
  // plot->xvaltype(Line1,FL_PLOTXY_VAL_NUMBER);
  // plot->yvaltype(Line1,FL_PLOTXY_VAL_NUMBER);

   plot->xmarkon(Line1,FL_PLOTXY_MARK_ON|FL_PLOTXY_MARK_VAL);
   plot->ymarkon(Line1,FL_PLOTXY_MARK_ON|FL_PLOTXY_MARK_VAL);

   DemoStage++;
   break;


  case 21:
   TimeReload=2;
   status->label("Showing X Label");

   plot->xmarklabel(Line1,"X Axis Label");
   plot->xmarkon(Line1,FL_PLOTXY_MARK_ON|FL_PLOTXY_MARK_VAL|FL_PLOTXY_MARK_LABEL);

   plot->ymarklabel(Line1,"Y Axis");
   plot->ymarkon(Line1,FL_PLOTXY_MARK_ON|FL_PLOTXY_MARK_VAL|FL_PLOTXY_MARK_LABEL);

   DemoStage++;
   break;

  case 22:
   TimeReload=3;
   status->label("Showing Line3");
   plot->lineshow(Line3);
   DemoStage++;
   break;



  case 23:
   TimeReload=2;
   status->label("About to REMOVE all lines");
   DemoStage++;
   break;

  case 24:
   TimeReload=1;
   status->label("REMOVE all lines");
   plot->removeall();
   DemoStage++;
   ReRunDemo->show();
   break;



  default:
   status->label("End of Demo - try loading a csv file");
   plot->redraw();
   TimeReload=4;
   break;

 }

 plot->redraw();

 Fl::repeat_timeout(TimeReload,AutoAddData);
}


/* Check what lines are currently in use */
static void LineCheck(void*)
{
 int count;
 for(count=0;count<10;count++)
 {
  if(plot->used(count)==1)
  {
   LineSel[count]->show();
   LineSel[count]->color(plot->linecolor(count));
  }
  else
  {
   LineSel[count]->hide();
   LineSel[count]->color(FL_GRAY);
  }
  LineSel[count]->redraw();
 }

 Fl::repeat_timeout(1,LineCheck);
}



/* Load Callback */
static void cb_loadfile(Fl_Widget *, void*)
{
 char *FileName;
 int line,r,g,b;

 FileName=fl_file_chooser("Load .CSV File","*.csv","",0);
 if((line=plot->load(FileName))!=-1)status->label("File opened");
 else status->label("UNABLE TO OPEN FILE");


 /* Change Line to random value */
 r=(int)(255.0*(rand()/(RAND_MAX+1.0)));
 g=(int)(255.0*(rand()/(RAND_MAX+1.0)));
 b=(int)(255.0*(rand()/(RAND_MAX+1.0)));

 plot->linecolor(line,fl_rgb_color(r,g,b));
 LineSel[line]->value(0);

}

/* Loadxyyy Callback */
static void cb_loadxyyyfile(Fl_Widget *, void*)
{
 char *FileName;
 double X=0,Y=0,X1=0,Y1=0;
 int count;

 FileName=fl_file_chooser("Load .CSV File","*.csv","",0);
 if(plot->loadxyyy(FileName)!=0)
 {
  status->label("File opened");
  plot->xmarkon(0,FL_PLOTXY_MARK_ON|FL_PLOTXY_MARK_LABEL|FL_PLOTXY_MARK_VAL);
  plot->ymarkon(0,FL_PLOTXY_MARK_ON|FL_PLOTXY_MARK_LABEL|FL_PLOTXY_MARK_VAL);
  plot->getrange(0,&X,&Y,&X1,&Y1);
  plot->xmarkstep(0,(X1-X)/5);
  plot->ymarkstep(0,(Y1-Y)/5);
  plot->xmarklabel(0);

  for(count=0;count<FL_PLOTXY_MAXLINES;count++)
  {
   plot->linecolor(count,MyColour[count]);
   plot->scalemode(count,FL_PLOTXY_AUTO);
   LineSel[count]->value(0);
  }

  plot->redraw();

 }
 else
 {
  status->label("UNABLE TO OPEN FILE");
 }
}


/* Save Callback */
static void cb_savefile(Fl_Widget *, void*)
{
 char *FileName;
 FileName=fl_file_chooser("Save .CSV File","*.csv","",0);
 if(plot->save(0,FileName))status->label("File saved");
 else status->label("UNABLE TO SAVE FILE");

}

/* Savexyyy callback */
static void cb_savexyyy(Fl_Widget *, void*)
{
 char *FileName;
 FileName=fl_file_chooser("Save .CSV File","*.csv","",0);
 if(plot->savexyyy(FileName))status->label("File saved");
 else status->label("UNABLE TO SAVE FILE");

}


/* Restart Demo */
static void cb_restart(Fl_Widget *, void*)
{
 double count;

 DemoStage=0;

 Line1=plot->newline();
 Line2=plot->newline(0,0,0,0,FL_PLOTXY_AUTO,FL_GREEN,"");
 Line3=plot->newline(-2,-2,2,2,FL_PLOTXY_FIXED,FL_BLUE,"");



  /* Draw A Circle */
 for(count=0;count<7;count+=0.01)
 {
  plot->add(Line1,cos(count)*10,sin(count)*10);
 }

 ReRunDemo->hide();
 StopDemo->show();
}


static void cb_stopdemo(Fl_Widget *, void*)
{
 DemoStage=100;

 ReRunDemo->show();
 StopDemo->hide();
}



/* Selected Line */
static void cb_linesel(Fl_Button *o, void*)
{
 char str[10];
 int line;
 sprintf(str,"%s",o->label());
 printf("Line Number Selected = %c\n",str[5]);
 line=atoi(&str[5]);

 if(plot->used(line)==0)
 {
  o->value(0);
 }
 else
 {
  if(o->value()==1)
  {
   plot->linehide(line);
  }
  else
  {
   plot->lineshow(line);
  }
  plot->redraw();
 }
}

/* Selected Line */
static void cb_lineclose(Fl_Button *o, void*)
{
 char str[10];
 int line;
 sprintf(str,"%s",o->label());
 printf("Closing Line = %c\n",str[6]);
 line=atoi(&str[6]);

 if(plot->used(line)) plot->remove(line);

 plot->redraw();

}


