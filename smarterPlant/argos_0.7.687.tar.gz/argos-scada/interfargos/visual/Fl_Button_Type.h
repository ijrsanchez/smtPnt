#ifndef FL_BUTTON_TYPE_H_
#define FL_BUTTON_TYPE_H_


#include "Fl_Widget_Type.h"

////////////////////////////////////////////////////////////////

#include <FL/Fl_Box.H>
class Fl_Box_Type : public Fl_Widget_Type {
public:
  virtual const char *type_name() {return "Fl_Box";}

/*---------------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-FECHA: 25/09/09 ------------------------------------------------
----INICIO ----------------------------------------------------*/

  virtual const char *p_type_name() {return "Fl_Widget";} // type for code output

/*---FIN --------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-----------------------------------------------------------------
----------------------------------------------------------------*/

  Fl_Widget *widget(int x,int y,int w, int h,void *dt=0) {
    return new Fl_Box(x,y,w,h,"label");}
  Fl_Widget_Type *_make() {return new Fl_Box_Type();}
  int pixmapID() { return 5; }
};
/*static Fl_Box_Type Fl_Box_type;*/

////////////////////////////////////////////////////////////////

#include <FL/Fl_Button.H>
static Fl_Menu_Item buttontype_menu[] = {
  {"Normal",0,0,(void*)0},
  {"Toggle",0,0,(void*)FL_TOGGLE_BUTTON},
  {"Radio",0,0,(void*)FL_RADIO_BUTTON},
  {0}};
class Fl_Button_Type : public Fl_Widget_Type {
  Fl_Menu_Item *subtypes() {return buttontype_menu;}
public:
  virtual void ideal_size(int &w, int &h) {
    Fl_Widget_Type::ideal_size(w, h);
    w += 2 * (o->labelsize() - 4);
    h = (h / 5) * 5;
  }
  virtual const char *type_name() {return "Fl_Button";}

/*---------------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-FECHA: 25/09/09 ------------------------------------------------
----INICIO ----------------------------------------------------*/

  virtual const char *p_type_name() {return "Fl_Widget";} // type for code output

/*---FIN --------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-----------------------------------------------------------------
----------------------------------------------------------------*/

  Fl_Widget *widget(int x,int y,int w,int h,void *dt=0) {
    return new Fl_Button(x,y,w,h,"button");}
  Fl_Widget_Type *_make() {return new Fl_Button_Type();}
  int is_button() const {return 1;}
  int pixmapID() { return 2; }
};
/*static Fl_Button_Type Fl_Button_type;*/

////////////////////////////////////////////////////////////////

#include <FL/Fl_Return_Button.H>
class Fl_Return_Button_Type : public Fl_Button_Type {
public:
  virtual void ideal_size(int &w, int &h) {
    Fl_Button_Type::ideal_size(w, h);
    int W = o->h();
    if (o->w()/3 < W) W = o->w()/3;
    w += W + 8 - o->labelsize();
  }
  virtual const char *type_name() {return "Fl_Return_Button";}

/*---------------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-FECHA: 25/09/09 ------------------------------------------------
----INICIO ----------------------------------------------------*/

  virtual const char *p_type_name() {return "Fl_Button";} // type for code output

/*---FIN --------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-----------------------------------------------------------------
----------------------------------------------------------------*/

  Fl_Widget *widget(int x,int y,int w,int h,void *dt=0) {
    return new Fl_Return_Button(x,y,w,h,"button");}
  Fl_Widget_Type *_make() {return new Fl_Return_Button_Type();}
  int pixmapID() { return 23; }
};
/*static Fl_Return_Button_Type Fl_Return_Button_type;*/

////////////////////////////////////////////////////////////////

#include <FL/Fl_Repeat_Button.H>
class Fl_Repeat_Button_Type : public Fl_Widget_Type {
public:
  virtual const char *type_name() {return "Fl_Repeat_Button";}

/*---------------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-FECHA: 25/09/09 ------------------------------------------------
----INICIO ----------------------------------------------------*/

  virtual const char *p_type_name() {return "Fl_Widget";} // type for code output

/*---FIN --------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-----------------------------------------------------------------
----------------------------------------------------------------*/

  Fl_Widget *widget(int x,int y,int w,int h,void *dt=0) {
    return new Fl_Repeat_Button(x,y,w,h,"button");}
  Fl_Widget_Type *_make() {return new Fl_Repeat_Button_Type();}
  int pixmapID() { return 25; }
};
/*static Fl_Repeat_Button_Type Fl_Repeat_Button_type;*/

////////////////////////////////////////////////////////////////

#include <FL/Fl_Light_Button.H>
class Fl_Light_Button_Type : public Fl_Button_Type {
public:
  virtual void ideal_size(int &w, int &h) {
    Fl_Button_Type::ideal_size(w, h);
    w += 4;
  }
  virtual const char *type_name() {return "Fl_Light_Button";}

/*---------------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-FECHA: 25/09/09 ------------------------------------------------
----INICIO ----------------------------------------------------*/

  virtual const char *p_type_name() {return "Fl_Button";} // type for code output

/*---FIN --------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-----------------------------------------------------------------
----------------------------------------------------------------*/

  Fl_Widget *widget(int x,int y,int w,int h,void *dt=0) {
    return new Fl_Light_Button(x,y,w,h,"button");}
  Fl_Widget_Type *_make() {return new Fl_Light_Button_Type();}
  int pixmapID() { return 24; }
};
/*static Fl_Light_Button_Type Fl_Light_Button_type;*/

////////////////////////////////////////////////////////////////

#include <FL/Fl_Check_Button.H>
class Fl_Check_Button_Type : public Fl_Button_Type {
public:
  virtual void ideal_size(int &w, int &h) {
    Fl_Button_Type::ideal_size(w, h);
    w += 4;
  }
  virtual const char *type_name() {return "Fl_Check_Button";}

/*---------------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-FECHA: 25/09/09 ------------------------------------------------
----INICIO ----------------------------------------------------*/

  virtual const char *p_type_name() {return "Fl_Button";} // type for code output

/*---FIN --------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-----------------------------------------------------------------
----------------------------------------------------------------*/

  Fl_Widget *widget(int x,int y,int w,int h,void *dt=0) {
    return new Fl_Check_Button(x,y,w,h,"button");}
  Fl_Widget_Type *_make() {return new Fl_Check_Button_Type();}
  int pixmapID() { return 3; }
};
/*static Fl_Check_Button_Type Fl_Check_Button_type;*/

////////////////////////////////////////////////////////////////

#include <FL/Fl_Round_Button.H>
class Fl_Round_Button_Type : public Fl_Button_Type {
public:
  virtual void ideal_size(int &w, int &h) {
    Fl_Button_Type::ideal_size(w, h);
    w += 4;
  }
  virtual const char *type_name() {return "Fl_Round_Button";}

/*---------------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-FECHA: 25/09/09 ------------------------------------------------
----INICIO ----------------------------------------------------*/

  virtual const char *p_type_name() {return "Fl_Button";} // type for code output

/*---FIN --------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-----------------------------------------------------------------
----------------------------------------------------------------*/

  Fl_Widget *widget(int x,int y,int w,int h,void *dt=0) {
    return new Fl_Round_Button(x,y,w,h,"button");}
  Fl_Widget_Type *_make() {return new Fl_Round_Button_Type();}
  int pixmapID() { return 4; }
};
/*static Fl_Round_Button_Type Fl_Round_Button_type;*/

////////////////////////////////////////////////////////////////


#endif
