
#ifndef FL_ARGOS_TYPE_H_
#define FL_ARGOS_TYPE_H_

#include "Fl_Button_Type.h"
#include "Fl_Misc_Type.h"


#include "Arg_Label.h"
class Arg_Label_Type : public Fl_Output_Type {
public:
  virtual void ideal_size(int &w, int &h) {
    infarg::Arg_Label *myo = (infarg::Arg_Label *)o;
    fl_font(myo->textfont(), myo->textsize());
    h = fl_height() + myo->textsize() - 6;
    w -= Fl::box_dw(o->box());
    int ww = (int)fl_width('m');
    w = ((w + ww - 1) / ww) * ww + Fl::box_dw(o->box());
    if (h < 15) h = 15;
    if (w < 15) w = 15;
  }
  virtual const char *type_name() {return "Arg_Label";}
  virtual const char *p_type_name() {return "Fl_Output";} // type for code output
  Fl_Widget *widget(int x,int y,int w,int h) {
    infarg::Arg_Label *myo = new infarg::Arg_Label(x,y,w,h,"arg_label:");
    myo->value("Valor");
    return myo;
  }
  Fl_Widget_Type *_make() {return new Arg_Label_Type();}
  int pixmapID() { return 50; }

  int is_arg_widget() const { return 1;}
  int arg_type() const { return ARG_LABEL; }

};
/*static Arg_Label_Type Arg_Label_type;*/



#include "Arg_Image.h"
class Arg_Image_Type : public Fl_Box_Type {
  std::string img_file[3];

public:
  virtual const char *type_name() {return "Arg_Image";}
  virtual const char *p_type_name() {return "Fl_Box";} // type for code output
  Fl_Widget *widget(int x,int y,int w,int h,void *dt=0) {
    infarg::Arg_Image *myo = new infarg::Arg_Image(x,y,w,h,"");
    return myo;
  }
  Fl_Widget_Type *_make() {return new Arg_Image_Type();}
  int pixmapID() { return 51; }

  int is_arg_widget() const { return 1; }
  int is_arg_image() const { return 1; }
  int arg_type() const { return ARG_IMAGE; }

  void arch_imagen( const char * c, int i ){
    if( i>=0 && i <=2 )
    img_file[i] = string( c );
  }

  const char * arch_imagen( int i ){
    if( i>=0 && i<=2 )
    return img_file[i].c_str();
  return NULL;
  }

};
/*static Arg_Image_Type Arg_Image_type;*/



#include "Arg_Gauge.h"
class Arg_Gauge_Type : public Fl_Box_Type {
  std::string img_file[3];

public:
  virtual const char *type_name() { return "Arg_Gauge"; }
  virtual const char *p_type_name() { return "Fl_Widget"; } // type for code output
  Fl_Widget *widget(int x, int y, int w, int h) {
    infarg::Arg_Gauge *myo = new infarg::Arg_Gauge(x, y, w, h, "");
    return myo;
  }
  Fl_Widget_Type *_make() { return new Arg_Gauge_Type(); }
  int pixmapID() { return 52; }

  int is_arg_widget() const { return 1; }
  int is_arg_gauge() const { return 1; }
  int arg_type() const { return ARG_GAUGE; }

};
/*static Arg_Gauge_Type Arg_Gauge_type;*/


#include "Arg_SVG_Image.h"
class Arg_SVG_Image_Type : public Fl_Box_Type {
public:
  virtual const char *type_name() { return "Arg_SVG_Image"; }
  virtual const char *p_type_name() { return "Fl_Widget"; } // type for code output
  Fl_Widget *widget(int x, int y, int w, int h,void *dt=0) {
  	Fl_Box *b = new Fl_Box(x,y,w,h,"label");
  	if(dt){
  		infarg::Arg_SVG_Image *tmp = (infarg::Arg_SVG_Image *)dt;
  		const char * buf = tmp->data()[0];
  		infarg::Arg_SVG_Image *ai = new infarg::Arg_SVG_Image(buf, tmp->len(), w, h);
  		b->image(ai);
  	}
    return b;
  }
  Fl_Widget_Type *_make() { return new Arg_SVG_Image_Type(); }
  int pixmapID() { return 52; }

  int is_arg_widget() const { return 1; }
  int is_arg_gauge() const { return 0; }
  int arg_type() const { return ARG_SVG_IMAGE; }


};


#endif


