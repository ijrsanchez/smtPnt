//
// "$Id: factory.cxx 5658 2007-02-02 20:09:53Z mike $"
//
// Widget factory code for the Fast Light Tool Kit (FLTK).
//
// Type classes for most of the fltk widgets.  Most of the work
// is done by code in Fl_Widget_Type.C.  Also a factory instance
// of each of these type classes.
//
// This file also contains the "new" menu, which has a pointer
// to a factory instance for every class (both the ones defined
// here and ones in other files)
//
// Copyright 1998-2006 by Bill Spitzak and others.
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Library General Public
// License as published by the Free Software Foundation; either
// version 2 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Library General Public License for more details.
//
// You should have received a copy of the GNU Library General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
// USA.
//
// Please report all bugs and problems on the following page:
//
//     http://www.fltk.org/str.php
//
/*
#include <FL/Fl.H>
#include <FL/Fl_Group.H>
#include <FL/Fl_Menu_Item.H>
#include <FL/Fl_Pixmap.H>
#include <stdio.h>
#include "flstring.h"
#include "undo.h"
*/
#include "factory.h"

//#include "Fl_Widget_Type.h"

extern Fl_Pixmap *pixmap[];
extern class Arg_Label_Type Arg_Label_type;						//Declarado en Fl_Argos_Type.cpp
extern class Arg_Image_Type Arg_Image_type;						//Declarado en Fl_Argos_Type.cpp
extern class Arg_Gauge_Type Arg_Gauge_type;						//Declarado en Fl_Argos_Type.cpp
extern class Arg_SVG_Image_Type	Arg_SVG_Image_type;		//Declarado en Fl_Argos_Type.cpp
extern class Arg_Window_Type Arg_Window_type;
extern class Fl_Function_Type Fl_Function_type;
extern class Fl_Code_Type Fl_Code_type;
extern class Fl_CodeBlock_Type Fl_CodeBlock_type;
extern class Fl_Decl_Type Fl_Decl_type;
extern class Fl_DeclBlock_Type Fl_DeclBlock_type;
extern class Fl_Comment_Type Fl_Comment_type;
extern class Fl_Class_Type Fl_Class_type;
extern class Fl_Window_Type Fl_Window_type;
extern class Fl_Widget_Class_Type Fl_Widget_Class_type;
extern class Fl_Group_Type Fl_Group_type;
extern class Fl_Pack_Type Fl_Pack_type;
extern class Fl_Tabs_Type Fl_Tabs_type;
extern class Fl_Scroll_Type Fl_Scroll_type;
extern class Fl_Tile_Type Fl_Tile_type;
extern class Fl_Input_Choice_Type Fl_Input_Choice_type;
extern class Fl_Choice_Type Fl_Choice_type;
extern class Fl_Menu_Bar_Type Fl_Menu_Bar_type;
extern class Fl_Menu_Button_Type Fl_Menu_Button_type;
extern class Fl_Menu_Item_Type Fl_Menu_Item_type;
extern class Fl_Submenu_Type Fl_Submenu_type;
extern class Fl_Wizard_Type Fl_Wizard_type;
extern class Fl_Box_Type Fl_Box_type;											//Declarado en Fl_Button_Type.cpp
extern class Fl_Button_Type Fl_Button_type;								//Declarado en Fl_Button_Type.cpp
extern class Fl_Return_Button_Type Fl_Return_Button_type;	//Declarado en Fl_Button_Type.cpp
extern class Fl_Repeat_Button_Type Fl_Repeat_Button_type;	//Declarado en Fl_Button_Type.cpp
extern class Fl_Light_Button_Type Fl_Light_Button_type;		//Declarado en Fl_Button_Type.cpp
extern class Fl_Check_Button_Type Fl_Check_Button_type;		//Declarado en Fl_Button_Type.cpp
extern class Fl_Round_Button_Type Fl_Round_Button_type;		//Declarado en Fl_Button_Type.cpp
extern class Fl_Browser_Type Fl_Browser_type;							//Declarado en Fl_Misc_Type.cpp
extern class Fl_Check_Browser_Type Fl_Check_Browser_type;	//Declarado en Fl_Misc_Type.cpp
extern class Fl_File_Browser_Type Fl_File_Browser_type;		//Declarado en Fl_Misc_Type.cpp
extern class Fl_Counter_Type Fl_Counter_type;							//Declarado en Fl_Misc_Type.cpp
extern class Fl_Spinner_Type Fl_Spinner_type;							//Declarado en Fl_Misc_Type.cpp
extern class Fl_Input_Type Fl_Input_type;									//Declarado en Fl_Misc_Type.cpp
extern class Fl_File_Input_Type Fl_File_Input_type;				//Declarado en Fl_Misc_Type.cpp
extern class Fl_Text_Display_Type Fl_Text_Display_type;		//Declarado en Fl_Misc_Type.cpp
extern class Fl_Text_Editor_Type Fl_Text_Editor_type;			//Declarado en Fl_Misc_Type.cpp
extern class Fl_Clock_Type Fl_Clock_type;									//Declarado en Fl_Misc_Type.cpp
extern class Fl_Help_View_Type Fl_Help_View_type;					//Declarado en Fl_Misc_Type.cpp
extern class Fl_Progress_Type Fl_Progress_type;						//Declarado en Fl_Misc_Type.cpp
extern class Fl_Adjuster_Type Fl_Adjuster_type;						//Declarado en Fl_Misc_Type.cpp
extern class Fl_Dial_Type Fl_Dial_type;										//Declarado en Fl_Misc_Type.cpp
extern class Fl_Roller_Type Fl_Roller_type;								//Declarado en Fl_Misc_Type.cpp
extern class Fl_Slider_Type Fl_Slider_type;								//Declarado en Fl_Misc_Type.cpp
extern class Fl_Scrollbar_Type Fl_Scrollbar_type;					//Declarado en Fl_Misc_Type.cpp
extern class Fl_Output_Type Fl_Output_type;								//Declarado en Fl_Misc_Type.cpp
extern class Fl_Value_Input_Type Fl_Value_Input_type;			//Declarado en Fl_Misc_Type.cpp
extern class Fl_Value_Output_Type Fl_Value_Output_type;		//Declarado en Fl_Misc_Type.cpp
extern class Fl_Value_Slider_Type Fl_Value_Slider_type;		//Declarado en Fl_Misc_Type.cpp

int reading_file;
void	*img_to_draw;																				//Imagen utilizada para pintar
																													//en la ventana de diseno la
																													//figura SVG seleccionada de la
																													//biblioteca


extern void select(Fl_Type *,int);
extern void select_only(Fl_Type *);


#if !HAVE_STRCASECMP
//
// 'strcasecmp()' - Do a case-insensitive compare...
//

static int
strcasecmp(const char *s, const char *t) {
  while (*s != '\0' && *t != '\0') {
    if (tolower(*s) < tolower(*t))
      return (-1);
    else if (tolower(*s) > tolower(*t))
      return (1);

    s ++;
    t ++;
  }

  if (*s == '\0' && *t == '\0')
    return (0);
  else if (*s != '\0')
    return (1);
  else
    return (-1);
}
#endif // !HAVE_STRCASECMP


////////////////////////////////////////////////////////////////






#include <FL/Fl_Window.H>

static void cb(Fl_Widget *, void *v) {
  undo_checkpoint();
  undo_suspend();
  Fl_Type *t = ((Fl_Type*)v)->make();
  if (t) {
    if (t->is_widget() && !t->is_window()) {
      Fl_Widget_Type *wt = (Fl_Widget_Type *)t;

      // Set font sizes...
      wt->o->labelsize(Fl_Widget_Type::default_size);

      Fl_Font f;
      int s = Fl_Widget_Type::default_size;
      Fl_Color c;

      wt->textstuff(2, f, s, c);

      // Resize and/or reposition new widget...
      int w = 0, h = 0;
      wt->ideal_size(w, h);

      if (!strcmp(wt->type_name(), "Fl_Menu_Bar")) {
        // Move and resize the menubar across the top of the window...
        wt->o->resize(0, 0, w, h);
      } else {
        // Just resize to the ideal size...
        wt->o->size(w, h);
      }
    }
    select_only(t);
    set_modflag(1);
    t->open();
  } else {
    undo_current --;
    undo_last --;
  }
  undo_resume();
}

extern void graphic_library_cb(Fl_Widget *, void * );

Fl_Menu_Item New_Menu[] = {
{"Codigo",0,0,0,FL_SUBMENU},
  {"Funcion/Metodo",0,cb,(void*)&Fl_Function_type},
  {"Codigo",0,cb,(void*)&Fl_Code_type},
  {"Bloque de Codigo",0,cb,(void*)&Fl_CodeBlock_type},
  {"Declaracion",0,cb,(void*)&Fl_Decl_type},
  {"Bloque de Declaration",0,cb,(void*)&Fl_DeclBlock_type},
  {"Clase",0,cb,(void*)&Fl_Class_type},
  {"Clase Widget",0,cb,(void*)&Fl_Widget_Class_type},
  {"Comentario",0,cb,(void*)&Fl_Comment_type},
{0},
{"Grupo",0,0,0,FL_SUBMENU},
  {0,0,cb,(void*)&Fl_Window_type},
  {0,0,cb,(void*)&Fl_Group_type},
  {0,0,cb,(void*)&Fl_Pack_type},
  {0,0,cb,(void*)&Fl_Tabs_type},
  {0,0,cb,(void*)&Fl_Scroll_type},
  {0,0,cb,(void*)&Fl_Tile_type},
  {0,0,cb,(void*)&Fl_Wizard_type},
{0},
{"Botones",0,0,0,FL_SUBMENU},
  {0,0,cb,(void*)&Fl_Button_type},
  {0,0,cb,(void*)&Fl_Return_Button_type},
  {0,0,cb,(void*)&Fl_Light_Button_type},
  {0,0,cb,(void*)&Fl_Check_Button_type},
  {0,0,cb,(void*)&Fl_Repeat_Button_type},
  {0,0,cb,(void*)&Fl_Round_Button_type},
{0},
{"Actuadores",0,0,0,FL_SUBMENU},
  {0,0,cb,(void*)&Fl_Slider_type},
  {0,0,cb,(void*)&Fl_Scrollbar_type},
  {0,0,cb,(void*)&Fl_Value_Slider_type},
  {0,0,cb,(void*)&Fl_Adjuster_type},
  {0,0,cb,(void*)&Fl_Counter_type},
  {0,0,cb,(void*)&Fl_Spinner_type},
  {0,0,cb,(void*)&Fl_Dial_type},
  {0,0,cb,(void*)&Fl_Roller_type},
  {0,0,cb,(void*)&Fl_Value_Input_type},
  {0,0,cb,(void*)&Fl_Value_Output_type},
{0},
{"Texto",0,0,0,FL_SUBMENU},
  {0,0,cb,(void*)&Fl_File_Input_type},
  {0,0,cb,(void*)&Fl_Input_type},
  {0,0,cb,(void*)&Fl_Output_type},
  {0,0,cb,(void*)&Fl_Text_Display_type},
  {0,0,cb,(void*)&Fl_Text_Editor_type},
{0},
{"Menu",0,0,0,FL_SUBMENU},
  {0,0,cb,(void*)&Fl_Menu_Bar_type},
  {0,0,cb,(void*)&Fl_Menu_Button_type},
  {0,0,cb,(void*)&Fl_Choice_type},
  {0,0,cb,(void*)&Fl_Input_Choice_type},
  {0,0,cb, (void*)&Fl_Submenu_type},
  {0,0,cb, (void*)&Fl_Menu_Item_type},
{0},
{"Navegador",0,0,0,FL_SUBMENU},
  {0,0,cb,(void*)&Fl_Browser_type},
  {0,0,cb,(void*)&Fl_Check_Browser_type},
  {0,0,cb,(void*)&Fl_File_Browser_type},
{0},
{"Otros",0,0,0,FL_SUBMENU},
  {0,0,cb,(void*)&Fl_Box_type},
  {0,0,cb,(void*)&Fl_Clock_type},
  {0,0,cb,(void*)&Fl_Help_View_type},
  {0,0,cb,(void*)&Fl_Progress_type},
{0},
{"Argos",0,0,0,FL_SUBMENU},
  {0,0,cb,(void*)&Arg_Window_type},
  {0,0,cb,(void*)&Arg_Label_type},
  {0,0,cb,(void*)&Arg_Image_type},
  {0,0,cb,(void*)&Arg_Gauge_type},
{0},
{"&Biblioteca de Im�genes",FL_ALT+'b',(Fl_Callback *)graphic_library_cb},
{0}};

#include <FL/Fl_Multi_Label.H>

// modify a menuitem to display an icon in front of the label
static void make_iconlabel( Fl_Menu_Item *mi, Fl_Image *ic, const char *txt )
{
  if (ic) {
    char *t1 = new char[strlen(txt)+6];
    strcpy( t1, " " );
    strcat(t1, txt);
    strcat(t1, "...");
    mi->image( ic );
    Fl_Multi_Label *ml = new Fl_Multi_Label;
    ml->labela = (char*)ic;
    ml->labelb = t1;
    ml->typea = _FL_IMAGE_LABEL;
    ml->typeb = FL_NORMAL_LABEL;
    ml->label( mi );
  }
  else if (txt!=mi->text)
    mi->label(txt);
}

void fill_in_New_Menu() {
  for (unsigned i = 0; i < sizeof(New_Menu)/sizeof(*New_Menu); i++) {
    Fl_Menu_Item *m = New_Menu+i;
    if (m->user_data()) {
      Fl_Type *t = (Fl_Type*)m->user_data();
      if (m->text) {
	make_iconlabel( m, pixmap[t->pixmapID()], m->label() );
      }
      else {
	const char *n = t->type_name();
	if (!strncmp(n,"Fl_",3)) n += 3;
	make_iconlabel( m, pixmap[t->pixmapID()], n );
      }
    }
  }
}

// use keyword to pick the type, this is used to parse files:
Fl_Type *Fl_Type_make(const char *tn) {
  reading_file = 1; // makes labels be null
  Fl_Type *r = 0;
  for (unsigned i = 0; i < sizeof(New_Menu)/sizeof(*New_Menu); i++) {
    Fl_Menu_Item *m = New_Menu+i;
    if (!m->user_data())
		continue;


    Fl_Type *t = (Fl_Type*)(m->user_data());
    if (!strcasecmp(tn,t->type_name())) {
    	r = t->make();
    	break;
	}
  }
  reading_file = 0;
  return r;
}

/*---------------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-FECHA: 25/02/09 ------------------------------------------------
----INICIO ----------------------------------------------------*/

Fl_Type *Fl_Type_make_svg(void *dat) {
  reading_file = 1; // makes labels be null
  img_to_draw = dat;
  Fl_Type *t = (Fl_Type*)(&Arg_SVG_Image_type);
  Fl_Type *r = t->make();
  reading_file = 0;
  return r;
}

/*---FIN --------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-----------------------------------------------------------------
----------------------------------------------------------------*/

////////////////////////////////////////////////////////////////

// Since I have included all the .H files, do this table here:
// This table is only used to read fdesign files:

struct symbol {const char *name; int value;};

static symbol table[] = {
  {"BLACK",	FL_BLACK},
  {"RED",	FL_RED},
  {"GREEN",	FL_GREEN},
  {"YELLOW",	FL_YELLOW},
  {"BLUE",	FL_BLUE},
  {"MAGENTA",	FL_MAGENTA},
  {"CYAN",	FL_CYAN},
  {"WHITE",	FL_WHITE},

  {"LCOL",		 FL_BLACK},
  {"COL1",		 FL_GRAY},
  {"MCOL",		 FL_LIGHT1},
  {"LEFT_BCOL",		 FL_LIGHT3},
  {"TOP_BCOL",		 FL_LIGHT2},
  {"BOTTOM_BCOL",	 FL_DARK2},
  {"RIGHT_BCOL",		 FL_DARK3},
  {"INACTIVE",		 FL_INACTIVE_COLOR},
  {"INACTIVE_COL",	 FL_INACTIVE_COLOR},
  {"FREE_COL1",		 FL_FREE_COLOR},
  {"FREE_COL2",		 FL_FREE_COLOR+1},
  {"FREE_COL3",		 FL_FREE_COLOR+2},
  {"FREE_COL4",		 FL_FREE_COLOR+3},
  {"FREE_COL5",		 FL_FREE_COLOR+4},
  {"FREE_COL6",		 FL_FREE_COLOR+5},
  {"FREE_COL7",		 FL_FREE_COLOR+6},
  {"FREE_COL8",		 FL_FREE_COLOR+7},
  {"FREE_COL9",		 FL_FREE_COLOR+8},
  {"FREE_COL10",		 FL_FREE_COLOR+9},
  {"FREE_COL11",		 FL_FREE_COLOR+10},
  {"FREE_COL12",		 FL_FREE_COLOR+11},
  {"FREE_COL13",		 FL_FREE_COLOR+12},
  {"FREE_COL14",		 FL_FREE_COLOR+13},
  {"FREE_COL15",		 FL_FREE_COLOR+14},
  {"FREE_COL16",		 FL_FREE_COLOR+15},
  {"TOMATO",		 131},
  {"INDIANRED",		 164},
  {"SLATEBLUE",		 195},
  {"DARKGOLD",		 84},
  {"PALEGREEN",		 157},
  {"ORCHID",		 203},
  {"DARKCYAN",		 189},
  {"DARKTOMATO",		 113},
  {"WHEAT",		 174},
  {"ALIGN_CENTER",	FL_ALIGN_CENTER},
  {"ALIGN_TOP",		FL_ALIGN_TOP},
  {"ALIGN_BOTTOM",	FL_ALIGN_BOTTOM},
  {"ALIGN_LEFT",	FL_ALIGN_LEFT},
  {"ALIGN_RIGHT",	FL_ALIGN_RIGHT},
  {"ALIGN_INSIDE",	FL_ALIGN_INSIDE},
  {"ALIGN_TOP_LEFT",	 FL_ALIGN_TOP | FL_ALIGN_LEFT},
  {"ALIGN_TOP_RIGHT",	 FL_ALIGN_TOP | FL_ALIGN_RIGHT},
  {"ALIGN_BOTTOM_LEFT",	 FL_ALIGN_BOTTOM | FL_ALIGN_LEFT},
  {"ALIGN_BOTTOM_RIGHT", FL_ALIGN_BOTTOM | FL_ALIGN_RIGHT},
  {"ALIGN_CENTER|FL_ALIGN_INSIDE",	FL_ALIGN_CENTER|FL_ALIGN_INSIDE},
  {"ALIGN_TOP|FL_ALIGN_INSIDE",		FL_ALIGN_TOP|FL_ALIGN_INSIDE},
  {"ALIGN_BOTTOM|FL_ALIGN_INSIDE",	FL_ALIGN_BOTTOM|FL_ALIGN_INSIDE},
  {"ALIGN_LEFT|FL_ALIGN_INSIDE",	FL_ALIGN_LEFT|FL_ALIGN_INSIDE},
  {"ALIGN_RIGHT|FL_ALIGN_INSIDE",	FL_ALIGN_RIGHT|FL_ALIGN_INSIDE},
  {"ALIGN_INSIDE|FL_ALIGN_INSIDE",	FL_ALIGN_INSIDE|FL_ALIGN_INSIDE},
  {"ALIGN_TOP_LEFT|FL_ALIGN_INSIDE",	FL_ALIGN_TOP|FL_ALIGN_LEFT|FL_ALIGN_INSIDE},
  {"ALIGN_TOP_RIGHT|FL_ALIGN_INSIDE",	FL_ALIGN_TOP|FL_ALIGN_RIGHT|FL_ALIGN_INSIDE},
  {"ALIGN_BOTTOM_LEFT|FL_ALIGN_INSIDE",	FL_ALIGN_BOTTOM|FL_ALIGN_LEFT|FL_ALIGN_INSIDE},
  {"ALIGN_BOTTOM_RIGHT|FL_ALIGN_INSIDE",FL_ALIGN_BOTTOM|FL_ALIGN_RIGHT|FL_ALIGN_INSIDE},

  {"ALIGN_LEFT_TOP",	 FL_ALIGN_TOP | FL_ALIGN_LEFT},
  {"ALIGN_RIGHT_TOP",	 FL_ALIGN_TOP | FL_ALIGN_RIGHT},
  {"ALIGN_LEFT_BOTTOM",	 FL_ALIGN_BOTTOM | FL_ALIGN_LEFT},
  {"ALIGN_RIGHT_BOTTOM", FL_ALIGN_BOTTOM | FL_ALIGN_RIGHT},
  {"INVALID_STYLE",	 255},
  {"NORMAL_STYLE",	 FL_HELVETICA},
  {"BOLD_STYLE",		 FL_HELVETICA|FL_BOLD},
  {"ITALIC_STYLE",	 FL_HELVETICA|FL_ITALIC},
  {"BOLDITALIC_STYLE",	 FL_HELVETICA|FL_BOLD|FL_ITALIC},
  {"FIXED_STYLE",	 FL_COURIER},
  {"FIXEDBOLD_STYLE",	 FL_COURIER|FL_BOLD},
  {"FIXEDITALIC_STYLE",	 FL_COURIER|FL_ITALIC},
  {"FIXEDBOLDITALIC_STYLE",  FL_COURIER|FL_BOLD|FL_ITALIC},
  {"TIMES_STYLE",	 FL_TIMES},
  {"TIMESBOLD_STYLE",	 FL_TIMES|FL_BOLD},
  {"TIMESITALIC_STYLE",	 FL_TIMES|FL_ITALIC},
  {"TIMESBOLDITALIC_STYLE",  FL_TIMES|FL_BOLD|FL_ITALIC},
  {"SHADOW_STYLE",	(_FL_SHADOW_LABEL<<8)},
  {"ENGRAVED_STYLE",	(_FL_ENGRAVED_LABEL<<8)},
  {"EMBOSSED_STYLE",	(_FL_EMBOSSED_LABEL<<0)},
  {"TINY_SIZE",		 8},
  {"SMALL_SIZE",		 11},
  {"NORMAL_SIZE",	 FL_NORMAL_SIZE},
  {"MEDIUM_SIZE",	 18},
  {"LARGE_SIZE",		 24},
  {"HUGE_SIZE",		 32},
  {"DEFAULT_SIZE",	 FL_NORMAL_SIZE},
  {"TINY_FONT",		 8},
  {"SMALL_FONT",		 11},
  {"NORMAL_FONT",	 FL_NORMAL_SIZE},
  {"MEDIUM_FONT",	 18},
  {"LARGE_FONT",		 24},
  {"HUGE_FONT",		 32},
  {"NORMAL_FONT1",	 11},
  {"NORMAL_FONT2",	 FL_NORMAL_SIZE},
  {"DEFAULT_FONT",	 11},
  {"RETURN_END_CHANGED",  0},
  {"RETURN_CHANGED",	 1},
  {"RETURN_END",		 2},
  {"RETURN_ALWAYS",	 3},
  {"PUSH_BUTTON",	FL_TOGGLE_BUTTON},
  {"RADIO_BUTTON",	FL_RADIO_BUTTON},
  {"HIDDEN_BUTTON",	FL_HIDDEN_BUTTON},
  {"SELECT_BROWSER",	FL_SELECT_BROWSER},
  {"HOLD_BROWSER",	FL_HOLD_BROWSER},
  {"MULTI_BROWSER",	FL_MULTI_BROWSER},
  {"SIMPLE_COUNTER",	FL_SIMPLE_COUNTER},
  {"LINE_DIAL",		FL_LINE_DIAL},
  {"FILL_DIAL",		FL_FILL_DIAL},
  {"VERT_SLIDER",	FL_VERT_SLIDER},
  {"HOR_SLIDER",	FL_HOR_SLIDER},
  {"VERT_FILL_SLIDER",	FL_VERT_FILL_SLIDER},
  {"HOR_FILL_SLIDER",	FL_HOR_FILL_SLIDER},
  {"VERT_NICE_SLIDER",	FL_VERT_NICE_SLIDER},
  {"HOR_NICE_SLIDER",	FL_HOR_NICE_SLIDER},
};

#include <stdlib.h>

int lookup_symbol(const char *name, int &v, int numberok) {
  if (name[0]=='F' && name[1]=='L' && name[2]=='_') name += 3;
  for (int i=0; i < int(sizeof(table)/sizeof(*table)); i++)
    if (!strcasecmp(name,table[i].name)) {v = table[i].value; return 1;}
  if (numberok && ((v = atoi(name)) || !strcmp(name,"0"))) return 1;
  return 0;
}

//
// End of "$Id: factory.cxx 5658 2007-02-02 20:09:53Z mike $".
//
