
#include "Fl_Argos_Type.h"

Arg_Label_Type Arg_Label_type;
Arg_Image_Type Arg_Image_type;
Arg_Gauge_Type Arg_Gauge_type;
Arg_SVG_Image_Type	Arg_SVG_Image_type;
