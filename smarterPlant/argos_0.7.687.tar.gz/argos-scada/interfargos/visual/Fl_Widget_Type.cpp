//
// "$Id: Fl_Widget_Type.cxx 6012 2008-01-04 21:45:49Z matt $"
//
// Widget type code for the Fast Light Tool Kit (FLTK).
//
// Copyright 1998-2006 by Bill Spitzak and others.
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Library General Public
// License as published by the Free Software Foundation; either
// version 2 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Library General Public License for more details.
//
// You should have received a copy of the GNU Library General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
// USA.
//
// Please report all bugs and problems on the following page:
//
//     http://www.fltk.org/str.php
//

#include <FL/Fl.H>
#include <FL/Fl_Group.H>
#include <FL/Fl_Input.H>
#include "Fl_Widget_Type.h"
#include "alignment_panel.h"
#include "widget_panel.h"
#include <FL/fl_message.H>
#include <FL/Fl_Slider.H>
#include <FL/Fl_Spinner.H>
#include <FL/Fl_Window.H>
#include "flstring.h"
#include <stdio.h>
#include <stdlib.h>

#include "Fl_Argos_Type.h"

//#include "factory.h"


// Make an Fl_Widget_Type subclass instance.
// It figures out the automatic size and parent of the new widget,
// creates the Fl_Widget (by calling the virtual function _make),
// adds it to the Fl_Widget hierarchy, creates a new Fl_Type
// instance, sets the widget pointers, and makes all the display
// update correctly...

extern int reading_file;
int force_parent;
extern int gridx;
extern int gridy;
extern int i18n_type;
extern const char* i18n_include;
extern const char* i18n_function;
extern const char* i18n_file;
extern const char* i18n_set;
extern Fl_Window *the_panel;					// Declarado en Callbacks.cpp
extern int numselected;
extern Fl_Menu_Item alignmenu[];      // Declarado en Callbacks.cpp
extern Fl_Menu_Item whensymbolmenu[];	// Declarado en Callbacks.cpp
extern void * img_to_draw;						// Declarado en factory.cpp
int Fl_Widget_Type::default_size = FL_NORMAL_SIZE;


// Implementadas en Callbacks.cpp
extern void load_panel();
extern const char* arg_subclassname(Fl_Type*);
extern const char* subclassname(Fl_Type*);
extern int isdeclare(const char *);
extern int is_name(const char *);
extern const char *array_name(Fl_Widget_Type *);
extern const char *boxname(int);
extern const char *item_name(Fl_Menu_Item*, int);
extern int item_number(Fl_Menu_Item*, const char*);
extern int boxnumber(const char *);


int Fl_Widget_Type::is_widget() const {return 1;}
int Fl_Widget_Type::is_public() const {return public_;}


/*---------------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-FECHA: 25/09/09 ------------------------------------------------
----INICIO ----------------------------------------------------*/

int Fl_Widget_Type::is_arg_window() const {return 0;}
int Fl_Widget_Type::is_arg_widget() const {return 0;}
int Fl_Widget_Type::is_arg_image() const {return 0;}
int Fl_Widget_Type::is_arg_gauge() const { return 0; }
int Fl_Widget_Type::arg_type() const {return ARG_NADA;}

void Fl_Widget_Type::expresion(const char *n) {
  storestring(n,expresion_);
}

void Fl_Widget_Type::temporizador(const int n) {
  switch( n ){
    case T_RAPIDO:
    temporizador_ = T_RAPIDO;
  break;
  case T_NORMAL:
    temporizador_ = T_NORMAL;
  break;
  case T_LENTO:
    temporizador_ = T_LENTO;
  break;
  default:
    temporizador_ = T_DESHAB;
  }
}


// Return the ideal widget size...
void
Fl_Widget_Type::ideal_size(int &w, int &h) {
  h = o->labelsize();
  o->measure_label(w, h);

  w += Fl::box_dw(o->box());
  h += Fl::box_dh(o->box());

  if (w < 15) w = 15;
  if (h < 15) h = 15;
}

// Return the ideal widget spacing...
void
Fl_Widget_Type::ideal_spacing(int &x, int &y) {
  if (o->labelsize() < 10)
    x = y = 0;
  else if (o->labelsize() < 14)
    x = y = 5;
  else
    x = y = 10;
}

Fl_Type *Fl_Widget_Type::make() {
  // Find the current widget, or widget to copy:
  Fl_Type *qq = Fl_Type::current;
  while (qq && (!qq->is_widget() || qq->is_menu_item())) qq = qq->parent;
  if (!qq) {
    fl_message("Please select a widget");
    return 0;
  }
  Fl_Widget_Type* q = (Fl_Widget_Type*)qq;
  // find the parent widget:
  Fl_Widget_Type* p = q;
  if ((force_parent || !p->is_group()) && p->parent->is_widget())
    p = (Fl_Widget_Type*)(p->parent);
  force_parent = 0;

  // Figure out a border between widget and window:
  int B = p->o->w()/2; if (p->o->h()/2 < B) B = p->o->h()/2; if (B>25) B = 25;

  int ULX,ULY; // parent's origin in window
  if (!p->is_window()) { // if it is a group, add corner
    ULX = p->o->x(); ULY = p->o->y();
  } else {
    ULX = ULY = 0;
  }

  // Figure out a position and size for the widget
  int X,Y,W,H;
  if (is_group()) {  // fill the parent with the widget
    X = ULX+B;
    W = p->o->w()-B;
    Y = ULY+B;
    H = p->o->h()-B;
  } else if (q != p) {  // copy position and size of current widget
    W = q->o->w();
    H = q->o->h();
    X = q->o->x()+W;
    Y = q->o->y();
    if (X+W > ULX+p->o->w()) {
      X = q->o->x();
      Y = q->o->y()+H;
      if (Y+H > ULY+p->o->h()) Y = ULY+B;
    }
  } else {  // just make it small and square...
    X = ULX+B;
    Y = ULY+B;
    W = H = B;
  }

  // satisfy the grid requirements (otherwise it edits really strangely):
  if (gridx>1) {
    X = (X/gridx)*gridx;
    W = ((W-1)/gridx+1)*gridx;
  }
  if (gridy>1) {
    Y = (Y/gridy)*gridy;
    H = ((H-1)/gridy+1)*gridy;
  }

  // Construct the Fl_Type:
  Fl_Widget_Type *t = _make();
  if (!o){
		switch(t->arg_type()){
			case ARG_SVG_IMAGE:
				if(img_to_draw){
					o = widget(X,Y,W,H,img_to_draw);
				}
				else{
					// Construct the Fl_Widget:
					o = widget(X,Y,W,H);
				}
				break;
			case ARG_NADA:
			default:
				// Construct the Fl_Widget:
				o = widget(X,Y,W,H);
		}
  }
  t->factory = this;

  switch(t->arg_type()){
  	case ARG_SVG_IMAGE:
  		if(img_to_draw){
  			t->o = widget(X,Y,W,H,img_to_draw);
  		}
  		else{
  			// Construct the Fl_Widget:
  			t->o = widget(X,Y,W,H);
  		}
  		break;
  	case ARG_NADA:
  	default:
  		// Construct the Fl_Widget:
  		t->o = widget(X,Y,W,H);
  }
  if (reading_file) t->o->label(0);
  else if (t->o->label()) t->label(t->o->label()); // allow editing
  t->o->user_data((void*)t);
  // Put it in the parent:
  //  ((Fl_Group *)(p->o))->add(t->o); (done by Fl_Type::add())
  // add to browser:
  t->add(p);
  t->redraw();
  return t;
}

#include "Fluid_Image.h"

void Fl_Widget_Type::setimage(Fluid_Image *i) {
  if (i == image || is_window()) return;
  if (image) image->decrement();
  if (i) i->increment();
  image = i;
  if (i) i->image(o);
  else o->image(0);
  redraw();
}

void Fl_Widget_Type::setinactive(Fluid_Image *i) {
  if (i == inactive || is_window()) return;
  if (inactive) inactive->decrement();
  if (i) i->increment();
  inactive = i;
  if (i) i->deimage(o);
  else o->deimage(0);
  redraw();
}

void Fl_Widget_Type::setlabel(const char *n) {
  o->label(n);
  redraw();
}

Fl_Widget_Type::Fl_Widget_Type() {
  for (int n=0; n<NUM_EXTRA_CODE; n++) {extra_code_[n] = 0; subclass_ = 0;}
  hotspot_ = 0;
  tooltip_ = 0;
  image_name_ = 0;
  inactive_name_ = 0;
  image = 0;
  inactive = 0;
  xclass = 0;
  o = 0;
  public_ = 1;

/*---------------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-FECHA: 25/09/09 ------------------------------------------------
----INICIO ----------------------------------------------------*/
  expresion_ = 0;
  temporizador_ = T_DESHAB;
/*---FIN --------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-----------------------------------------------------------------
----------------------------------------------------------------*/
}

Fl_Widget_Type::~Fl_Widget_Type() {
  if (o) {
    o->hide();
    if (o->parent()) ((Fl_Group*)o->parent())->remove(*o);
    delete o;
  }
}

void Fl_Widget_Type::extra_code(int m,const char *n) {
  storestring(n,extra_code_[m]);
}

extern void redraw_browser();
void Fl_Widget_Type::subclass(const char *n) {
  if (storestring(n,subclass_) && visible)
    redraw_browser();
}

void Fl_Widget_Type::tooltip(const char *n) {
  storestring(n,tooltip_);
  o->tooltip(n);
}

void Fl_Widget_Type::image_name(const char *n) {
  setimage(Fluid_Image::find(n));
  storestring(n,image_name_);
}

void Fl_Widget_Type::inactive_name(const char *n) {
  setinactive(Fluid_Image::find(n));
  storestring(n,inactive_name_);
}

void Fl_Widget_Type::redraw() {
  Fl_Type *t = this;
  if (is_menu_item()) {
    // find the menu button that parents this menu:
    do t = t->parent; while (t && t->is_menu_item());
    // kludge to cause build_menu to be called again:
    t->add_child(0,0);
  } else {
    while (t->parent && t->parent->is_widget()) t = t->parent;
    ((Fl_Widget_Type*)t)->o->redraw();
  }
}


uchar Fl_Widget_Type::resizable() const {
  if (is_window()) return ((Fl_Window*)o)->resizable() != 0;
  Fl_Group* p = (Fl_Group*)o->parent();
  if (p) return p->resizable() == o;
  else return 0;
}

void Fl_Widget_Type::resizable(uchar v) {
  if (v) {
    if (resizable()) return;
    if (is_window()) ((Fl_Window*)o)->resizable(o);
    else {
      Fl_Group* p = (Fl_Group*)o->parent();
      if (p) p->resizable(o);
    }
  } else {
    if (!resizable()) return;
    if (is_window()) {
      ((Fl_Window*)o)->resizable(0);
    } else {
      Fl_Group* p = (Fl_Group*)o->parent();
      if (p) p->resizable(0);
    }
  }
}

////////////////////////////////////////////////////////////////

// textstuff: set textfont, textsize, textcolor attributes:

// default widget returns 0 to indicate not-implemented:
int Fl_Widget_Type::textstuff(int, Fl_Font&, int&, Fl_Color&) {return 0;}


// This is called when user double-clicks an item, open or update the panel:
void Fl_Widget_Type::open() {
  if (!the_panel) the_panel = make_widget_panel();
  load_panel();
  if (numselected) the_panel->show();
}


void Fl_Widget_Type::write_static() {
  const char* t = subclassname(this);


  if (!subclass() || (is_class() && !strncmp(t, "Fl_", 3))) {

/*---------------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-FECHA: 25/09/09 ------------------------------------------------
----INICIO ----------------------------------------------------*/
  if( is_arg_window() ){
    write_declare("#include \"Arg_Window.h\"");
  }
  if( is_arg_widget() ){
    write_declare("#include \"%s.h\"", t);
  }
  else{
    write_declare("#include <FL/%s.H>", t);
  }

/*---FIN --------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-----------------------------------------------------------------
----------------------------------------------------------------*/

  }


  for (int n=0; n < NUM_EXTRA_CODE; n++) {
    if (extra_code(n) && isdeclare(extra_code(n)))
      write_declare("%s", extra_code(n));
  }
  if (callback() && is_name(callback())) {
    int write_extern_declaration = 1;
    const Fl_Class_Type *cc = is_in_class();
    char buf[1024]; snprintf(buf, 1023, "%s(*)",  callback());
    if (cc) {
      if (cc->has_function("static void", buf))
        write_extern_declaration = 0;
    } else {
      if (has_toplevel_function(0L, buf))
        write_extern_declaration = 0;
    }
    if (write_extern_declaration)
      write_declare("extern void %s(%s*, %s);", callback(), t,
        user_data_type() ? user_data_type() : "void*");
  }
  const char* k = class_name(1);
  const char* c = array_name(this);
  if (c && !k && !is_class()) {

/*---------------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-FECHA: 25/09/09 ------------------------------------------------
----INICIO ----------------------------------------------------*/
    if( is_arg_widget() ){
      t = arg_subclassname(this);
    }
/*---FIN --------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-----------------------------------------------------------------
----------------------------------------------------------------*/

  write_c("\n");
  if (!public_) write_c("static ");
  else write_h("extern %s *%s;\n", t, c);
  if (strchr(c, '[') == NULL) write_c("%s *%s=(%s *)0;\n", t, c, t);
  else write_c("%s *%s={(%s *)0};\n", t, c, t);
  }
  if (callback() && !is_name(callback())) {
    // see if 'o' or 'v' used, to prevent unused argument warnings:
    int use_o = 0;
    int use_v = 0;
    const char *d;
    for (d = callback(); *d;) {
      if (*d == 'o' && !is_id(d[1])) use_o = 1;
      if (*d == 'v' && !is_id(d[1])) use_v = 1;
      do d++; while (is_id(*d));
      while (*d && !is_id(*d)) d++;
    }
    const char* cn = callback_name();
    if (k) {
      write_c("\nvoid %s::%s_i(%s*", k, cn, t);
    } else {
      write_c("\nstatic void %s(%s*", cn, t);
    }
    if (use_o) write_c(" o");
    const char* ut = user_data_type() ? user_data_type() : "void*";
    write_c(", %s", ut);
    if (use_v) write_c(" v");
    write_c(") {\n  %s", callback());
    if (*(d-1) != ';') {
      const char *p = strrchr(callback(), '\n');
      if (p) p ++;
      else p = callback();
      // Only add trailing semicolon if the last line is not a preprocessor
      // statement...
      if (*p != '#' && *p) write_c(";");
    }
    write_c("\n}\n");
    if (k) {
      write_c("void %s::%s(%s* o, %s v) {\n", k, cn, t, ut);
      write_c("  ((%s*)(o", k);
      Fl_Type *q = 0;
      for (Fl_Type* p = parent; p && p->is_widget(); q = p, p = p->parent)
        write_c("->parent()");
      if (!q || strcmp(q->type_name(), "widget_class"))
        write_c("->user_data()");
      write_c("))->%s_i(o,v);\n}\n", cn);
    }
  }
  if (image) {
    if (image->written != write_number) {
      image->write_static();
      image->written = write_number;
    }
  }
  if (inactive) {
    if (inactive->written != write_number) {
      inactive->write_static();
      inactive->written = write_number;
    }
  }
}

const char *Fl_Type::callback_name() {
  if (is_name(callback())) return callback();
  return unique_id(this, "cb", name(), label());
}

extern int varused_test, varused;

void Fl_Widget_Type::write_code1() {
  const char* t = subclassname(this);
  const char *c = array_name(this);
  if (c) {
    if (class_name(1)) {
      write_public(public_);
      write_h("  %s *%s;\n", t, c);
    }
  }
  if (class_name(1) && callback() && !is_name(callback())) {
    const char* cn = callback_name();
    const char* ut = user_data_type() ? user_data_type() : "void*";
    write_public(0);
    write_h("  void %s_i(%s*, %s);\n", cn, t, ut);
    write_h("  static void %s(%s*, %s);\n", cn, t, ut);
  }
  // figure out if local variable will be used (prevent compiler warnings):
  int wused = !name() && is_window();
  const char *ptr;

  varused = wused;

  if (!name() && !varused) {
    varused |= is_parent();

    if (!varused) {
      varused_test = 1;
      write_widget_code();
      varused_test = 0;
    }
  }

  if (!varused) {
    for (int n=0; n < NUM_EXTRA_CODE; n++)
      if (extra_code(n) && !isdeclare(extra_code(n)))
      {
        int instring = 0;
        int inname = 0;
        for (ptr = extra_code(n); *ptr; ptr ++) {
          if (instring) {
            if (*ptr == '\\') ptr++;
            else if (*ptr == '\"') instring = 0;
          }
          else if (inname && !isalnum(*ptr & 255)) inname = 0;
          else if (*ptr == '\"') instring = 1;
          else if (isalnum(*ptr & 255) || *ptr == '_') {
            size_t len = strspn(ptr, "0123456789_"
                                     "abcdefghijklmnopqrstuvwxyz"
                                     "ABCDEFGHIJKLMNOPQRSTUVWXYZ");
            if (!strncmp(ptr, "o", len)) {
              varused = 1;
              break;
            } else ptr += len - 1;
          }
        }
      }
  }

  write_c("%s{ ", indent());
  if (varused) write_c("%s* o = ", t);
  if (name()) write_c("%s = ", name());
  if (is_window()) {
    // Handle special case where user is faking a Fl_Group type as a window,
    // there is no 2-argument constructor in that case:
    if (!strstr(t, "Window"))
      write_c("new %s(0, 0, %d, %d", t, o->w(), o->h());
    else
      write_c("new %s(%d, %d", t, o->w(), o->h());
  } else {
    write_c("new %s(%d, %d, %d, %d", t, o->x(), o->y(), o->w(), o->h());
  }
  if (label() && *label()) {
    write_c(", ");
    switch (i18n_type) {
    case 0 : /* None */
      write_cstring(label());
      break;
    case 1 : /* GNU gettext */
      write_c("%s(", i18n_function);
      write_cstring(label());
      write_c(")");
      break;
    case 2 : /* POSIX catgets */
      write_c("catgets(%s,%s,%d,", i18n_file[0] ? i18n_file : "_catalog", i18n_set, msgnum());
      write_cstring(label());
      write_c(")");
      break;
    }
  }
  write_c(");\n");

  indentation += 2;

  if (wused) write_c("%sw = o;\n", indent());

  write_widget_code();
}



/*---------------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-FECHA: 25/09/09 ------------------------------------------------
----INICIO ----------------------------------------------------*/

void Fl_Widget_Type::write_code1_arg() {
  const char* t = subclassname(this);
  const char *c = array_name(this);
  if (c) {
    if (class_name(1)) {
      write_public(public_);
      write_h("  %s *%s;\n", t, c);
    }
  }
  if (class_name(1) && callback() && !is_name(callback())) {
    const char* cn = callback_name();
    const char* ut = user_data_type() ? user_data_type() : "void*";
    write_public(0);
    write_h("  void %s_i(%s*, %s);\n", cn, t, ut);
    write_h("  static void %s(%s*, %s);\n", cn, t, ut);
  }
  // figure out if local variable will be used (prevent compiler warnings):
  int wused = !name() && is_window();
  const char *ptr;

  varused = wused;

  if (!name() && !varused) {
    varused |= is_parent();

    if (!varused) {
      varused_test = 1;
      write_widget_code();
      varused_test = 0;
    }
  }

  if (!varused) {
    for (int n=0; n < NUM_EXTRA_CODE; n++)
      if (extra_code(n) && !isdeclare(extra_code(n))) {
        int instring = 0;
        int inname = 0;
        for (ptr = extra_code(n); *ptr; ptr ++) {
          if (instring) {
            if (*ptr == '\\') ptr++;
            else if (*ptr == '\"') instring = 0;
          }
          else if (inname && !isalnum(*ptr & 255)) inname = 0;
          else if (*ptr == '\"') instring = 1;
          else if (isalnum(*ptr & 255) || *ptr == '_') {
            size_t len = strspn(ptr, "0123456789_"
                                     "abcdefghijklmnopqrstuvwxyz"
                                     "ABCDEFGHIJKLMNOPQRSTUVWXYZ");
            if (!strncmp(ptr, "o", len)) {
              varused = 1;
              break;
            } else ptr += len - 1;
          }
        }
      }
  }

  write_c( "%sfl_register_images();\n", indent() );

  write_c("%s{ ", indent());

  if (varused) write_c("%s* o = ", t);
  if (name()) write_c("%s = ", name());
  if (is_window()) {
    // Handle special case where user is faking a Fl_Group type as a window,
    // there is no 2-argument constructor in that case:
    if (!strstr(t, "Window"))
      write_c("new %s(0, 0, %d, %d", t, o->w(), o->h());
    else{
      if( is_arg_window() ){
        Arg_Window_Type * aw = (Arg_Window_Type *)this;
        write_c("new Arg_Window(%d, %d, \"%s\",\"%s\"",
          o->w(), o->h(), aw->s_tags() ? aw->s_tags() : "",
          aw->s_alarmas() ? aw->s_alarmas() : "" );
      }
      else{
        write_c("new Arg_Window(%d, %d", o->w(), o->h());
      }
    }
  } else {
    write_c("new %s(%d, %d, %d, %d", t, o->x(), o->y(), o->w(), o->h());
  }
  if (label() && *label()) {
    write_c(", ");
    switch (i18n_type) {
    case 0 : /* None */
      write_cstring(label());
      break;
    case 1 : /* GNU gettext */
      write_c("%s(", i18n_function);
      write_cstring(label());
      write_c(")");
      break;
    case 2 : /* POSIX catgets */
      write_c("catgets(%s,%s,%d,", i18n_file[0] ? i18n_file : "_catalog", i18n_set, msgnum());
      write_cstring(label());
      write_c(")");
      break;
    }
  }
  write_c(");\n");

  indentation += 2;

  if (wused) write_c("%sw = o;\n", indent());

  write_widget_code();

}

/*---FIN --------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-----------------------------------------------------------------
----------------------------------------------------------------*/





void Fl_Widget_Type::write_color(const char* field, Fl_Color color) {
  const char* color_name = 0;
  switch (color) {
  case FL_FOREGROUND_COLOR:  color_name = "FL_FOREGROUND_COLOR";  break;
  case FL_BACKGROUND2_COLOR:  color_name = "FL_BACKGROUND2_COLOR";  break;
  case FL_INACTIVE_COLOR:  color_name = "FL_INACTIVE_COLOR";  break;
  case FL_SELECTION_COLOR:  color_name = "FL_SELECTION_COLOR";  break;
  case FL_GRAY0:    color_name = "FL_GRAY0";    break;
  case FL_DARK3:    color_name = "FL_DARK3";    break;
  case FL_DARK2:    color_name = "FL_DARK2";    break;
  case FL_DARK1:    color_name = "FL_DARK1";    break;
  case FL_BACKGROUND_COLOR:  color_name = "FL_BACKGROUND_COLOR";  break;
  case FL_LIGHT1:    color_name = "FL_LIGHT1";    break;
  case FL_LIGHT2:    color_name = "FL_LIGHT2";    break;
  case FL_LIGHT3:    color_name = "FL_LIGHT3";    break;
  case FL_BLACK:    color_name = "FL_BLACK";    break;
  case FL_RED:      color_name = "FL_RED";      break;
  case FL_GREEN:    color_name = "FL_GREEN";    break;
  case FL_YELLOW:    color_name = "FL_YELLOW";    break;
  case FL_BLUE:      color_name = "FL_BLUE";      break;
  case FL_MAGENTA:    color_name = "FL_MAGENTA";    break;
  case FL_CYAN:      color_name = "FL_CYAN";      break;
  case FL_DARK_RED:    color_name = "FL_DARK_RED";    break;
  case FL_DARK_GREEN:    color_name = "FL_DARK_GREEN";    break;
  case FL_DARK_YELLOW:    color_name = "FL_DARK_YELLOW";    break;
  case FL_DARK_BLUE:    color_name = "FL_DARK_BLUE";    break;
  case FL_DARK_MAGENTA:    color_name = "FL_DARK_MAGENTA";    break;
  case FL_DARK_CYAN:    color_name = "FL_DARK_CYAN";    break;
  case FL_WHITE:    color_name = "FL_WHITE";    break;
  }
  const char *var = is_class() ? "this" : name() ? name() : "o";
  if (color_name) {
    write_c("%s%s->%s(%s);\n", indent(), var, field, color_name);
  } else {
    write_c("%s%s->%s((Fl_Color)%d);\n", indent(), var, field, color);
  }
}

// this is split from write_code1() for Fl_Window_Type:
void Fl_Widget_Type::write_widget_code() {
  Fl_Widget* tplate = ((Fl_Widget_Type*)factory)->o;
  const char *var = is_class() ? "this" : name() ? name() : "o";

  if (tooltip() && *tooltip()) {
    write_c("%s%s->tooltip(",indent(), var);
    switch (i18n_type) {
      case 0 : /* None */
        write_cstring(tooltip());
        break;
      case 1 : /* GNU gettext */
        write_c("%s(", i18n_function);
        write_cstring(tooltip());
        write_c(")");
        break;
      case 2 : /* POSIX catgets */
        write_c("catgets(%s,%s,%d,", i18n_file[0] ? i18n_file : "_catalog", i18n_set, msgnum() + 1);
        write_cstring(tooltip());
        write_c(")");
        break;
    }
    write_c(");\n");
  }

  if (is_spinner() && ((Fl_Spinner*)o)->type() != ((Fl_Spinner*)tplate)->type())
    write_c("%s%s->type(%d);\n", indent(), var, ((Fl_Spinner*)o)->type());
  else if (o->type() != tplate->type() && !is_window())
    write_c("%s%s->type(%d);\n", indent(), var, o->type());
  if (o->box() != tplate->box() || subclass())
    write_c("%s%s->box(FL_%s);\n", indent(), var, boxname(o->box()));
  if (is_button()) {
    Fl_Button* b = (Fl_Button*)o;
    if (b->down_box()) write_c("%s%s->down_box(FL_%s);\n", indent(), var, boxname(b->down_box()));
    if (b->value()) write_c("%s%s->value(1);\n", indent(), var);
    if (b->shortcut()) {
      int s = b->shortcut();
      if (use_FL_COMMAND && (s & (FL_CTRL|FL_META))) {
        write_c("%s%s->shortcut(FL_COMMAND|0x%x);\n", indent(), var, s & ~(FL_CTRL|FL_META));
      } else {
        write_c("%s%s->shortcut(0x%x);\n", indent(), var, s);
      }
    }
  } else if (!strcmp(type_name(), "Fl_Input_Choice")) {
    Fl_Input_Choice* b = (Fl_Input_Choice*)o;
    if (b->down_box()) write_c("%s%s->down_box(FL_%s);\n", indent(), var, boxname(b->down_box()));
  } else if (is_menu_button()) {
    Fl_Menu_* b = (Fl_Menu_*)o;
    if (b->down_box()) write_c("%s%s->down_box(FL_%s);\n", indent(), var, boxname(b->down_box()));
  }
  if (o->color() != tplate->color() || subclass())
    write_color("color", o->color());
  if (o->selection_color() != tplate->selection_color() || subclass())
    write_color("selection_color", o->selection_color());
  if (image) image->write_code(var);
  if (inactive) inactive->write_code(var, 1);
  if (o->labeltype() != tplate->labeltype() || subclass())
    write_c("%s%s->labeltype(FL_%s);\n", indent(), var, item_name(labeltypemenu, o->labeltype()));
  if (o->labelfont() != tplate->labelfont() || subclass())
    write_c("%s%s->labelfont(%d);\n", indent(), var, o->labelfont());
  if (o->labelsize() != tplate->labelsize() || subclass())
    write_c("%s%s->labelsize(%d);\n", indent(), var, o->labelsize());
  if (o->labelcolor() != tplate->labelcolor() || subclass())
    write_color("labelcolor", o->labelcolor());
  if (is_valuator()) {
    Fl_Valuator* v = (Fl_Valuator*)o;
    Fl_Valuator* f = (Fl_Valuator*)(tplate);
    if (v->minimum()!=f->minimum())
      write_c("%s%s->minimum(%g);\n", indent(), var, v->minimum());
    if (v->maximum()!=f->maximum())
      write_c("%s%s->maximum(%g);\n", indent(), var, v->maximum());
    if (v->step()!=f->step())
      write_c("%s%s->step(%g);\n", indent(), var, v->step());
    if (v->value()) {
      if (is_valuator()==3) { // Fl_Scrollbar::value(double) is nott available
        write_c("%s%s->Fl_Slider::value(%g);\n", indent(), var, v->value());
      } else {
        write_c("%s%s->value(%g);\n", indent(), var, v->value());
      }
    }
    if (is_valuator()>=2) {
      double x = ((Fl_Slider*)v)->slider_size();
      double y = ((Fl_Slider*)f)->slider_size();
      if (x != y) write_c("%s%s->slider_size(%g);\n", indent(), var, x);
    }
  }
  if (is_spinner()) {
    Fl_Spinner* v = (Fl_Spinner*)o;
    Fl_Spinner* f = (Fl_Spinner*)(tplate);
    if (v->minimum()!=f->minimum())
      write_c("%s%s->minimum(%g);\n", indent(), var, v->minimum());
    if (v->maximum()!=f->maximum())
      write_c("%s%s->maximum(%g);\n", indent(), var, v->maximum());
    if (v->step()!=f->step())
      write_c("%s%s->step(%g);\n", indent(), var, v->step());
    if (v->value())
      write_c("%s%s->value(%g);\n", indent(), var, v->value());
  }

  {Fl_Font ff; int fs; Fl_Color fc; if (textstuff(4,ff,fs,fc)) {
    Fl_Font f; int s; Fl_Color c; textstuff(0,f,s,c);
    if (f != ff) write_c("%s%s->textfont(%d);\n", indent(), var, f);
    if (s != fs) write_c("%s%s->textsize(%d);\n", indent(), var, s);
    if (c != fc) write_c("%s%s->textcolor(%d);\n",indent(), var, c);
  }}
  const char* ud = user_data();
  if (class_name(1) && !parent->is_widget()) ud = "this";
  if (callback()) {
    write_c("%s%s->callback((Fl_Callback*)%s", indent(), var, callback_name());
    if (ud)
      write_c(", (void*)(%s));\n", ud);
    else
      write_c(");\n");
  } else if (ud) {
    write_c("%s%s->user_data((void*)(%s));\n", indent(), var, ud);
  }
  if (o->align() != tplate->align() || subclass()) {
    int i = o->align();
    write_c("%s%s->align(%s", indent(), var, item_name(alignmenu, i & ~FL_ALIGN_INSIDE));
    if (i & FL_ALIGN_INSIDE) write_c("|FL_ALIGN_INSIDE");
    write_c(");\n");
  }
  // avoid the unsupported combination of flegs when user sets
  // "when" to "FL_WHEN_NEVER", but keeps the "no change" set.
  // FIXME: This could be reflected in the GUI by graying out the button.
  Fl_When ww = o->when();
  if (ww==FL_WHEN_NOT_CHANGED)
    ww = FL_WHEN_NEVER;
  if (ww != tplate->when() || subclass())
    write_c("%s%s->when(%s);\n", indent(), var,
            item_name(whensymbolmenu, ww));
  if (!o->visible() && o->parent())
    write_c("%s%s->hide();\n", indent(), var);
  if (!o->active())
    write_c("%s%s->deactivate();\n", indent(), var);
  if (!is_group() && resizable())
    write_c("%sFl_Group::current()->resizable(%s);\n", indent(), var);
  if (hotspot()) {
    if (is_class())
      write_c("%shotspot(%s);\n", indent(), var);
    else if (is_window())
      write_c("%s%s->hotspot(%s);\n", indent(), var, var);
    else
      write_c("%s%s->window()->hotspot(%s);\n", indent(), var, var);
  }


/*---------------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-FECHA: 25/09/09 ------------------------------------------------
----INICIO ----------------------------------------------------*/

  if(is_arg_widget()){
    const char * t = subclassname(this);

    switch( arg_type() ){
      case ARG_IMAGE: {
        Arg_Image_Type * ai = (Arg_Image_Type *)this;
        write_c("%s((%s *)%s)->asignar_imagenes(\"%s\",\"%s\",\"%s\");\n",
            indent(), t, var,
            ai->arch_imagen(0) ? ai->arch_imagen(0) : " ",
            ai->arch_imagen(1) ? ai->arch_imagen(1) : " ",
            ai->arch_imagen(2) ? ai->arch_imagen(2) : " ");
        break;
      }
      case ARG_GAUGE: {
        //TODO: Escribir el código para la configuración del widget
        //Arg_Gauge_Type * ag = (Arg_Gauge_Type *)this;
        write_c("//Widget en desarrollo. Para modificar las caracteristicas del mismo, debe\n");
        write_c("//editar el código que sigue a continuación. A medida que se vayan añadiendo\n");
        write_c("//elementos a la interfaz, se irán eliminado de aqui.\n");
        write_c("%s((%s *)%s)->stepdiv(5);\n", indent(), t, var);
        write_c("%s((%s *)%s)->framecolor(FL_GREEN);\n", indent(), t, var);
        write_c("%s((%s *)%s)->v2color(FL_DARK_MAGENTA);\n", indent(), t, var);
        write_c("%s((%s *)%s)->fontsize(8);\n", indent(), t, var);
        break;
      }
    }

    if( expresion() && *expresion() ){
      write_c("%s((%s *)%s)->asignar_expresion(\"%s\");\n", indent(), t, var, expresion());
      switch(temporizador()){
        case 1:
          write_c("%s((Arg_Window *)%s->window())->registrar_timer_lento( (%s *)(%s) );\n",
            indent(), var, t, var );
          break;
        case 2:
          write_c("%s((Arg_Window *)%s->window())->registrar_timer_normal( (%s *)(%s) );\n",
            indent(), var, t, var );
          break;
        case 3:
          write_c("%s((Arg_Window *)%s->window())->registrar_timer_rapido( (%s *)(%s) );\n",
            indent(), var, t, var );
          break;
        case 0:
        default:
          write_c("%s//temporizado no registrado\n", indent() );
      }
    }
  }


/*---FIN --------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-----------------------------------------------------------------
----------------------------------------------------------------*/


}


void Fl_Widget_Type::write_extra_code() {
  for (int n=0; n < NUM_EXTRA_CODE; n++)
    if (extra_code(n) && !isdeclare(extra_code(n)))
      write_c("%s%s\n", indent(), extra_code(n));
}

void Fl_Widget_Type::write_block_close() {
  indentation -= 2;
  write_c("%s} // %s* %s\n", indent(), subclassname(this),
          name() ? name() : "o");
}

void Fl_Widget_Type::write_code2() {
  write_extra_code();
  write_block_close();
}

////////////////////////////////////////////////////////////////

void Fl_Widget_Type::write_properties() {
  Fl_Type::write_properties();
  write_indent(level+1);
  switch (public_) {
    case 0: write_string("private"); break;
    case 1: break;
    case 2: write_string("protected"); break;
  }
  if (tooltip() && *tooltip()) {
    write_string("tooltip");
    write_word(tooltip());
  }
  if (image_name() && *image_name()) {
    write_string("image");
    write_word(image_name());
  }
  if (inactive_name() && *inactive_name()) {
    write_string("deimage");
    write_word(inactive_name());
  }
  write_string("xywh {%d %d %d %d}", o->x(), o->y(), o->w(), o->h());
  Fl_Widget* tplate = ((Fl_Widget_Type*)factory)->o;
  if (is_spinner() && ((Fl_Spinner*)o)->type() != ((Fl_Spinner*)tplate)->type()) {
    write_string("type");
    write_word(item_name(subtypes(), ((Fl_Spinner*)o)->type()));
  } else if (o->type() != tplate->type() || is_window()) {
    write_string("type");
    write_word(item_name(subtypes(), o->type()));
  }
  if (o->box() != tplate->box()) {
    write_string("box"); write_word(boxname(o->box()));}
  if (is_button()) {
    Fl_Button* b = (Fl_Button*)o;
    if (b->down_box()) {
      write_string("down_box"); write_word(boxname(b->down_box()));}
    if (b->shortcut()) write_string("shortcut 0x%x", b->shortcut());
    if (b->value()) write_string("value 1");
  } else if (!strcmp(type_name(), "Fl_Input_Choice")) {
    Fl_Input_Choice* b = (Fl_Input_Choice*)o;
    if (b->down_box()) {
      write_string("down_box"); write_word(boxname(b->down_box()));}
  } else if (is_menu_button()) {
    Fl_Menu_* b = (Fl_Menu_*)o;
    if (b->down_box()) {
      write_string("down_box"); write_word(boxname(b->down_box()));}
  }
  if (o->color()!=tplate->color())
    write_string("color %d", o->color());
  if (o->selection_color()!=tplate->selection_color())
    write_string("selection_color %d", o->selection_color());
  if (o->labeltype()!=tplate->labeltype()) {
    write_string("labeltype");
    write_word(item_name(labeltypemenu, o->labeltype()));
  }
  if (o->labelfont()!=tplate->labelfont())
    write_string("labelfont %d", o->labelfont());
  if (o->labelsize()!=tplate->labelsize())
    write_string("labelsize %d", o->labelsize());
  if (o->labelcolor()!=tplate->labelcolor())
    write_string("labelcolor %d", o->labelcolor());
  if (o->align()!=tplate->align())
    write_string("align %d", o->align());
  if (o->when() != tplate->when())
    write_string("when %d", o->when());
  if (is_valuator()) {
    Fl_Valuator* v = (Fl_Valuator*)o;
    Fl_Valuator* f = (Fl_Valuator*)(tplate);
    if (v->minimum()!=f->minimum()) write_string("minimum %g",v->minimum());
    if (v->maximum()!=f->maximum()) write_string("maximum %g",v->maximum());
    if (v->step()!=f->step()) write_string("step %g",v->step());
    if (v->value()!=0.0) write_string("value %g",v->value());
    if (is_valuator()>=2) {
      double x = ((Fl_Slider*)v)->slider_size();
      double y = ((Fl_Slider*)f)->slider_size();
      if (x != y) write_string("slider_size %g", x);
    }
  }
  if (is_spinner()) {
    Fl_Spinner* v = (Fl_Spinner*)o;
    Fl_Spinner* f = (Fl_Spinner*)(tplate);
    if (v->minimum()!=f->minimum()) write_string("minimum %g",v->minimum());
    if (v->maximum()!=f->maximum()) write_string("maximum %g",v->maximum());
    if (v->step()!=f->step()) write_string("step %g",v->step());
    if (v->value()!=0.0) write_string("value %g",v->value());
  }
  {Fl_Font ff; int fs; Fl_Color fc; if (textstuff(4,ff,fs,fc)) {
    Fl_Font f; int s; Fl_Color c; textstuff(0,f,s,c);
    if (f != ff) write_string("textfont %d", f);
    if (s != fs) write_string("textsize %d", s);
    if (c != fc) write_string("textcolor %d", c);
  }}
  if (!o->visible()) write_string("hide");
  if (!o->active()) write_string("deactivate");
  if (resizable()) write_string("resizable");
  if (hotspot()) write_string(is_menu_item() ? "divider" : "hotspot");
  for (int n=0; n < NUM_EXTRA_CODE; n++) if (extra_code(n)) {
    write_indent(level+1);
    write_string("code%d",n);
    write_word(extra_code(n));
  }
  if (subclass()) {
    write_indent(level+1);
    write_string("class");
    write_word(subclass());
  }
}

int pasteoffset;

void Fl_Widget_Type::read_property(const char *c) {
  int x,y,w,h; Fl_Font f; int s; Fl_Color cc;
  if (!strcmp(c,"private")) {
    public_ = 0;
  } else if (!strcmp(c,"protected")) {
    public_ = 2;
  } else if (!strcmp(c,"xywh")) {
    if (sscanf(read_word(),"%d %d %d %d",&x,&y,&w,&h) == 4) {
      x += pasteoffset;
      y += pasteoffset;
      o->resize(x,y,w,h);
    }
  } else if (!strcmp(c,"tooltip")) {
    tooltip(read_word());
  } else if (!strcmp(c,"image")) {
    image_name(read_word());
  } else if (!strcmp(c,"deimage")) {
    inactive_name(read_word());
  } else if (!strcmp(c,"type")) {
    if (is_spinner())
      ((Fl_Spinner*)o)->type(item_number(subtypes(), read_word()));
    else
      o->type(item_number(subtypes(), read_word()));
  } else if (!strcmp(c,"box")) {
    const char* value = read_word();
    if ((x = boxnumber(value))) {
      if (x == ZERO_ENTRY) x = 0;
      o->box((Fl_Boxtype)x);
    } else if (sscanf(value,"%d",&x) == 1) o->box((Fl_Boxtype)x);
  } else if (is_button() && !strcmp(c,"down_box")) {
    const char* value = read_word();
    if ((x = boxnumber(value))) {
      if (x == ZERO_ENTRY) x = 0;
      ((Fl_Button*)o)->down_box((Fl_Boxtype)x);
    }
  } else if (!strcmp(type_name(), "Fl_Input_Choice") && !strcmp(c,"down_box")) {
    const char* value = read_word();
    if ((x = boxnumber(value))) {
      if (x == ZERO_ENTRY) x = 0;
      ((Fl_Input_Choice*)o)->down_box((Fl_Boxtype)x);
    }
  } else if (is_menu_button() && !strcmp(c,"down_box")) {
    const char* value = read_word();
    if ((x = boxnumber(value))) {
      if (x == ZERO_ENTRY) x = 0;
      ((Fl_Menu_*)o)->down_box((Fl_Boxtype)x);
    }
  } else if (is_button() && !strcmp(c,"value")) {
    const char* value = read_word();
    ((Fl_Button*)o)->value(atoi(value));
  } else if (!strcmp(c,"color")) {
    int n = sscanf(read_word(),"%d %d",&x,&y);
    if (n == 2) { // back compatability...
      if (x != 47) o->color(x);
      o->selection_color(y);
    } else {
      o->color(x);
    }
  } else if (!strcmp(c,"selection_color")) {
    if (sscanf(read_word(),"%d",&x)) o->selection_color(x);
  } else if (!strcmp(c,"labeltype")) {
    c = read_word();
    if (!strcmp(c,"image")) {
      Fluid_Image *i = Fluid_Image::find(label());
      if (!i) read_error("Image file '%s' not found", label());
      else setimage(i);
      image_name(label());
      label("");
    } else {
      o->labeltype((Fl_Labeltype)item_number(labeltypemenu,c));
    }
  } else if (!strcmp(c,"labelfont")) {
    if (sscanf(read_word(),"%d",&x) == 1) o->labelfont(x);
  } else if (!strcmp(c,"labelsize")) {
    if (sscanf(read_word(),"%d",&x) == 1) o->labelsize(x);
  } else if (!strcmp(c,"labelcolor")) {
    if (sscanf(read_word(),"%d",&x) == 1) o->labelcolor(x);
  } else if (!strcmp(c,"align")) {
    if (sscanf(read_word(),"%d",&x) == 1) o->align(x);
  } else if (!strcmp(c,"when")) {
    if (sscanf(read_word(),"%d",&x) == 1) o->when(x);
  } else if (!strcmp(c,"minimum")) {
    if (is_valuator()) ((Fl_Valuator*)o)->minimum(strtod(read_word(),0));
    if (is_spinner()) ((Fl_Spinner*)o)->minimum(strtod(read_word(),0));
  } else if (!strcmp(c,"maximum")) {
    if (is_valuator()) ((Fl_Valuator*)o)->maximum(strtod(read_word(),0));
    if (is_spinner()) ((Fl_Spinner*)o)->maximum(strtod(read_word(),0));
  } else if (!strcmp(c,"step")) {
    if (is_valuator()) ((Fl_Valuator*)o)->step(strtod(read_word(),0));
    if (is_spinner()) ((Fl_Spinner*)o)->step(strtod(read_word(),0));
  } else if (!strcmp(c,"value")) {
    if (is_valuator()) ((Fl_Valuator*)o)->value(strtod(read_word(),0));
    if (is_spinner()) ((Fl_Spinner*)o)->value(strtod(read_word(),0));
  } else if ((!strcmp(c,"slider_size")||!strcmp(c,"size"))&&is_valuator()==2) {
    ((Fl_Slider*)o)->slider_size(strtod(read_word(),0));
  } else if (!strcmp(c,"textfont")) {
    if (sscanf(read_word(),"%d",&x) == 1) {f=(Fl_Font)x; textstuff(1,f,s,cc);}
  } else if (!strcmp(c,"textsize")) {
    if (sscanf(read_word(),"%d",&x) == 1) {s=x; textstuff(2,f,s,cc);}
  } else if (!strcmp(c,"textcolor")) {
    if (sscanf(read_word(),"%d",&x) == 1) {cc=(Fl_Color)x;textstuff(3,f,s,cc);}
  } else if (!strcmp(c,"hide")) {
    o->hide();
  } else if (!strcmp(c,"deactivate")) {
    o->deactivate();
  } else if (!strcmp(c,"resizable")) {
    resizable(1);
  } else if (!strcmp(c,"hotspot") || !strcmp(c, "divider")) {
    hotspot(1);
  } else if (!strcmp(c,"class")) {
    subclass(read_word());
  } else if (is_button() && !strcmp(c,"shortcut")) {
    ((Fl_Button*)o)->shortcut(strtol(read_word(),0,0));
  } else {
    if (!strncmp(c,"code",4)) {
      int n = atoi(c+4);
      if (n >= 0 && n <= NUM_EXTRA_CODE) {
  extra_code(n,read_word());
  return;
      }
    }
    Fl_Type::read_property(c);
  }
}

Fl_Menu_Item boxmenu1[] = {
  // these extra ones are for looking up fdesign saved strings:
  {"NO_FRAME",    0,0,(void *)FL_NO_BOX},
  {"ROUNDED3D_UPBOX",  0,0,(void *)_FL_ROUND_UP_BOX},
  {"ROUNDED3D_DOWNBOX",  0,0,(void *)_FL_ROUND_DOWN_BOX},
  {"OVAL3D_UPBOX",  0,0,(void *)_FL_ROUND_UP_BOX},
  {"OVAL3D_DOWNBOX",  0,0,(void *)_FL_ROUND_DOWN_BOX},
  {"0",      0,0,(void *)ZERO_ENTRY},
  {"1",      0,0,(void *)FL_UP_BOX},
  {"2",      0,0,(void *)FL_DOWN_BOX},
  {"3",      0,0,(void *)FL_FLAT_BOX},
  {"4",      0,0,(void *)FL_BORDER_BOX},
  {"5",      0,0,(void *)FL_SHADOW_BOX},
  {"6",      0,0,(void *)FL_FRAME_BOX},
  {"7",      0,0,(void *)FL_ROUNDED_BOX},
  {"8",      0,0,(void *)FL_RFLAT_BOX},
  {"9",      0,0,(void *)FL_RSHADOW_BOX},
  {"10",    0,0,(void *)FL_UP_FRAME},
  {"11",    0,0,(void *)FL_DOWN_FRAME},
{0}};

extern int fdesign_flip;
int lookup_symbol(const char *, int &, int numberok = 0);

int Fl_Widget_Type::read_fdesign(const char* propname, const char* value) {
  int v;
  if (!strcmp(propname,"box")) {
    float x,y,w,h;
    if (sscanf(value,"%f %f %f %f",&x,&y,&w,&h) == 4) {
      if (fdesign_flip) {
        Fl_Type *p;
        for (p = parent; p && !p->is_window(); p = p->parent);
        if (p && p->is_widget()) y = ((Fl_Widget_Type*)p)->o->h()-(y+h);
      }
      x += pasteoffset;
      y += pasteoffset;
      o->resize(int(x),int(y),int(w),int(h));
    }
  } else if (!strcmp(propname,"label")) {
    label(value);
  } else if (!strcmp(propname,"name")) {
    this->name(value);
  } else if (!strcmp(propname,"callback")) {
    callback(value); user_data_type("long");
  } else if (!strcmp(propname,"argument")) {
    user_data(value);
  } else if (!strcmp(propname,"shortcut")) {
    if (value[0]) {
      char buf[128]; sprintf(buf,"o->shortcut(\"%s\");",value);
      extra_code(0,buf);
    }
  } else if (!strcmp(propname,"style")) {
    if (!strncmp(value,"FL_NORMAL",9)) return 1;
    if (!lookup_symbol(value,v,1)) return 0;
    o->labelfont(v); o->labeltype((Fl_Labeltype)(v>>8));
  } else if (!strcmp(propname,"size")) {
    if (!lookup_symbol(value,v,1)) return 0;
    o->labelsize(v);
  } else if (!strcmp(propname,"type")) {
    if (!strncmp(value,"NORMAL",6)) return 1;
    if (lookup_symbol(value,v,1)) {o->type(v); return 1;}
    if (!strcmp(value+strlen(value)-5,"FRAME")) goto TRY_BOXTYPE;
    if (!strcmp(value+strlen(value)-3,"BOX")) goto TRY_BOXTYPE;
    return 0;
  } else if (!strcmp(propname,"lcol")) {
    if (!lookup_symbol(value,v,1)) return 0;
    o->labelcolor(v);
  } else if (!strcmp(propname,"return")) {
    if (!lookup_symbol(value,v,0)) return 0;
    o->when(v|FL_WHEN_RELEASE);
  } else if (!strcmp(propname,"alignment")) {
    if (!lookup_symbol(value,v)) {
      // convert old numeric values:
      int v1 = atoi(value); if (v1 <= 0 && strcmp(value,"0")) return 0;
      v = 0;
      if (v1 >= 5) {v = FL_ALIGN_INSIDE; v1 -= 5;}
      switch (v1) {
      case 0: v += FL_ALIGN_TOP; break;
      case 1: v += FL_ALIGN_BOTTOM; break;
      case 2: v += FL_ALIGN_LEFT; break;
      case 3: v += FL_ALIGN_RIGHT; break;
      case 4: v += FL_ALIGN_CENTER; break;
      default: return 0;
      }
    }
    o->align(v);
  } else if (!strcmp(propname,"resizebox")) {
    resizable(1);
  } else if (!strcmp(propname,"colors")) {
    char* p = (char*)value;
    while (*p != ' ') {if (!*p) return 0; p++;}
    *p = 0;
    int v1;
    if (!lookup_symbol(value,v,1) || !lookup_symbol(p+1,v1,1)) {
      *p=' '; return 0;}
    o->color(v,v1);
  } else if (!strcmp(propname,"resize")) {
    return !strcmp(value,"FL_RESIZE_ALL");
  } else if (!strcmp(propname,"gravity")) {
    return !strcmp(value,"FL_NoGravity FL_NoGravity");
  } else if (!strcmp(propname,"boxtype")) {
  TRY_BOXTYPE:
    int x = boxnumber(value);
    if (!x) {x = item_number(boxmenu1, value); if (x < 0) return 0;}
    if (x == ZERO_ENTRY) {
      x = 0;
      if (o->box() != ((Fl_Widget_Type*)factory)->o->box()) return 1; // kludge for frame
    }
    o->box((Fl_Boxtype)x);
  } else {
    return 0;
  }
  return 1;
}


Fl_Widget *Fl_Widget_Type::enter_live_mode(int) {
  live_widget = widget(o->x(), o->y(), o->w(), o->h());
  if (live_widget)
    copy_properties();
  return live_widget;
}

void Fl_Widget_Type::leave_live_mode() {
}

/**
 * copy all properties from the edit widget to the live widget
 */
void Fl_Widget_Type::copy_properties() {
  if (!live_widget)
    return;

  // copy all attributes common to all widget types
  Fl_Widget *w = live_widget;
  w->label(o->label());
  w->tooltip(tooltip());
  w->type(o->type());
  w->box(o->box());
  w->color(o->color());
  w->selection_color(o->selection_color());
  w->labeltype(o->labeltype());
  w->labelfont(o->labelfont());
  w->labelsize(o->labelsize());
  w->labelcolor(o->labelcolor());
  w->align(o->align());

  // copy all attributes specific to widgets derived from Fl_Button
  if (is_button()) {
    Fl_Button* d = (Fl_Button*)live_widget, *s = (Fl_Button*)o;
    d->down_box(s->down_box());
    d->shortcut(s->shortcut());
    d->value(s->value());
  }

  // copy all attributes specific to Fl_Valuator and derived classes
  if (is_valuator()) {
    Fl_Valuator* d = (Fl_Valuator*)live_widget, *s = (Fl_Valuator*)o;
    d->minimum(s->minimum());
    d->maximum(s->maximum());
    d->step(s->step());
    d->value(s->value());
    if (is_valuator()>=2) {
      Fl_Slider *d = (Fl_Slider*)live_widget, *s = (Fl_Slider*)o;
      d->slider_size(s->slider_size());
    }
  }

  // copy all attributes specific to Fl_Spinner and derived classes
  if (is_spinner()) {
    Fl_Spinner* d = (Fl_Spinner*)live_widget, *s = (Fl_Spinner*)o;
    d->minimum(s->minimum());
    d->maximum(s->maximum());
    d->step(s->step());
    d->value(s->value());
  }

/* TODO: implement this
  {Fl_Font ff; int fs; Fl_Color fc; if (textstuff(4,ff,fs,fc)) {
    Fl_Font f; int s; Fl_Color c; textstuff(0,f,s,c);
    if (f != ff) write_string("textfont %d", f);
    if (s != fs) write_string("textsize %d", s);
    if (c != fc) write_string("textcolor %d", c);
  }}*/

  if (!o->visible())
    w->hide();
  if (!o->active())
    w->deactivate();
  if (resizable() && w->parent())
    w->parent()->resizable(o);
}

void Fl_Pack_Type::copy_properties()
{
  Fl_Group_Type::copy_properties();
  Fl_Pack *d = (Fl_Pack*)live_widget, *s =(Fl_Pack*)o;
  d->spacing(s->spacing());
}

//
// End of "$Id: Fl_Widget_Type.cxx 6012 2008-01-04 21:45:49Z matt $".
//
