
#ifndef WIDGET_BROWSER_H
#define WIDGET_BROWSER_H

#include <FL/Fl_Browser.H>

class Widget_Browser : public Fl_Browser_ {
private:
  friend class Fl_Type;

  // required routines for Fl_Browser_ subclass:
  void *item_first() const ;
  void *item_next(void *) const ;
  void *item_prev(void *) const ;
  int item_selected(void *) const ;
  void item_select(void *,int);
  int item_width(void *) const ;
  int item_height(void *) const ;
  void item_draw(void *,int,int,int,int) const ;
  int incr_height() const ;

public:

  int handle(int);
  void callback();
  Widget_Browser(int,int,int,int,const char * =0);
};



#endif
