#ifndef FL_MISC_TYPE_H_
#define FL_MISC_TYPE_H_

#include <cstdio>
#include <FL/Fl_Browser.H>
#include <FL/Fl_Check_Browser.H>
#include <FL/Fl_File_Browser.H>

#include "Fl_Widget_Type.h"

using namespace std;

extern int compile_only;


static Fl_Menu_Item browser_type_menu[] = {
  {"No Select",0,0,(void*)FL_NORMAL_BROWSER},
  {"Select",0,0,(void*)FL_SELECT_BROWSER},
  {"Hold",0,0,(void*)FL_HOLD_BROWSER},
  {"Multi",0,0,(void*)FL_MULTI_BROWSER},
  {0}};


class Fl_Browser_Type : public Fl_Widget_Type {
  Fl_Menu_Item *subtypes() {return browser_type_menu;}
  int textstuff(int w, Fl_Font& f, int& s, Fl_Color& c);
public:
  virtual void ideal_size(int &w, int &h) {
    Fl_Browser *myo = (Fl_Browser *)o;
    fl_font(myo->textfont(), myo->textsize());
    h -= Fl::box_dh(o->box());
    w -= Fl::box_dw(o->box());
    int ww = (int)fl_width('m');
    w = ((w + ww - 1) / ww) * ww + Fl::box_dw(o->box());
    h = ((h + fl_height() - 1) / fl_height()) * fl_height() +
        Fl::box_dh(o->box());
    if (h < 30) h = 30;
    if (w < 50) w = 50;
  }
  virtual const char *type_name() {return "Fl_Browser";}

/*---------------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-FECHA: 25/09/09 ------------------------------------------------
----INICIO ----------------------------------------------------*/

  virtual const char *p_type_name() {return "Fl_Widget";} // type for code output

/*---FIN --------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-----------------------------------------------------------------
----------------------------------------------------------------*/

  Fl_Widget *widget(int x,int y,int w,int h,void *dt=0) {
    Fl_Browser* b = new Fl_Browser(x,y,w,h);
    // Fl_Browser::add calls fl_height(), which requires the X display open.
    // Avoid this when compiling so it works w/o a display:
    if (!compile_only) {
      char buffer[20];
      for (int i = 1; i <= 20; i++) {
  sprintf(buffer,"Browser Line %d",i);
  b->add(buffer);
      }
    }
    return b;
  }
  Fl_Widget_Type *_make() {return new Fl_Browser_Type();}
  int pixmapID() { return 31; }
};
/*static Fl_Browser_Type Fl_Browser_type;*/
/*
int Fl_Browser_Type::textstuff(int w, Fl_Font& f, int& s, Fl_Color& c) {
  Fl_Browser *myo = (Fl_Browser*)(w==4 ? ((Fl_Widget_Type*)factory)->o : o);
  switch (w) {
    case 4:
    case 0: f = myo->textfont(); s = myo->textsize(); c = myo->textcolor(); break;
    case 1: myo->textfont(f); break;
    case 2: myo->textsize(s); break;
    case 3: myo->textcolor(c); break;
  }
  return 1;
}
*/
class Fl_Check_Browser_Type : public Fl_Widget_Type {
  Fl_Menu_Item *subtypes() {return browser_type_menu;}
  int textstuff(int w, Fl_Font& f, int& s, Fl_Color& c);
public:
  virtual void ideal_size(int &w, int &h) {
    Fl_Check_Browser *myo = (Fl_Check_Browser *)o;
    fl_font(myo->textfont(), myo->textsize());
    h -= Fl::box_dh(o->box());
    w -= Fl::box_dw(o->box()) - fl_height();
    int ww = (int)fl_width('m');
    w = ((w + ww - 1) / ww) * ww + Fl::box_dw(o->box());
    h = ((h + fl_height() - 1) / fl_height()) * fl_height() +
        Fl::box_dh(o->box());
    if (h < 30) h = 30;
    if (w < 50) w = 50;
  }
  virtual const char *type_name() {return "Fl_Check_Browser";}

/*---------------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-FECHA: 25/09/09 ------------------------------------------------
----INICIO ----------------------------------------------------*/

  virtual const char *p_type_name() {return "Fl_Widget";} // type for code output

/*---FIN --------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-----------------------------------------------------------------
----------------------------------------------------------------*/

  Fl_Widget *widget(int x,int y,int w,int h,void *dt=0) {
    Fl_Check_Browser* b = new Fl_Check_Browser(x,y,w,h);
    // Fl_Check_Browser::add calls fl_height(), which requires the X display open.
    // Avoid this when compiling so it works w/o a display:
    if (!compile_only) {
      char buffer[20];
      for (int i = 1; i <= 20; i++) {
  sprintf(buffer,"Browser Line %d",i);
  b->add(buffer);
      }
    }
    return b;
  }
  Fl_Widget_Type *_make() {return new Fl_Check_Browser_Type();}
  int pixmapID() { return 32; }
};
/*static Fl_Check_Browser_Type Fl_Check_Browser_type;*/
/*
int Fl_Check_Browser_Type::textstuff(int w, Fl_Font& f, int& s, Fl_Color& c) {
  Fl_Check_Browser *myo = (Fl_Check_Browser*)(w==4 ? ((Fl_Widget_Type*)factory)->o : o);
  switch (w) {
    case 4:
    case 0: f = myo->textfont(); s = myo->textsize(); c = myo->textcolor(); break;
    case 1: myo->textfont(f); break;
    case 2: myo->textsize(s); break;
    case 3: myo->textcolor(c); break;
  }
  return 1;
}
*/
class Fl_File_Browser_Type : public Fl_Widget_Type {
  Fl_Menu_Item *subtypes() {return browser_type_menu;}
  int textstuff(int w, Fl_Font& f, int& s, Fl_Color& c);
public:
  virtual void ideal_size(int &w, int &h) {
    Fl_File_Browser *myo = (Fl_File_Browser *)o;
    fl_font(myo->textfont(), myo->textsize());
    h -= Fl::box_dh(o->box());
    w -= Fl::box_dw(o->box()) + fl_height();
    int ww = (int)fl_width('m');
    w = ((w + ww - 1) / ww) * ww + Fl::box_dw(o->box());
    h = ((h + fl_height() - 1) / fl_height()) * fl_height() +
        Fl::box_dh(o->box());
    if (h < 30) h = 30;
    if (w < 50) w = 50;
  }
  virtual const char *type_name() {return "Fl_File_Browser";}

/*---------------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-FECHA: 25/09/09 ------------------------------------------------
----INICIO ----------------------------------------------------*/

  virtual const char *p_type_name() {return "Fl_Widget";} // type for code output

/*---FIN --------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-----------------------------------------------------------------
----------------------------------------------------------------*/

  Fl_Widget *widget(int x,int y,int w,int h,void *dt=0) {
    Fl_File_Browser* b = new Fl_File_Browser(x,y,w,h);
    // Fl_File_Browser::add calls fl_height(), which requires the X display open.
    // Avoid this when compiling so it works w/o a display:
    if (!compile_only) {
      b->load(".");
    }
    return b;
  }
  Fl_Widget_Type *_make() {return new Fl_File_Browser_Type();}
  int pixmapID() { return 33; }
};
/*static Fl_File_Browser_Type Fl_File_Browser_type;

int Fl_File_Browser_Type::textstuff(int w, Fl_Font& f, int& s, Fl_Color& c) {
  Fl_File_Browser *myo = (Fl_File_Browser*)(w==4 ? ((Fl_Widget_Type*)factory)->o : o);
  switch (w) {
    case 4:
    case 0: f = myo->textfont(); s = myo->textsize(); c = myo->textcolor(); break;
    case 1: myo->textfont(f); break;
    case 2: myo->textsize(s); break;
    case 3: myo->textcolor(c); break;
  }
  return 1;
}
*/
////////////////////////////////////////////////////////////////

#include <FL/Fl_Counter.H>
static Fl_Menu_Item counter_type_menu[] = {
  {"Normal",0,0,(void*)FL_NORMAL_COUNTER},
  {"Simple",0,0,(void*)FL_SIMPLE_COUNTER},
  {0}};
class Fl_Counter_Type : public Fl_Widget_Type {
  Fl_Menu_Item *subtypes() {return counter_type_menu;}
  int textstuff(int w, Fl_Font& f, int& s, Fl_Color& c);
  int is_valuator() const {return 1;}
  int pixmapID() { return 41; }
public:
  virtual const char *type_name() {return "Fl_Counter";}

/*---------------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-FECHA: 25/09/09 ------------------------------------------------
----INICIO ----------------------------------------------------*/

  virtual const char *p_type_name() {return "Fl_Widget";} // type for code output

/*---FIN --------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-----------------------------------------------------------------
----------------------------------------------------------------*/

  Fl_Widget *widget(int x,int y,int w,int h,void *dt=0) {
    return new Fl_Counter(x,y,w,h,"counter:");}
  Fl_Widget_Type *_make() {return new Fl_Counter_Type();}
};
/*static Fl_Counter_Type Fl_Counter_type;

int Fl_Counter_Type::textstuff(int w, Fl_Font& f, int& s, Fl_Color& c) {
  Fl_Counter *myo = (Fl_Counter*)(w==4 ? ((Fl_Widget_Type*)factory)->o : o);
  switch (w) {
    case 4:
    case 0: f = myo->textfont(); s = myo->textsize(); c = myo->textcolor(); break;
    case 1: myo->textfont(f); break;
    case 2: myo->textsize(s); break;
    case 3: myo->textcolor(c); break;
  }
  return 1;
}
*/
////////////////////////////////////////////////////////////////

#include <FL/Fl_Spinner.H>
static Fl_Menu_Item spinner_type_menu[] = {
  {"Integer",0,0,(void*)FL_INT_INPUT},
  {"Float",  0,0,(void*)FL_FLOAT_INPUT},
  {0}};
class Fl_Spinner_Type : public Fl_Widget_Type {
  Fl_Menu_Item *subtypes() {return spinner_type_menu;}
  int textstuff(int w, Fl_Font& f, int& s, Fl_Color& c);
  int pixmapID() { return 47; }
public:
  virtual void ideal_size(int &w, int &h) {
    Fl_Spinner *myo = (Fl_Spinner *)o;
    fl_font(myo->textfont(), myo->textsize());
    h = fl_height() + myo->textsize() - 6;
    if (h < 15) h = 15;
    w -= Fl::box_dw(o->box());
    int ww = (int)fl_width('m');
    w = ((w + ww - 1) / ww) * ww + Fl::box_dw(o->box()) + h / 2;
    if (w < 40) w = 40  ;
  }
  virtual const char *type_name() {return "Fl_Spinner";}

/*---------------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-FECHA: 25/09/09 ------------------------------------------------
----INICIO ----------------------------------------------------*/

  virtual const char *p_type_name() {return "Fl_Widget";} // type for code output

/*---FIN --------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-----------------------------------------------------------------
----------------------------------------------------------------*/

  int is_spinner() const { return 1; }
  Fl_Widget *widget(int x,int y,int w,int h,void *dt=0) {
    return new Fl_Spinner(x,y,w,h,"spinner:");}
  Fl_Widget_Type *_make() {return new Fl_Spinner_Type();}
};
/*static Fl_Spinner_Type Fl_Spinner_type;

int Fl_Spinner_Type::textstuff(int w, Fl_Font& f, int& s, Fl_Color& c) {
  Fl_Spinner *myo = (Fl_Spinner*)(w==4 ? ((Fl_Widget_Type*)factory)->o : o);
  switch (w) {
    case 4:
    case 0: f = (Fl_Font)myo->textfont(); s = myo->textsize(); c = myo->textcolor(); break;
    case 1: myo->textfont(f); break;
    case 2: myo->textsize(s); break;
    case 3: myo->textcolor(c); break;
  }
  return 1;
}
*/
////////////////////////////////////////////////////////////////

#include <FL/Fl_Input.H>
static Fl_Menu_Item input_type_menu[] = {
  {"Normal",0,0,(void*)FL_NORMAL_INPUT},
  {"Multiline",0,0,(void*)FL_MULTILINE_INPUT},
  {"Secret",0,0,(void*)FL_SECRET_INPUT},
  {"Int",0,0,(void*)FL_INT_INPUT},
  {"Float",0,0,(void*)FL_FLOAT_INPUT},
  {0}};
class Fl_Input_Type : public Fl_Widget_Type {
  Fl_Menu_Item *subtypes() {return input_type_menu;}
  int textstuff(int w, Fl_Font& f, int& s, Fl_Color& c);
public:
  virtual void ideal_size(int &w, int &h) {
    Fl_Input *myo = (Fl_Input *)o;
    fl_font(myo->textfont(), myo->textsize());
    h = fl_height() + myo->textsize() - 6;
    w -= Fl::box_dw(o->box());
    int ww = (int)fl_width('m');
    w = ((w + ww - 1) / ww) * ww + Fl::box_dw(o->box());
    if (h < 15) h = 15;
    if (w < 15) w = 15;
  }
  virtual const char *type_name() {return "Fl_Input";}

/*---------------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-FECHA: 25/09/09 ------------------------------------------------
----INICIO ----------------------------------------------------*/

  virtual const char *p_type_name() {return "Fl_Widget";} // type for code output

/*---FIN --------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-----------------------------------------------------------------
----------------------------------------------------------------*/

  Fl_Widget *widget(int x,int y,int w,int h,void *dt=0) {
    Fl_Input *myo = new Fl_Input(x,y,w,h,"input:");
    myo->value("Text Input");
    return myo;
  }
  Fl_Widget_Type *_make() {return new Fl_Input_Type();}
  int pixmapID() { return 14; }
  virtual void copy_properties() {
    Fl_Widget_Type::copy_properties();
    Fl_Input_ *d = (Fl_Input_*)live_widget, *s = (Fl_Input_*)o;
    d->textfont(s->textfont());
    d->textsize(s->textsize());
    d->textcolor(s->textcolor());
  }

};
/*static Fl_Input_Type Fl_Input_type;

int Fl_Input_Type::textstuff(int w, Fl_Font& f, int& s, Fl_Color& c) {
  Fl_Input_ *myo = (Fl_Input_*)(w==4 ? ((Fl_Widget_Type*)factory)->o : o);
  switch (w) {
    case 4:
    case 0: f = myo->textfont(); s = myo->textsize(); c = myo->textcolor(); break;
    case 1: myo->textfont(f); break;
    case 2: myo->textsize(s); break;
    case 3: myo->textcolor(c); break;
  }
  return 1;
}
*/
////////////////////////////////////////////////////////////////

#include <FL/Fl_File_Input.H>
class Fl_File_Input_Type : public Fl_Widget_Type {
  Fl_Menu_Item *subtypes() {return 0;}
  int textstuff(int w, Fl_Font& f, int& s, Fl_Color& c);
public:
  virtual void ideal_size(int &w, int &h) {
    Fl_File_Input *myo = (Fl_File_Input *)o;
    fl_font(myo->textfont(), myo->textsize());
    h = fl_height() + myo->textsize() + 4;
    w -= Fl::box_dw(o->box());
    int ww = (int)fl_width('m');
    w = ((w + ww - 1) / ww) * ww + Fl::box_dw(o->box());
    if (h < 20) h = 20;
    if (w < 50) w = 50;
  }
  virtual const char *type_name() {return "Fl_File_Input";}

/*---------------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-FECHA: 25/09/09 ------------------------------------------------
----INICIO ----------------------------------------------------*/

  virtual const char *p_type_name() {return "Fl_Widget";} // type for code output

/*---FIN --------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-----------------------------------------------------------------
----------------------------------------------------------------*/

  Fl_Widget *widget(int x,int y,int w,int h,void *dt=0) {
    Fl_File_Input *myo = new Fl_File_Input(x,y,w,h,"file:");
    myo->value("/now/is/the/time/for/a/filename.ext");
    return myo;
  }
  Fl_Widget_Type *_make() {return new Fl_File_Input_Type();}
  int pixmapID() { return 30; }
};
/*static Fl_File_Input_Type Fl_File_Input_type;

int Fl_File_Input_Type::textstuff(int w, Fl_Font& f, int& s, Fl_Color& c) {
  Fl_File_Input *myo = (Fl_File_Input*)(w==4 ? ((Fl_Widget_Type*)factory)->o : o);
  switch (w) {
    case 4:
    case 0: f = myo->textfont(); s = myo->textsize(); c = myo->textcolor(); break;
    case 1: myo->textfont(f); break;
    case 2: myo->textsize(s); break;
    case 3: myo->textcolor(c); break;
  }
  return 1;
}
*/
////////////////////////////////////////////////////////////////

#include <FL/Fl_Text_Display.H>
class Fl_Text_Display_Type : public Fl_Widget_Type {
  int textstuff(int w, Fl_Font& f, int& s, Fl_Color& c);
public:
  virtual void ideal_size(int &w, int &h) {
    Fl_Text_Display *myo = (Fl_Text_Display *)o;
    fl_font(myo->textfont(), myo->textsize());
    h -= Fl::box_dh(o->box());
    w -= Fl::box_dw(o->box());
    int ww = (int)fl_width('m');
    w = ((w + ww - 1) / ww) * ww + Fl::box_dw(o->box());
    h = ((h + fl_height() - 1) / fl_height()) * fl_height() +
        Fl::box_dh(o->box());
    if (h < 30) h = 30;
    if (w < 50) w = 50;
  }
  virtual const char *type_name() {return "Fl_Text_Display";}

/*---------------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-FECHA: 25/09/09 ------------------------------------------------
----INICIO ----------------------------------------------------*/

  virtual const char *p_type_name() {return "Fl_Widget";} // type for code output

/*---FIN --------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-----------------------------------------------------------------
----------------------------------------------------------------*/

  Fl_Widget *widget(int x,int y,int w,int h,void *dt=0) {
    Fl_Text_Display *myo = new Fl_Text_Display(x,y,w,h);
    return myo;
  }
  Fl_Widget_Type *_make() {return new Fl_Text_Display_Type();}
  int pixmapID() { return 28; }
};
/*static Fl_Text_Display_Type Fl_Text_Display_type;

int Fl_Text_Display_Type::textstuff(int w, Fl_Font& f, int& s, Fl_Color& c) {
  Fl_Text_Display *myo = (Fl_Text_Display*)(w==4 ? ((Fl_Widget_Type*)factory)->o : o);
  switch (w) {
    case 4:
    case 0: f = myo->textfont(); s = myo->textsize(); c = myo->textcolor(); break;
    case 1: myo->textfont(f); break;
    case 2: myo->textsize(s); break;
    case 3: myo->textcolor(c); break;
  }
  return 1;
}
*/
////////////////////////////////////////////////////////////////

#include <FL/Fl_Text_Editor.H>
class Fl_Text_Editor_Type : public Fl_Widget_Type {
  int textstuff(int w, Fl_Font& f, int& s, Fl_Color& c);
public:
  virtual void ideal_size(int &w, int &h) {
    Fl_Text_Editor *myo = (Fl_Text_Editor *)o;
    fl_font(myo->textfont(), myo->textsize());
    h -= Fl::box_dh(o->box());
    w -= Fl::box_dw(o->box());
    int ww = (int)fl_width('m');
    w = ((w + ww - 1) / ww) * ww + Fl::box_dw(o->box());
    h = ((h + fl_height() - 1) / fl_height()) * fl_height() +
        Fl::box_dh(o->box());
    if (h < 30) h = 30;
    if (w < 50) w = 50;
  }
  virtual const char *type_name() {return "Fl_Text_Editor";}

/*---------------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-FECHA: 25/09/09 ------------------------------------------------
----INICIO ----------------------------------------------------*/

  virtual const char *p_type_name() {return "Fl_Widget";} // type for code output

/*---FIN --------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-----------------------------------------------------------------
----------------------------------------------------------------*/

  Fl_Widget *widget(int x,int y,int w,int h,void *dt=0) {
    Fl_Text_Editor *myo = new Fl_Text_Editor(x,y,w,h);
    return myo;
  }
  Fl_Widget_Type *_make() {return new Fl_Text_Editor_Type();}
  int pixmapID() { return 29; }
};
/*static Fl_Text_Editor_Type Fl_Text_Editor_type;

int Fl_Text_Editor_Type::textstuff(int w, Fl_Font& f, int& s, Fl_Color& c) {
  Fl_Text_Editor *myo = (Fl_Text_Editor*)(w==4 ? ((Fl_Widget_Type*)factory)->o : o);
  switch (w) {
    case 4:
    case 0: f = myo->textfont(); s = myo->textsize(); c = myo->textcolor(); break;
    case 1: myo->textfont(f); break;
    case 2: myo->textsize(s); break;
    case 3: myo->textcolor(c); break;
  }
  return 1;
}
*/
////////////////////////////////////////////////////////////////

#include <FL/Fl_Clock.H>
class Fl_Clock_Type : public Fl_Widget_Type {
public:
  virtual const char *type_name() {return "Fl_Clock";}

/*---------------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-FECHA: 25/09/09 ------------------------------------------------
----INICIO ----------------------------------------------------*/

  virtual const char *p_type_name() {return "Fl_Widget";} // type for code output

/*---FIN --------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-----------------------------------------------------------------
----------------------------------------------------------------*/

  Fl_Widget *widget(int x,int y,int w,int h,void *dt=0) {
    return new Fl_Clock(x,y,w,h);}
  Fl_Widget_Type *_make() {return new Fl_Clock_Type();}
  int pixmapID() { return 34; }
};
/*static Fl_Clock_Type Fl_Clock_type;*/

////////////////////////////////////////////////////////////////

#include <FL/Fl_Help_View.H>
class Fl_Help_View_Type : public Fl_Widget_Type {
public:
  virtual void ideal_size(int &w, int &h) {
    Fl_Help_View *myo = (Fl_Help_View *)o;
    fl_font(myo->textfont(), myo->textsize());
    h -= Fl::box_dh(o->box());
    w -= Fl::box_dw(o->box());
    int ww = (int)fl_width('m');
    w = ((w + ww - 1) / ww) * ww + Fl::box_dw(o->box());
    h = ((h + fl_height() - 1) / fl_height()) * fl_height() +
        Fl::box_dh(o->box());
    if (h < 30) h = 30;
    if (w < 50) w = 50;
  }
  virtual const char *type_name() {return "Fl_Help_View";}

/*---------------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-FECHA: 25/09/09 ------------------------------------------------
----INICIO ----------------------------------------------------*/

  virtual const char *p_type_name() {return "Fl_Widget";} // type for code output

/*---FIN --------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-----------------------------------------------------------------
----------------------------------------------------------------*/

  Fl_Widget *widget(int x,int y,int w,int h,void *dt=0) {
    Fl_Help_View *myo = new Fl_Help_View(x,y,w,h);
    if (!compile_only) {
      myo->value("<HTML><BODY><H1>Fl_Help_View Widget</H1>"
                 "<P>This is a Fl_Help_View widget.</P></BODY></HTML>");
    }
    return myo;}
  Fl_Widget_Type *_make() {return new Fl_Help_View_Type();}
  int pixmapID() { return 35; }
};
/*static Fl_Help_View_Type Fl_Help_View_type;*/

////////////////////////////////////////////////////////////////

#include <FL/Fl_Progress.H>
class Fl_Progress_Type : public Fl_Widget_Type {
public:
  virtual const char *type_name() {return "Fl_Progress";}

/*---------------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-FECHA: 25/09/09 ------------------------------------------------
----INICIO ----------------------------------------------------*/

  virtual const char *p_type_name() {return "Fl_Widget";} // type for code output

/*---FIN --------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-----------------------------------------------------------------
----------------------------------------------------------------*/

  Fl_Widget *widget(int x,int y,int w,int h,void *dt=0) {
    Fl_Progress *myo = new Fl_Progress(x,y,w,h,"label");
    myo->value(50);
    return myo;}
  Fl_Widget_Type *_make() {return new Fl_Progress_Type();}
  int pixmapID() { return 36; }
};
/*static Fl_Progress_Type Fl_Progress_type;*/

////////////////////////////////////////////////////////////////

#include <FL/Fl_Adjuster.H>
class Fl_Adjuster_Type : public Fl_Widget_Type {
  int is_valuator() const {return 1;}
public:
  virtual const char *type_name() {return "Fl_Adjuster";}

/*---------------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-FECHA: 25/09/09 ------------------------------------------------
----INICIO ----------------------------------------------------*/

  virtual const char *p_type_name() {return "Fl_Widget";} // type for code output

/*---FIN --------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-----------------------------------------------------------------
----------------------------------------------------------------*/

  Fl_Widget *widget(int x,int y,int w,int h,void *dt=0) {
    return new Fl_Adjuster(x,y,w,h);}
  Fl_Widget_Type *_make() {return new Fl_Adjuster_Type();}
  int pixmapID() { return 40; }
};
/*static Fl_Adjuster_Type Fl_Adjuster_type;*/

////////////////////////////////////////////////////////////////

#include <FL/Fl_Dial.H>
static Fl_Menu_Item dial_type_menu[] = {
  {"Dot",0,0,(void*)0},
  {"Line",0,0,(void*)FL_LINE_DIAL},
  {"Fill",0,0,(void*)FL_FILL_DIAL},
  {0}};
class Fl_Dial_Type : public Fl_Widget_Type {
  Fl_Menu_Item *subtypes() {return dial_type_menu;}
  int is_valuator() const {return 1;}
public:
  virtual const char *type_name() {return "Fl_Dial";}

/*---------------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-FECHA: 25/09/09 ------------------------------------------------
----INICIO ----------------------------------------------------*/

  virtual const char *p_type_name() {return "Fl_Widget";} // type for code output

/*---FIN --------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-----------------------------------------------------------------
----------------------------------------------------------------*/

  Fl_Widget *widget(int x,int y,int w,int h,void *dt=0) {
    return new Fl_Dial(x,y,w,h);}
  Fl_Widget_Type *_make() {return new Fl_Dial_Type();}
  int pixmapID() { return 42; }
};
/*static Fl_Dial_Type Fl_Dial_type;*/

////////////////////////////////////////////////////////////////

#include <FL/Fl_Roller.H>
static Fl_Menu_Item roller_type_menu[] = {
  {"Vertical",0,0,(void*)0},
  {"Horizontal",0,0,(void*)FL_HORIZONTAL},
  {0}};
class Fl_Roller_Type : public Fl_Widget_Type {
  Fl_Menu_Item *subtypes() {return roller_type_menu;}
  int is_valuator() const {return 1;}
public:
  virtual const char *type_name() {return "Fl_Roller";}

/*---------------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-FECHA: 25/09/09 ------------------------------------------------
----INICIO ----------------------------------------------------*/

  virtual const char *p_type_name() {return "Fl_Widget";} // type for code output

/*---FIN --------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-----------------------------------------------------------------
----------------------------------------------------------------*/

  Fl_Widget *widget(int x,int y,int w,int h,void *dt=0) {
    return new Fl_Roller(x,y,w,h);}
  Fl_Widget_Type *_make() {return new Fl_Roller_Type();}
  int pixmapID() { return 43; }
};
/*static Fl_Roller_Type Fl_Roller_type;*/

////////////////////////////////////////////////////////////////

#include <FL/Fl_Scrollbar.H>
static Fl_Menu_Item slider_type_menu[] = {
  {"Vertical",0,0,(void*)FL_VERT_SLIDER},
  {"Horizontal",0,0,(void*)FL_HOR_SLIDER},
  {"Vert Fill",0,0,(void*)FL_VERT_FILL_SLIDER},
  {"Horz Fill",0,0,(void*)FL_HOR_FILL_SLIDER},
  {"Vert Knob",0,0,(void*)FL_VERT_NICE_SLIDER},
  {"Horz Knob",0,0,(void*)FL_HOR_NICE_SLIDER},
  {0}};
class Fl_Slider_Type : public Fl_Widget_Type {
  Fl_Menu_Item *subtypes() {return slider_type_menu;}
  int is_valuator() const {return 2;}
public:
  virtual const char *type_name() {return "Fl_Slider";}

/*---------------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-FECHA: 25/09/09 ------------------------------------------------
----INICIO ----------------------------------------------------*/

  virtual const char *p_type_name() {return "Fl_Widget";} // type for code output

/*---FIN --------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-----------------------------------------------------------------
----------------------------------------------------------------*/

  Fl_Widget *widget(int x,int y,int w,int h,void *dt=0) {
    return new Fl_Slider(x,y,w,h,"slider:");}
  Fl_Widget_Type *_make() {return new Fl_Slider_Type();}
  int pixmapID() { return 37; }
};
/*static Fl_Slider_Type Fl_Slider_type;*/

static Fl_Menu_Item scrollbar_type_menu[] = {
  {"Vertical",0,0,(void*)FL_VERT_SLIDER},
  {"Horizontal",0,0,(void*)FL_HOR_SLIDER},
  {0}};
class Fl_Scrollbar_Type : public Fl_Slider_Type {
  Fl_Menu_Item *subtypes() {return scrollbar_type_menu;}
  int is_valuator() const {return 3;}
public:
  virtual const char *type_name() {return "Fl_Scrollbar";}

/*---------------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-FECHA: 25/09/09 ------------------------------------------------
----INICIO ----------------------------------------------------*/

  virtual const char *p_type_name() {return "Fl_Slider";} // type for code output

/*---FIN --------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-----------------------------------------------------------------
----------------------------------------------------------------*/

  Fl_Widget *widget(int x,int y,int w,int h,void *dt=0) {
    return new Fl_Scrollbar(x,y,w,h);}
  Fl_Widget_Type *_make() {return new Fl_Scrollbar_Type();}
  int pixmapID() { return 38; }
};
/*static Fl_Scrollbar_Type Fl_Scrollbar_type;*/

////////////////////////////////////////////////////////////////

#include <FL/Fl_Output.H>
static Fl_Menu_Item output_type_menu[] = {
  {"Normal",0,0,(void*)FL_NORMAL_OUTPUT},
  {"Multiline",0,0,(void*)FL_MULTILINE_OUTPUT},
  {0}};
class Fl_Output_Type : public Fl_Input_Type {
  Fl_Menu_Item *subtypes() {return output_type_menu;}
public:
  virtual void ideal_size(int &w, int &h) {
    Fl_Output *myo = (Fl_Output *)o;
    fl_font(myo->textfont(), myo->textsize());
    h = fl_height() + myo->textsize() - 6;
    w -= Fl::box_dw(o->box());
    int ww = (int)fl_width('m');
    w = ((w + ww - 1) / ww) * ww + Fl::box_dw(o->box());
    if (h < 15) h = 15;
    if (w < 15) w = 15;
  }
  virtual const char *type_name() {return "Fl_Output";}

/*---------------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-FECHA: 25/09/09 ------------------------------------------------
----INICIO ----------------------------------------------------*/

  virtual const char *p_type_name() {return "Fl_Input";} // type for code output

/*---FIN --------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-----------------------------------------------------------------
----------------------------------------------------------------*/

  Fl_Widget *widget(int x,int y,int w,int h,void *dt=0) {
    Fl_Output *myo = new Fl_Output(x,y,w,h,"output:");
    myo->value("Text Output");
    return myo;
  }
  Fl_Widget_Type *_make() {return new Fl_Output_Type();}
  int pixmapID() { return 27; }

};
/*static Fl_Output_Type Fl_Output_type;*/

////////////////////////////////////////////////////////////////

#include <FL/Fl_Value_Input.H>
class Fl_Value_Input_Type : public Fl_Widget_Type {
public:
  virtual void ideal_size(int &w, int &h) {
    Fl_Value_Input *myo = (Fl_Value_Input *)o;
    fl_font(myo->textfont(), myo->textsize());
    h = fl_height() + myo->textsize() - 6;
    w -= Fl::box_dw(o->box());
    int ww = (int)fl_width('m');
    w = ((w + ww - 1) / ww) * ww + Fl::box_dw(o->box());
    if (h < 15) h = 15;
    if (w < 15) w = 15;
  }
  virtual const char *type_name() {return "Fl_Value_Input";}

/*---------------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-FECHA: 25/09/09 ------------------------------------------------
----INICIO ----------------------------------------------------*/

  virtual const char *p_type_name() {return "Fl_Widget";} // type for code output

/*---FIN --------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-----------------------------------------------------------------
----------------------------------------------------------------*/

  int textstuff(int w, Fl_Font& f, int& s, Fl_Color& c);
  int is_valuator() const {return 1;}
  Fl_Widget *widget(int x,int y,int w,int h,void *dt=0) {
    Fl_Value_Input *myo = new Fl_Value_Input(x,y,w,h,"value:");
    return myo;
  }
  Fl_Widget_Type *_make() {return new Fl_Value_Input_Type();}
  int pixmapID() { return 44; }
};
/*static Fl_Value_Input_Type Fl_Value_Input_type;

int Fl_Value_Input_Type::textstuff(int w, Fl_Font& f, int& s, Fl_Color& c) {
  Fl_Value_Input *myo = (Fl_Value_Input*)(w==4 ? ((Fl_Widget_Type*)factory)->o : o);
  switch (w) {
    case 4:
    case 0: f = myo->textfont(); s = myo->textsize(); c = myo->textcolor(); break;
    case 1: myo->textfont(f); break;
    case 2: myo->textsize(s); break;
    case 3: myo->textcolor(c); break;
  }
  return 1;
}
*/
////////////////////////////////////////////////////////////////

#include <FL/Fl_Value_Output.H>
class Fl_Value_Output_Type : public Fl_Widget_Type {
public:
  virtual void ideal_size(int &w, int &h) {
    Fl_Value_Output *myo = (Fl_Value_Output *)o;
    fl_font(myo->textfont(), myo->textsize());
    h = fl_height() + myo->textsize() - 6;
    w = o->w() - Fl::box_dw(o->box());
    int ww = (int)fl_width('m');
    w = ((w + ww - 1) / ww) * ww + Fl::box_dw(o->box());
    if (h < 15) h = 15;
    if (w < 15) w = 15;
  }
  virtual const char *type_name() {return "Fl_Value_Output";}

/*---------------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-FECHA: 25/09/09 ------------------------------------------------
----INICIO ----------------------------------------------------*/

  virtual const char *p_type_name() {return "Fl_Widget";} // type for code output

/*---FIN --------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-----------------------------------------------------------------
----------------------------------------------------------------*/

  int textstuff(int w, Fl_Font& f, int& s, Fl_Color& c);
  int is_valuator() const {return 1;}
  Fl_Widget *widget(int x,int y,int w,int h,void *dt=0) {
    Fl_Value_Output *myo = new Fl_Value_Output(x,y,w,h,"value:");
    return myo;
  }
  Fl_Widget_Type *_make() {return new Fl_Value_Output_Type();}
  int pixmapID() { return 45; }
};
/*static Fl_Value_Output_Type Fl_Value_Output_type;

int Fl_Value_Output_Type::textstuff(int w, Fl_Font& f, int& s, Fl_Color& c) {
  Fl_Value_Output *myo = (Fl_Value_Output*)(w==4 ? ((Fl_Widget_Type*)factory)->o : o);
  switch (w) {
    case 4:
    case 0: f = myo->textfont(); s = myo->textsize(); c = myo->textcolor(); break;
    case 1: myo->textfont(f); break;
    case 2: myo->textsize(s); break;
    case 3: myo->textcolor(c); break;
  }
  return 1;
}
*/
////////////////////////////////////////////////////////////////

#include <FL/Fl_Value_Slider.H>
class Fl_Value_Slider_Type : public Fl_Slider_Type {
  int textstuff(int w, Fl_Font& f, int& s, Fl_Color& c);
public:
  virtual const char *type_name() {return "Fl_Value_Slider";}

/*---------------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-FECHA: 25/09/09 ------------------------------------------------
----INICIO ----------------------------------------------------*/

  virtual const char *p_type_name() {return "Fl_Slider";} // type for code output

/*---FIN --------------------------------------------------------
-----------------------------------------------------------------
---------------- ARGOS (INTERFARGOS)  ---------------------------
-----------------------------------------------------------------
----------------------------------------------------------------*/

  Fl_Widget *widget(int x,int y,int w,int h,void *dt=0) {
    return new Fl_Value_Slider(x,y,w,h,"slider:");}
  Fl_Widget_Type *_make() {return new Fl_Value_Slider_Type();}
  int pixmapID() { return 39; }
};
/*static Fl_Value_Slider_Type Fl_Value_Slider_type;

int Fl_Value_Slider_Type::textstuff(int w, Fl_Font& f, int& s, Fl_Color& c) {
  Fl_Value_Slider *myo = (Fl_Value_Slider*)(w==4 ? ((Fl_Widget_Type*)factory)->o : o);
  switch (w) {
    case 4:
    case 0: f = myo->textfont(); s = myo->textsize(); c = myo->textcolor(); break;
    case 1: myo->textfont(f); break;
    case 2: myo->textsize(s); break;
    case 3: myo->textcolor(c); break;
  }
  return 1;
}
*/
////////////////////////////////////////////////////////////////



#endif
