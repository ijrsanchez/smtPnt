/**
* @file	as-historico.cpp
* @brief		<b>Tipo Abstracto de Datos para el Almacenamiento
*				de Valores Historicos y Alarmas</b><br>
* @author	    Alejandro Pina <ajpina@gmail.com><br>
* @link			http://www.cintal.com.ve/tecnologia/argos<br>
* @package      argos
* @access       public
* @version      1.0  -  01/06/09
*/

/*
Copyright (C) 2006 Alejandro Pina <ajpina@gmail.com>

Este programa es software libre. Puede redistribuirlo y/o modificarlo bajo
los terminos de la Licencia Publica General de GNU segun es publicada por
la Free Software Foundation, bien de la version 3 de dicha Licencia o bien
(segun su eleccion) de cualquier version posterior.

Este programa se distribuye con la esperanza de que sea util, pero
SIN NINGUNA GARANTIA, incluso sin la garantia MERCANTIL implicita o sin
garantizar la CONVENIENCIA PARA UN PROPOSITO PARTICULAR. Vease la Licencia
Publica General de GNU para mas detalles.

Deberia haber recibido una copia de la Licencia Publica General junto con
este programa. Si no ha sido asi, escriba a la Free Software Foundation, Inc.,
en 675 Mass Ave, Cambridge, MA 02139, EEUU.

Alejandro Pina mediante este documento renuncia a cualquier interes de derechos de
copyright con respecto al programa 'argos'.

01 de Noviembre de 2008

Por favor reporte cualquier fallo a la siguiente direccion:

	http://www.cintal.com.ve/tecnologia/argos

*/

#include "as-historico.h"
#include "as-util.h"

using namespace argos;


/**
* @brief Crea un objeto Historico para albergar el Tag a muestrear
* @return referencia al objeto
*/
historico::historico(){
	tipo_log = MUESTREO_;
	tiempo_muestreo = 1000;
	maximo = (float) 0xFFFFFFFF;
	minimo = (float) 0xFFFFFFFF;
	muestras = 100;
	cant_funciones = 0;
}

/**
* @brief Destructor del objeto Historico
*/
historico::~historico(){

}

/**
* @brief Asigna la propiedad de tipo de muestreo al objeto historico
* @param tl		Tipo de muestreo que se realizar
*/
void historico::asignar_tipo(Tlog tl){
	tipo_log = tl;
}

/**
* @brief Asigna la propiedad de frecuencia de muestreo al objeto historico
* @param t		Frecuencia de muestreo
*/
void historico::asignar_tiempo(int t){
	tiempo_muestreo = (unsigned int)t;
}

void historico::asignar_maximo(float max){
	maximo = max;
}

void historico::asignar_minimo(float min){
	minimo = min;
}

/**
* @brief Asigna la Cantidad de Muestras a Recolectar
* @param m		Numero de Muestras
*/
void historico::asignar_muestras(int m){
	muestras = (unsigned int)m;
}

/**
* @brief Asigna las Funciones para el Manejo de las Muestras
* @param tf		Funciones
*/
void historico::asignar_funcion(Tfunciones tf){
	funciones[cant_funciones++] = tf;
}

/**
* @brief Reinicia el contador de Funciones
*/
void historico::reset_cant_funciones(){
	cant_funciones = 0;
}

/**
* @brief Copia de Historicos
* @param h		Valor Historico
*/
void historico::copiar(const historico & h){
	t.asignar_propiedades( &(h.t.nombre[0]), h.t.valor_campo, h.t.tipo, NULL, NULL );
	tipo_log = h.tipo_log;
	tiempo_muestreo = h.tiempo_muestreo;
	maximo = h.maximo;
	minimo = h.minimo;
	muestras = h.muestras;
	cant_funciones = h.cant_funciones;
	for(unsigned int i = 0; i < cant_funciones; i++)
		funciones[i] = h.funciones[i];
}

/**
* @brief Devuelve la Cantidad de Muestras
* @return muestras	Numero de Muestras
*/
unsigned int historico::obtener_muestras(){
	return muestras;
}

/**
* @brief Devuelve los Tiempos de Muestreo
* @return tiempo_muestreo	Frecuencia de Adquicision
*/
unsigned int historico::obtener_tiempo_muestreo(){
	return tiempo_muestreo;
}

/**
* @brief Devuelve el Tipo de Registro del Historico
* @return tipo_log		Tipo de Registro
*/
Tlog historico::obtener_tipo_log(){
	return tipo_log;
}

/**
* @brief Devuelve una Funcion de Manejo de Muestras
* @param	pos		Posicion de la Funcion dentro del Arreglo
* @return	funcion	Tipo de Funcion
*/
Tfunciones historico::obtener_funcion(unsigned int pos){
	return funciones[pos];
}

Tvalor tendencia::obtener_inicio_tendencia( struct timeval inicio, struct timeval fin,
										int & puntos, int & indice, struct timeval & fecha_pto ){
	size_t 		pos_inicio,
				pos_fin;

	pos_fin = posicion - 1;
	pos_fin = pos_fin < 0 ? _MAX_CANT_MUESTRAS_ - 1 : pos_fin;
	for(  ; fin.tv_sec <= fecha[pos_fin].tv_sec; pos_fin-- ){
		if( pos_fin == 0 ){
			pos_fin = _MAX_CANT_MUESTRAS_ - 1;
		}
		if( pos_fin == posicion ){
			puntos = 0;
			Tvalor temp;
			temp.L = _ERR_DATO_;
			fecha_pto.tv_sec = 0;
			fecha_pto.tv_usec = 0;
			return temp;
		}
	}

	pos_inicio = pos_fin - 1;
	pos_inicio = pos_inicio < 0 ? _MAX_CANT_MUESTRAS_ - 1 : pos_inicio;
	for( ; inicio.tv_sec <= fecha[pos_inicio].tv_sec; pos_inicio-- ){
		if( pos_inicio == 0 ){
			pos_inicio = _MAX_CANT_MUESTRAS_ - 1;
		}
		if( pos_inicio == pos_fin ){
			if( ++pos_inicio >= _MAX_CANT_MUESTRAS_ )
				pos_inicio = 0;
			break;
		}
	}

	puntos = pos_fin - pos_inicio;
	puntos = puntos < 0 ? puntos + _MAX_CANT_MUESTRAS_ : puntos;
	indice = pos_inicio;
	fecha_pto.tv_sec = fecha[pos_inicio].tv_sec;
	fecha_pto.tv_usec = fecha[pos_inicio].tv_usec;
	return punto[pos_inicio];
}

Tvalor tendencia::obtener_siguiente_punto( int & puntos, int & indice, struct timeval & fecha_pto ){
	indice++;
	puntos--;

	if( puntos > 0 ){
		if( indice >= _MAX_CANT_MUESTRAS_ )
			indice = 0;
		fecha_pto.tv_sec = fecha[indice].tv_sec;
		fecha_pto.tv_usec = fecha[indice].tv_usec;
		return punto[indice];
	}
	Tvalor temp;
	temp.L = _ERR_DATO_;
	fecha_pto.tv_sec = 0;
	fecha_pto.tv_usec = 0;
	return temp;
}
