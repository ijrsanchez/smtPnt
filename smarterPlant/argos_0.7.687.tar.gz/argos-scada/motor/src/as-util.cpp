/**
* @file	as-util.cpp
* @brief		<b>Utilitario usado por Argos</b><br>
* @author	    Alejandro Pina <ajpina@gmail.com><br>
* @link			http://www.cintal.com.ve/tecnologia/argos<br>
* @package      argos
* @access       public
* @version      1.0  -  01/06/09
*/

/*
Copyright (C) 2006 Alejandro Pina <ajpina@gmail.com>

Este programa es software libre. Puede redistribuirlo y/o modificarlo bajo
los terminos de la Licencia Publica General de GNU segun es publicada por
la Free Software Foundation, bien de la version 3 de dicha Licencia o bien
(segun su eleccion) de cualquier version posterior.

Este programa se distribuye con la esperanza de que sea util, pero
SIN NINGUNA GARANTIA, incluso sin la garantia MERCANTIL implicita o sin
garantizar la CONVENIENCIA PARA UN PROPOSITO PARTICULAR. Vease la Licencia
Publica General de GNU para mas detalles.

Deberia haber recibido una copia de la Licencia Publica General junto con
este programa. Si no ha sido asi, escriba a la Free Software Foundation, Inc.,
en 675 Mass Ave, Cambridge, MA 02139, EEUU.

Alejandro Pina mediante este documento renuncia a cualquier interes de derechos de
copyright con respecto al programa 'argos'.

01 de Noviembre de 2008

Por favor reporte cualquier fallo a la siguiente direccion:

	http://www.cintal.com.ve/tecnologia/argos

*/
#include "as-util.h"


char __ARCHIVO_CONF_TAGS[512] = "\0";			//!< Archivo XML de Tags
char __ARCHIVO_CONF_ALARMAS[512] = "\0";		//!< Archivo XML de Alarmas
char __ARCHIVO_CONF_DEVS[512] = "\0";			//!< Archivo XML de Dispositivos
char __ARCHIVO_CONF_SERV_DATOS[512] = "\0";		//!< Archivo XML de Servidor
char __ARCHIVO_CONF_CLIENTE_DATOS[512] = "\0";	//!< Archivo XML de Clientes
char __ARCHIVO_CONF_HISTORICOS[512] = "\0";		//!< Archivo XML de Historicos

/*--------------------------------------------------------
	Funciones para interpolacion de muestras.
----------------------------------------------------------*/
const char *_FUNCIONES_HISTORICOS_[] = {
		"AVG_",
		"STD_",
		"VAR_",
		"PZ_",
		"NO_",
		"FERROR_",
		"\0"
};

/**
* @brief	Obtiene un numero primo mayor que el parametro
* @param	no_primo	Numero No primo
*/
void primo_mayor_que(unsigned int & no_primo){
	unsigned int divisor = 2;
	unsigned int numero = no_primo;

	while(divisor<numero){
		while( numero % divisor != 0)
			divisor++;
		if(numero == divisor){
			no_primo = numero;
			break;
		}
       else{
    	   numero++;
    	   divisor = 2;
       }
  }
}

/**
* @brief	Obtiene la cantidad de funciones disponibles
* @return	uint	Cantidad de funciones
*/
unsigned int numero_funciones_disponibles(){
	unsigned int n = 0;
	while( strcmp(_FUNCIONES_HISTORICOS_[n++],"FERROR_") != 0 );
	return n-1;
}

/**
* @brief	Registra en el LOG de sistema configurado en syslog.conf
* @param	servicio	Nombre del proceso
* @param	opcion		Opcion del log
* @param	facilidad	Facilidad del log
* @param	nivel		Nivel del mensaje
* @param	msg			Mensaje del log
*/
void escribir_log(const char * servicio, int nivel, const char * msg){
	openlog (servicio, LOG_PID, LOG_LOCAL3);
	syslog(nivel, "%s\n", msg);
	closelog();
}

/**
* @brief	Imprime el numero de espacios necesarios para cuadrar
*        	la informaci�n imprimida en el espacio en pantalla
*					deseado
* @param	os				Stream de salida
*	@param	nombre		Mensaje a imprimir
* @param	maximo		cantidad de espacios
*/
void mostrar_espaciado(ostream & os, const char * nombre,int maximo){
				int espacio;
				espacio = maximo - strlen(nombre);
				for (int i = 0; i < espacio; i++){
					os<<" ";
				}
}


